export type paths = Record<string, never>;
export type webhooks = Record<string, never>;
export interface components {
    schemas: {
        /**
         * @description The base image of a layered boot, the current release's ReleaseBaseImage for the host's
         *     architecture. `imageUrl`, `kernelUrl` and `manifestUrl` are presigned GETs of the ext4 image, the
         *     kernel and the BaseImageManifest document stored under `imageDigest`, `kernelDigest` and
         *     `manifestDigest` in the release bucket.
         */
        "Channel.BaseImageDownload": {
            imageDigest: components["schemas"]["Sha256Digest"];
            kernelDigest: components["schemas"]["Sha256Digest"];
            manifestDigest: components["schemas"]["Sha256Digest"];
            /** Format: uri */
            imageUrl: string;
            /** Format: uri */
            kernelUrl: string;
            /** Format: uri */
            manifestUrl: string;
        };
        /** @description What a box boots from: a full guest image, or a base image with a harness layer. */
        "Channel.BootImage": components["schemas"]["Channel.GuestImageDownload"] | components["schemas"]["Channel.LayeredImageDownload"];
        /**
         * @description Asks the host to drop a box of a session that moved to another host, even when the box holds a
         *     completed turn no snapshot holds, or of a session whose repository the box could not clone. The host answers BoxGone, also when it runs no such box.
         */
        "Channel.BoxDiscard": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "BoxDiscard";
            sessionId: components["schemas"]["EntityId"];
            boxId: components["schemas"]["EntityId"];
        };
        /** @description The host runs no box of the session any more and returned its TAP device to the pool. */
        "Channel.BoxGone": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "BoxGone";
            sessionId: components["schemas"]["EntityId"];
            boxId: components["schemas"]["EntityId"];
        };
        /**
         * @description Asks the host to tear down the box of a session once a snapshot holds its last completed turn.
         *     The host answers BoxGone, also when it runs no box of the session with that boxId, or BoxTeardownFailed.
         */
        "Channel.BoxTeardown": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "BoxTeardown";
            sessionId: components["schemas"]["EntityId"];
            boxId: components["schemas"]["EntityId"];
        };
        /** @description The host kept the box. `detail` states what failed and what fixes it. */
        "Channel.BoxTeardownFailed": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "BoxTeardownFailed";
            sessionId: components["schemas"]["EntityId"];
            boxId: components["schemas"]["EntityId"];
            reason: components["schemas"]["Channel.BoxTeardownFailureReason"];
            detail: string;
            /** Format: date-time */
            failedAt: string;
        };
        /**
         * @description Why the host kept a box it was asked to tear down.
         * @enum {string}
         */
        "Channel.BoxTeardownFailureReason": "BoxDirty";
        /**
         * @description The first message on every connection, from the control plane: a fresh nonce, the unpadded
         *     base64url encoding of 32 random bytes, that the host must sign. A connection that sends anything
         *     but Hello next is closed.
         */
        "Channel.Challenge": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "Challenge";
            nonce: string;
        };
        /**
         * @description Where one chunk is stored: the chunk whose bytes have the lower-case hex SHA-256 `digest` lies
         *     `length` bytes long at byte `offset` of the pack `packDigest`. A pack is chunks concatenated, about
         *     8 MiB of them, stored under `<tenantId>/packs/<packDigest>`, where `packDigest` is the SHA-256 of
         *     the whole pack.
         */
        "Channel.ChunkPlacement": {
            digest: components["schemas"]["Sha256Digest"];
            packDigest: components["schemas"]["Sha256Digest"];
            /** Format: int64 */
            offset: number;
            /** Format: int32 */
            length: number;
        };
        /**
         * @description The code the person submitted, for the standard input of the setup's `claude setup-token`; the
         *     host forwards it to the box once and keeps no copy. The box fails the setup MintTimedOut when
         *     Claude Code prints no token within `mintBudgetSeconds` of the code.
         */
        "Channel.ClaudeSetupBoxCode": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "ClaudeSetupBoxCode";
            claudeSetupId: components["schemas"]["EntityId"];
            boxId: components["schemas"]["EntityId"];
            code: components["schemas"]["ClaudeSetupCodeText"];
            /** Format: int32 */
            mintBudgetSeconds: number;
        };
        /**
         * @description Asks the host to stop the setup's box and delete its drive, also in place of an unacked offer or
         *     code of a setup that ended. The host answers nothing, and does nothing when it runs no such box.
         */
        "Channel.ClaudeSetupBoxDiscard": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "ClaudeSetupBoxDiscard";
            claudeSetupId: components["schemas"]["EntityId"];
            boxId: components["schemas"]["EntityId"];
        };
        /**
         * @description The setup's box stopped without storing the token and is gone. `detail` states what failed and
         *     what fixes it, and never holds the token.
         */
        "Channel.ClaudeSetupBoxFailed": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "ClaudeSetupBoxFailed";
            claudeSetupId: components["schemas"]["EntityId"];
            reason: components["schemas"]["ClaudeSetupFailureReason"];
            detail: string;
            /** Format: date-time */
            failedAt: string;
        };
        /**
         * @description Asks the host to boot box `boxId` from `image` with no repository, no persona files and no
         *     credential, and run `claude setup-token` in it for Claude setup `claudeSetupId`. The host answers
         *     ClaudeSetupBoxUrl once the command prints its sign-in URL, hands the code of a ClaudeSetupBoxCode
         *     to the command's standard input, and answers ClaudeSetupBoxFailed when the box stops without
         *     storing the token. Only the box writes the token: it POSTs it to `tokenUrl` with `tokenCredential`
         *     as its bearer token, and the host never sees it. `tokenCredential` is bound to this setup and
         *     writes its token once, while the setup is Minting. The host stops the box at `expiresAt`, when it stores the token, or on
         *     ClaudeSetupBoxDiscard, and deletes its drive.
         */
        "Channel.ClaudeSetupBoxOffer": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "ClaudeSetupBoxOffer";
            claudeSetupId: components["schemas"]["EntityId"];
            tenantId: components["schemas"]["EntityId"];
            boxId: components["schemas"]["EntityId"];
            harnessVersion: components["schemas"]["HarnessVersion"];
            image: components["schemas"]["Channel.BootImage"];
            /** Format: uri */
            tokenUrl: string;
            tokenCredential: string;
            /** Format: date-time */
            expiresAt: string;
        };
        /** @description The setup's `claude setup-token` printed the URL where the person signs in. */
        "Channel.ClaudeSetupBoxUrl": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "ClaudeSetupBoxUrl";
            claudeSetupId: components["schemas"]["EntityId"];
            /** Format: uri */
            signInUrl: string;
            userCode?: string;
        };
        /**
         * @description The WebSocket close code each side closes a connection with. Revoked tells the host the tenant
         *     revoked it: the host stops its boxes, deletes its key and does not reconnect. On every other
         *     code but BadSignature and UnsupportedVersion the host reconnects.
         * @enum {integer}
         */
        "Channel.CloseCode": 4400 | 4401 | 4403 | 4408 | 4409 | 4426;
        /** @description Everything the control plane sends on a connection: Challenge, Welcome, Heartbeat, ReleasePublished, FrameRefused, or a sequenced frame. */
        "Channel.ControlEnvelope": components["schemas"]["Channel.Challenge"] | components["schemas"]["Channel.Welcome"] | components["schemas"]["Channel.Heartbeat"] | components["schemas"]["Channel.ReleasePublished"] | components["schemas"]["Channel.FrameRefused"] | components["schemas"]["Channel.ControlFrame"];
        /** @description One message from the control plane to the host, sequenced per Sequenced. */
        "Channel.ControlFrame": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "Frame";
            seq: components["schemas"]["Sequence"];
            ack: components["schemas"]["Sequence"];
            message: components["schemas"]["Channel.ControlMessage"];
        };
        "Channel.ControlMessage": components["schemas"]["Channel.TurnOffer"] | components["schemas"]["Channel.TurnWithdrawn"] | components["schemas"]["Channel.TurnClaimed"] | components["schemas"]["Channel.TurnCancel"] | components["schemas"]["Channel.SnapshotRequest"] | components["schemas"]["Channel.SnapshotChunksHeld"] | components["schemas"]["Channel.SnapshotPackUploads"] | components["schemas"]["Channel.RestoreDownloads"] | components["schemas"]["Channel.BoxTeardown"] | components["schemas"]["Channel.BoxDiscard"] | components["schemas"]["Channel.ClaudeSetupBoxOffer"] | components["schemas"]["Channel.ClaudeSetupBoxCode"] | components["schemas"]["Channel.ClaudeSetupBoxDiscard"];
        /**
         * @description One connector of a turn. `url` is the upstream MCP server. `tokenUrl` is the control plane's
         *     ConnectorTokens_fetch for this turn and connector, and `tokenCredential` its ConnectorTurnToken,
         *     valid while the turn is Running. The guest keeps both in forwarder memory only: never in the
         *     harness environment, a file, a log or a snapshot, and a new tokenCredential never restarts the
         *     harness.
         */
        "Channel.DispatchConnector": {
            connectorId: components["schemas"]["EntityId"];
            /** Format: uri */
            url: string;
            /** Format: uri */
            tokenUrl: string;
            tokenCredential: string;
        };
        /**
         * @description The dispatch variables for one offer: every member of the persona's secret set, the credential for
         *     the harness's provider under the variable its kind maps to and every other member under its own
         *     name. The control plane decrypts them from the secret set each time it sends or resends a
         *     TurnOffer, keeps no plaintext copy and records the variable names in an append-only handover log;
         *     `credentialHandoverId` names this handover in the supervisor's errors. `expiresAt`, the end of
         *     the turn's credential span (the longer of dispatchGrantTtlSeconds and turnOfferTtlSeconds plus
         *     turnImageFetchBudgetSeconds, from when the offer was sent), is when the supervisor stops handing
         *     the variables to a box and fails the turn DispatchCredentialExpired instead.
         */
        "Channel.DispatchGrant": {
            credentialHandoverId: components["schemas"]["EntityId"];
            /** Format: date-time */
            expiresAt: string;
            variables: components["schemas"]["Channel.DispatchVariable"][];
            /** @description The harness arguments the catalog maps the credential to; they hold no secret. A grant without them gives the guest none. */
            arguments?: string[];
            /** @description A CredentialFile credential: the guest writes `value` to `path` under the harness home, mode 0600, before the harness starts, and deletes it at the end of the turn. */
            credentialFile?: {
                path: string;
                value: string;
            };
            /** @description The session's connectors, none when its persona lists none. The guest forwarder serves each at its loopback route and fetches its access token from tokenUrl with tokenCredential. Neither reaches the harness. */
            connectors: components["schemas"]["Channel.DispatchConnector"][];
        };
        /** @description One environment variable for one turn: a secret set member's value. It lives in box memory only and is never written to the host's disk. */
        "Channel.DispatchVariable": {
            name: string;
            value: string;
        };
        /**
         * @description The control plane's answer to a host frame whose message matches no HostMessage. It travels
         *     outside frames, as Heartbeat does. The control plane counts that `seq` as received, so the next
         *     frame follows it without a gap, records nothing for it, and names the mismatch in `reason`. The
         *     host drops the frame from its unacked frames and logs FrameRefused with the reason, so one frame
         *     no control plane reads never holds up the channel. A supervisor that predates this message closes
         *     the connection with ProtocolError on it, and its reconnect resends the frame, which the control
         *     plane drops as a duplicate.
         */
        "Channel.FrameRefused": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "FrameRefused";
            seq: components["schemas"]["Sequence"];
            reason: string;
        };
        /**
         * @description The full guest image of the turn, from the current ReleaseManifest, for the session's harness version
         *     and the architecture the host enrolled with, offered while the release lacks a base image or a
         *     harness layer for them. `imageUrl`, `kernelUrl` and `manifestUrl` are presigned
         *     GETs of the ext4 image, the kernel and the GuestImageManifest document stored under
         *     `imageDigest`, `kernelDigest` and `manifestDigest` in the release bucket, valid until
         *     `downloadExpiresAt`, turnOfferTtlSeconds plus `fetchSeconds` after the send of the offer. A supervisor whose
         *     image cache lacks `imageDigest` sends TurnImageFetching and downloads the three within `fetchSeconds` of
         *     sending it, counting the wait for another image the host is fetching; it fetches one image at a time,
         *     checks each against its digest and only then moves them into the cache, replacing the cached image
         *     of the same harness version; it skips the kernel when the cache holds `kernelDigest`. A download
         *     that fails, misses its digest or names another image in its manifest fails the turn ImageFetchFailed,
         *     one that outlasts `fetchSeconds` fails it ImageFetchTimedOut.
         */
        "Channel.GuestImageDownload": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            kind: "Full";
            imageDigest: components["schemas"]["Sha256Digest"];
            kernelDigest: components["schemas"]["Sha256Digest"];
            manifestDigest: components["schemas"]["Sha256Digest"];
            /** Format: uri */
            imageUrl: string;
            /** Format: uri */
            kernelUrl: string;
            /** Format: uri */
            manifestUrl: string;
            /** Format: date-time */
            downloadExpiresAt: string;
            /** Format: int32 */
            fetchSeconds: number;
        };
        /**
         * @description The harness layer of a layered boot, the current release's ReleaseHarnessLayer for the session's
         *     harness version and the host's architecture. `layerUrl` and `manifestUrl` are presigned GETs of
         *     the squashfs file and the HarnessLayerManifest document stored under `layer.layerDigest` and
         *     `layer.manifestDigest` in the release bucket.
         */
        "Channel.HarnessLayerDownload": {
            layer: components["schemas"]["ReleaseHarnessLayer"];
            /** Format: uri */
            layerUrl: string;
            /** Format: uri */
            manifestUrl: string;
        };
        /**
         * @description The control plane sends one when it has sent nothing else for its heartbeat interval of 10
         *     seconds. A side that has received nothing for 30 seconds treats the connection as dead and closes
         *     it; the control plane then reads the host Offline.
         */
        "Channel.Heartbeat": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "Heartbeat";
            /** Format: date-time */
            sentAt: string;
        };
        /**
         * @description The host's answer to Challenge. `signature` is the base64 Ed25519 signature, by the host key
         *     made at enrolment, over these bytes in order: the ASCII string `tumpel-channel-hello-v1`, one
         *     0x00 byte, the ASCII bytes of the Challenge `nonce`, one 0x00 byte, and the UTF-8 bytes of
         *     `hostId`. The control plane rebuilds those bytes from the nonce it sent and verifies the
         *     signature against the host's stored public key. It answers Welcome, and closes the connection
         *     with BadSignature on a bad signature, Revoked for a revoked host, and UnsupportedVersion for a
         *     protocol version outside ChannelProtocol.Oldest to ChannelProtocol.Version. `boxCapacity` is the host's box slots from
         *     its runtime config and `usage` what it holds as it connects; the control plane keeps both for
         *     the host's tenant before it reads the host Online.
         */
        "Channel.Hello": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "Hello";
            hostId: components["schemas"]["EntityId"];
            /** Format: int32 */
            protocolVersion: number;
            supervisorVersion: string;
            signature: string;
            /** Format: int32 */
            boxCapacity: number;
            usage: components["schemas"]["HostUsage"];
        };
        /**
         * @description Everything the host sends on a connection: Hello, Heartbeat, or a sequenced frame. The host opens
         *     every connection itself, as a WebSocket to /v1/hosts/{hostId}/channel on the control plane's
         *     endpoint (wss for https, ws for http), and the control plane holds at most one per host: a new
         *     connection that reaches Welcome closes the one before it. Each message is one JSON text message.
         */
        "Channel.HostEnvelope": components["schemas"]["Channel.Hello"] | components["schemas"]["Channel.HostHeartbeat"] | components["schemas"]["Channel.HostFrame"];
        /** @description One message from the host to the control plane, sequenced per Sequenced. */
        "Channel.HostFrame": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "Frame";
            seq: components["schemas"]["Sequence"];
            ack: components["schemas"]["Sequence"];
            message: components["schemas"]["Channel.HostMessage"];
        };
        /**
         * @description The host sends one every 10 seconds after Welcome, whatever else it sends, with its usage. The
         *     control plane keeps the last one per host for the host's tenant, which places a new session on
         *     the Online host with the most free box slots, then the most memory available.
         *     `heldSessionIds` names every session the host holds a box for, whether the box runs a turn, waits
         *     warm or still boots, and is empty when it holds none. The host sends every frame queued before it
         *     read the list ahead of the Heartbeat, so the first Heartbeat after Welcome follows the resent
         *     frames. On that Heartbeat the control plane fails each Running turn on the host whose session the
         *     list does not name with BoxLost.
         */
        "Channel.HostHeartbeat": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "Heartbeat";
            /** Format: date-time */
            sentAt: string;
            usage: components["schemas"]["HostUsage"];
            heldSessionIds: components["schemas"]["EntityId"][];
        };
        "Channel.HostMessage": components["schemas"]["Channel.TurnImageFetching"] | components["schemas"]["Channel.TurnClaim"] | components["schemas"]["Channel.TurnRepositoryReady"] | components["schemas"]["Channel.TurnLine"] | components["schemas"]["Channel.TurnComplete"] | components["schemas"]["Channel.TurnRepositoryCloneFailed"] | components["schemas"]["Channel.TurnFailed"] | components["schemas"]["Channel.SnapshotChunks"] | components["schemas"]["Channel.SnapshotPacks"] | components["schemas"]["Channel.RestoreChunks"] | components["schemas"]["Channel.SnapshotDone"] | components["schemas"]["Channel.SnapshotFailed"] | components["schemas"]["Channel.BoxGone"] | components["schemas"]["Channel.BoxTeardownFailed"] | components["schemas"]["Channel.ClaudeSetupBoxUrl"] | components["schemas"]["Channel.ClaudeSetupBoxFailed"] | components["schemas"]["Channel.SupervisorUpdateStep"] | components["schemas"]["Channel.SupervisorUpdateFailed"] | components["schemas"]["Channel.TelemetryBatch"];
        /**
         * @description The layered boot of the turn, offered when the current release carries a base image for the
         *     host's architecture and a harness layer for the session's harness version on it. The box boots
         *     from the base, the guest drive of the host's supervisor and the layer. The URLs are valid until
         *     `downloadExpiresAt`, turnOfferTtlSeconds plus `fetchSeconds` after the send of the offer. A supervisor whose
         *     cache lacks the base or the layer sends TurnImageFetching naming the first part it lacks, then
         *     fetches base, kernel and layer within one `fetchSeconds` of sending it, counting the wait for
         *     another fetch on the host, and checks each against its digest before it moves it into the cache. A
         *     download that fails, misses its digest or names another part in its manifest fails the turn
         *     ImageFetchFailed, one that outlasts `fetchSeconds` fails it ImageFetchTimedOut. The host keeps the
         *     base and the layer in its cache while a box runs on them.
         */
        "Channel.LayeredImageDownload": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            kind: "Layered";
            base: components["schemas"]["Channel.BaseImageDownload"];
            layer: components["schemas"]["Channel.HarnessLayerDownload"];
            /** Format: date-time */
            downloadExpiresAt: string;
            /** Format: int32 */
            fetchSeconds: number;
        };
        /** @description One pack: `packDigest` is the SHA-256 of its `sizeBytes` bytes. */
        "Channel.Pack": {
            packDigest: components["schemas"]["Sha256Digest"];
            /** Format: int64 */
            sizeBytes: number;
        };
        /**
         * @description One pack object stored under `<tenantId>/packs/<packDigest>`, `sizeBytes` long, and `url` a
         *     presigned URL of that object alone.
         */
        "Channel.PackUrl": {
            packDigest: components["schemas"]["Sha256Digest"];
            /** Format: int64 */
            sizeBytes: number;
            /** Format: uri */
            url: string;
        };
        /**
         * @description One file of the session's persona. `downloadUrl` is a presigned GET of the blob stored under
         *     `digest`, valid until `downloadExpiresAt`, the DispatchGrant's expiresAt. The supervisor
         *     checks the bytes against `digest` and keeps them in its cache, so a digest it already holds is
         *     not fetched again.
         */
        "Channel.PersonaFileDownload": {
            path: components["schemas"]["PersonaFilePath"];
            digest: components["schemas"]["Sha256Digest"];
            sizeBytes: components["schemas"]["PersonaFileSize"];
            /** Format: uri */
            downloadUrl: string;
            /** Format: date-time */
            downloadExpiresAt: string;
        };
        /**
         * @description The control plane sends one to every Online host when the release bucket stores a new current
         *     release, `releaseVersion` naming it. It travels outside frames, as Heartbeat does, so it is never
         *     resent: a host that misses it reads the release at its next Welcome. The host reads
         *     GET /v1/releases/current and updates its supervisor when the release names another binary. A
         *     supervisor that predates this message closes the connection with ProtocolError on it, and the
         *     Welcome of its reconnect reads the release.
         */
        "Channel.ReleasePublished": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "ReleasePublished";
            releaseVersion: string;
        };
        /**
         * @description Part `part` of the chunks a box that boots cold needs for turn `turnId` and lacks in the host's
         *     chunk cache, each at the placement its manifest or root names, at most
         *     ChunkExchange.DigestsPerPart of them, grouped by pack. The host sends each next part once the
         *     answer to the one before arrived, and starts the downloads of each part as its answer arrives.
         *     The control plane answers RestoreDownloads.
         */
        "Channel.RestoreChunks": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "RestoreChunks";
            turnId: components["schemas"]["EntityId"];
            /** Format: int32 */
            part: number;
            chunks: components["schemas"]["Channel.ChunkPlacement"][];
        };
        /**
         * @description The answer to RestoreChunks part `part`: a presigned GET for each pack that holds chunks of that
         *     part, valid until `downloadExpiresAt`, the DispatchGrant's expiresAt. A pack is left out when
         *     any chunk asked in it is no chunk of the session at that placement, and the host fails the turn
         *     SnapshotUnreadable.
         */
        "Channel.RestoreDownloads": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "RestoreDownloads";
            turnId: components["schemas"]["EntityId"];
            /** Format: int32 */
            part: number;
            packs: components["schemas"]["Channel.PackUrl"][];
            /** Format: date-time */
            downloadExpiresAt: string;
        };
        /**
         * @description Each direction of a host's channel numbers its frames from 1 in `seq`, and the count survives
         *     reconnects and restarts. `ack` is the highest `seq` the sender has received from the other side
         *     with no gap before it, 0 before the first one; it advances only with the sender's next frame. A
         *     receiver drops a frame whose `seq` is at or below the last one it accepted, and treats a gap as
         *     a protocol error that closes the connection. After Welcome each side resends, in order, every
         *     frame the other side has not acked, and the receiver drops the duplicates. The control plane
         *     keeps both counters and its unacked frames in durable storage. The supervisor writes its
         *     counters and unacked frames to disk before it sends a frame; when it starts without that state
         *     it does not dial, and exits with failure ChannelStateLost, and the host is enrolled again.
         *     Challenge, Hello, Welcome and Heartbeat belong to one connection and travel outside frames,
         *     with no `seq` or `ack`. Each side ignores fields it does not know.
         */
        "Channel.Sequenced": {
            seq: components["schemas"]["Sequence"];
            ack: components["schemas"]["Sequence"];
        };
        /**
         * @description Part `part` of the chunk digests the files of a snapshot hold that the box's previous snapshot
         *     did not, at most ChunkExchange.DigestsPerPart of them. The host sends part 1 once its files are
         *     cut, and each next part once the answer to the one before arrived. The control plane answers
         *     SnapshotChunksHeld and counts each digest as referenced by the session.
         */
        "Channel.SnapshotChunks": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "SnapshotChunks";
            snapshotId: components["schemas"]["EntityId"];
            /** Format: int32 */
            part: number;
            digests: components["schemas"]["Sha256Digest"][];
        };
        /**
         * @description The answer to SnapshotChunks part `part`: where the tenant stores each digest of that part it
         *     holds already. A digest left out is stored in no pack, and the host packs and uploads it.
         */
        "Channel.SnapshotChunksHeld": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "SnapshotChunksHeld";
            snapshotId: components["schemas"]["EntityId"];
            /** Format: int32 */
            part: number;
            held: components["schemas"]["Channel.ChunkPlacement"][];
        };
        /** @description The host stored the snapshot's packs and root. `uploadedBytes` counts the bytes it uploaded: the packs the tenant lacked, plus the root. */
        "Channel.SnapshotDone": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "SnapshotDone";
            snapshotId: components["schemas"]["EntityId"];
            /** Format: int64 */
            uploadedBytes: number;
        };
        /**
         * @description One stored snapshot of a session, for a box that boots cold. `downloadUrl` is a presigned GET of
         *     the SnapshotRoot under `storageKey` alone, valid until `downloadExpiresAt`, the end of the turn's
         *     credential span, the DispatchGrant's expiresAt.
         */
        "Channel.SnapshotDownload": {
            snapshotId: components["schemas"]["EntityId"];
            snapshotSeq: components["schemas"]["Sequence"];
            storageKey: components["schemas"]["StorageKey"];
            /** Format: uri */
            downloadUrl: string;
            /** Format: date-time */
            downloadExpiresAt: string;
        };
        /** @description The host could not store the snapshot. `detail` states what failed and what fixes it. */
        "Channel.SnapshotFailed": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "SnapshotFailed";
            snapshotId: components["schemas"]["EntityId"];
            reason: components["schemas"]["Channel.SnapshotFailureReason"];
            detail: string;
            /** Format: date-time */
            failedAt: string;
        };
        /**
         * @description Why the host could not store a snapshot.
         * @enum {string}
         */
        "Channel.SnapshotFailureReason": "BoxNotFound" | "UpperDirectoryUnreadable" | "UploadExpired" | "UploadRejected" | "SnapshotTimedOut" | "NotAnswered";
        /**
         * @description Part `part` of the chunks a snapshot packed: where each chunk lies, at most
         *     ChunkExchange.DigestsPerPart of them, and the size of each pack they lie in. A pack whose chunks
         *     run past one part is listed again in the next. The host sends part 1 once its packs are written,
         *     and each next part once the answer to the one before arrived. The control plane keeps the
         *     placements until SnapshotDone, counts each digest as referenced by the session, and answers
         *     SnapshotPackUploads.
         */
        "Channel.SnapshotPacks": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "SnapshotPacks";
            snapshotId: components["schemas"]["EntityId"];
            /** Format: int32 */
            part: number;
            packs: components["schemas"]["Channel.Pack"][];
            chunks: components["schemas"]["Channel.ChunkPlacement"][];
        };
        /**
         * @description The answer to SnapshotPacks part `part`: a presigned PUT for each pack of that part the tenant
         *     holds no object for, valid until `uploadExpiresAt`. Each URL signs the pack's SHA-256 as the
         *     x-amz-checksum-sha256 header, so the host sends that header and object storage refuses bytes that
         *     do not hash to the key. A pack left out is stored already.
         */
        "Channel.SnapshotPackUploads": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "SnapshotPackUploads";
            snapshotId: components["schemas"]["EntityId"];
            /** Format: int32 */
            part: number;
            uploads: components["schemas"]["Channel.PackUrl"][];
            /** Format: date-time */
            uploadExpiresAt: string;
        };
        /**
         * @description Asks the host to store the upper directory of a box as a SnapshotRoot under `storageKey`. The
         *     host sends the chunk digests its files hold that the box's previous snapshot did not in
         *     SnapshotChunks parts, packs the ones the tenant lacks together with the chunks of its encoded
         *     SnapshotManifest, sends their placements in SnapshotPacks parts, uploads the packs each
         *     SnapshotPackUploads names, then PUTs the root to `uploadUrl`, a presigned PUT of `storageKey`
         *     alone, and answers SnapshotDone. Every URL expires at `uploadExpiresAt`, the snapshot deadline,
         *     after which the control plane records the snapshot failed NotAnswered.
         */
        "Channel.SnapshotRequest": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "SnapshotRequest";
            snapshotId: components["schemas"]["EntityId"];
            sessionId: components["schemas"]["EntityId"];
            boxId: components["schemas"]["EntityId"];
            turnId: components["schemas"]["EntityId"];
            snapshotSeq: components["schemas"]["Sequence"];
            storageKey: components["schemas"]["StorageKey"];
            /** Format: uri */
            uploadUrl: string;
            /** Format: date-time */
            uploadExpiresAt: string;
        };
        /**
         * @description A HostFrame as channel.json keeps it until the control plane acks it. The message stays as the
         *     supervisor wrote it, so a supervisor of another version loads it whatever message kinds it reads
         *     and resends it unchanged; a message no control plane reads is answered with FrameRefused.
         */
        "Channel.StoredHostFrame": {
            /** @enum {string} */
            type: "Frame";
            seq: components["schemas"]["Sequence"];
            ack: components["schemas"]["Sequence"];
            message: unknown;
        };
        /**
         * @description The host's supervisor update stopped. `detail` states what failed and what fixes it.
         *     `outputTail` holds the last lines the candidate printed in its dry run, token-shaped runs
         *     hidden, and is empty for every other reason.
         */
        "Channel.SupervisorUpdateFailed": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "SupervisorUpdateFailed";
            fromSha256: components["schemas"]["Sha256Digest"];
            toSha256: components["schemas"]["Sha256Digest"];
            reason: components["schemas"]["SupervisorUpdateFailureReason"];
            detail: string;
            outputTail: string[];
            /** Format: date-time */
            failedAt: string;
        };
        /**
         * @description The host's supervisor update from the binary `fromSha256` to `toSha256` entered `phase`. The new
         *     binary sends Online once it reaches Welcome after the swap.
         */
        "Channel.SupervisorUpdateStep": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "SupervisorUpdateStep";
            fromSha256: components["schemas"]["Sha256Digest"];
            toSha256: components["schemas"]["Sha256Digest"];
            releaseVersion: string;
            /** Format: int32 */
            boxesRunning: number;
            phase: components["schemas"]["SupervisorUpdatePhase"];
            /** Format: date-time */
            at: string;
        };
        /**
         * @description Metric points the supervisor collected at its lifecycle edges and from its host sampler, sent
         *     while the channel is Welcomed. The control plane overwrites each point's `hostId` dimension with
         *     the host that signed the connection, stamps each turn.cost and turn.tokens point with the
         *     personaId, secretSetId, provider and costBasis of the turn as it offered it, drops a turn.cost
         *     point whose costBasis is NotReported, and writes the batch to the tenant's metrics store. A batch
         *     the store refuses is logged as TelemetryRejected and still acked. The control plane refuses this
         *     message on a connection that speaks a protocol version below 19.
         */
        "Channel.TelemetryBatch": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "TelemetryBatch";
            instruments: components["schemas"]["MetricInstrument"][];
            samples: components["schemas"]["SamplePoint"][];
            turns: components["schemas"]["TurnPoint"][];
        };
        /**
         * @description Asks the host to end turn `turnId` at once, which the control plane already failed Cancelled. The
         *     host ends the harness and answers TurnFailed Cancelled with the turn's credential file, and the
         *     control plane keeps the reason and detail it recorded. The box is then a box after any turn, and the
         *     SnapshotRequest and BoxTeardown that follow snapshot and free it. A host that runs no such turn
         *     does nothing.
         */
        "Channel.TurnCancel": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "TurnCancel";
            turnId: components["schemas"]["EntityId"];
        };
        /**
         * @description The host accepts the offered turn. It sends this at once, before it fetches the image, restores the
         *     snapshot or boots the box; those keep their own budgets and failures. The control plane answers TurnClaimed
         *     and the turn reads Running, or answers TurnWithdrawn when the turn already left Offered. The host
         *     hands the prompt to the harness only once TurnClaimed arrived and the box is ready. A host that
         *     gives up waiting for the answer hands nothing and fails the turn NotClaimed, and the control plane
         *     offers the turn again. So a turn is either claimed and its result reaches the control plane, or
         *     refused before the harness starts.
         */
        "Channel.TurnClaim": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "TurnClaim";
            turnId: components["schemas"]["EntityId"];
            boxId: components["schemas"]["EntityId"];
        };
        /** @description The control plane's answer to a TurnClaim for a turn that was still Offered; the turn now reads Running, and the host hands its prompt to the harness once the box is ready. */
        "Channel.TurnClaimed": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "TurnClaimed";
            turnId: components["schemas"]["EntityId"];
        };
        /** @description The harness finished the turn. `lastLineSeq` is the turn's final line; the control plane holds every line up to it before the turn reads Completed. */
        "Channel.TurnComplete": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "TurnComplete";
            turnId: components["schemas"]["EntityId"];
            lastLineSeq: components["schemas"]["Sequence"];
            /** Format: date-time */
            completedAt: string;
            /** @description The turn's credential file as the harness rewrote it; the control plane stores it in place of the secret set's CredentialFile member. */
            credentialFile?: string;
            /** @description The guest's warning for a turn the harness completed, such as a box disk with less than a hundredth of it free; the control plane shows it on the turn read. */
            warning?: string;
        };
        "Channel.TurnFailed": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "TurnFailed";
            turnId: components["schemas"]["EntityId"];
            reason: components["schemas"]["TurnFailureReason"];
            detail: string;
            /** Format: date-time */
            failedAt: string;
            /** @description The turn's credential file as the harness rewrote it; the control plane stores it in place of the secret set's CredentialFile member. */
            credentialFile?: string;
        };
        /**
         * @description The host's cache lacks part of the offer's image and the host has started to download it: `imageDigest` names
         *     the full image, or the base image or harness layer of a layered boot, whichever it lacks first.
         *     It follows the TurnClaim; the host fails the turn ImageFetchTimedOut when the fetch outlasts the
         *     offer's `image.fetchSeconds`.
         */
        "Channel.TurnImageFetching": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "TurnImageFetching";
            turnId: components["schemas"]["EntityId"];
            imageDigest: components["schemas"]["Sha256Digest"];
        };
        /** @description One harness-native JSONL line. `lineSeq` continues the session's line count, so lines of a turn arrive in `lineSeq` order with no gap. */
        "Channel.TurnLine": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "TurnLine";
            turnId: components["schemas"]["EntityId"];
            lineSeq: components["schemas"]["Sequence"];
            text: string;
        };
        /**
         * @description The control plane offers a turn to the host. The host answers TurnClaim, or TurnFailed when it
         *     cannot run it. `lastLineSeq` is the session's last transcript line, so the box numbers the turn's
         *     first line `lastLineSeq` + 1. `snapshots` holds the session's latest stored snapshot, which a box
         *     that boots cold restores from; it is empty for a session with none. `personaFiles` is the persona's file set as it stands when the offer is sent. `gitAuthorName` and
         *     `gitAuthorEmail` are the git identity the box commits as: the bot of the stage's GitHub App when the tenant
         *     installed it, else the GitHub user of the secret set's GITHUB_TOKEN, with its noreply address. `image` is the guest image
         *     the box boots. A resend of the offer keeps its `seq` and carries a new `credential`, `lastLineSeq`,
         *     `snapshots`, `personaFiles`, `image` and git identity.
         */
        "Channel.TurnOffer": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "TurnOffer";
            turnId: components["schemas"]["EntityId"];
            sessionId: components["schemas"]["EntityId"];
            boxId: components["schemas"]["EntityId"];
            repository: components["schemas"]["RepositoryUrl"];
            harness: components["schemas"]["Harness"];
            harnessVersion: string;
            model: components["schemas"]["ModelName"];
            prompt: components["schemas"]["Prompt"];
            credential: components["schemas"]["Channel.DispatchGrant"];
            lastLineSeq: components["schemas"]["Sequence"];
            snapshots: components["schemas"]["Channel.SnapshotDownload"][];
            personaFiles: components["schemas"]["Channel.PersonaFileDownload"][];
            image: components["schemas"]["Channel.BootImage"];
            gitAuthorName: components["schemas"]["DisplayName"];
            gitAuthorEmail: components["schemas"]["EmailAddress"];
            /**
             * Format: int32
             * @description The memory in MiB the box boots with: the persona's boxMemoryMib, or BoxMemoryLimit.DefaultMib. A box
             *     that is already warm keeps the memory it booted with. A supervisor given an offer without it boots
             *     the box with memoryMib of its runtime config.
             */
            boxMemoryMib?: number;
            /**
             * Format: int32
             * @description The disk in MiB the box boots with: the persona's boxDiskMib, or BoxDiskLimit.DefaultMib. A box that
             *     is already warm keeps the disk it booted with. A supervisor given an offer without it boots the
             *     box with overlayMib of its runtime config, and refuses the turn PoolExhausted when the disk does
             *     not fit its disk budget.
             */
            boxDiskMib?: number;
            /**
             * @description Set when the turn builds a prebuild: the box clones the repository at this commit and runs the
             *     repository's setup step, /opt/tumpel/prebuild.mjs run, in place of the harness, its output lines
             *     being the turn's lines. The credential then holds only a GITHUB_TOKEN that reads the
             *     repository's contents, and the snapshot the control plane asks for after the turn is the
             *     prebuild's layer.
             */
            prebuildCommitSha?: string;
        };
        /** @description The box could not clone the session's repository; the turn fails RepositoryCloneFailed. `detail` carries what git reported. */
        "Channel.TurnRepositoryCloneFailed": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "TurnRepositoryCloneFailed";
            turnId: components["schemas"]["EntityId"];
            cause: components["schemas"]["RepositoryCloneFailureCause"];
            detail: string;
            /** Format: date-time */
            failedAt: string;
        };
        /** @description The box holds the session's repository and the harness is about to get the prompt; the first-line budget starts here. */
        "Channel.TurnRepositoryReady": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "TurnRepositoryReady";
            turnId: components["schemas"]["EntityId"];
        };
        /**
         * @description Takes the place of an unacked TurnOffer when the control plane resends it after its turn left
         *     Offered, so the resend keeps every `seq` and no key reaches a turn that already ended. It is also
         *     the answer to a TurnClaim for a turn that left Offered before the claim arrived: the host then
         *     hands the turn no prompt, keeps the box warm and reports nothing for the turn.
         */
        "Channel.TurnWithdrawn": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "TurnWithdrawn";
            turnId: components["schemas"]["EntityId"];
        };
        /** @description The control plane accepts the host. Both sides then resend their unacked frames. */
        "Channel.Welcome": {
            /**
             * @description discriminator enum property added by openapi-typescript
             * @enum {string}
             */
            type: "Welcome";
            hostId: components["schemas"]["EntityId"];
            /** Format: int32 */
            protocolVersion: number;
        };
        /** @description The sign-in code a person pastes after signing in at a Claude setup's signInUrl. */
        ClaudeSetupCodeText: string;
        /**
         * @description Why a Claude setup ended Failed. Each reason names the phase it stopped in.
         * @enum {string}
         */
        ClaudeSetupFailureReason: "SetupUrlMissing" | "CodeRejected" | "ClaudeCodeExited" | "SetupTimedOut" | "TokenNotStored" | "NoHostOnline" | "Superseded";
        DisplayName: string;
        EmailAddress: string;
        EntityId: string;
        /** @enum {string} */
        Harness: "ClaudeCode" | "Codex" | "OpenCode" | "PiDev" | "MistralAgent";
        HarnessVersion: string;
        /** @enum {string} */
        HostArchitecture: "Amd64" | "Arm64";
        /**
         * @description What a host holds at one moment, sent on Hello and on every host Heartbeat. `boxesWarm` counts
         *     the paused boxes in their warm window, `loadAverage` is the one-minute load average of the host,
         *     and `memoryAvailableMib` is MemAvailable of /proc/meminfo in MiB. `diskBudgetMib` is the disk the
         *     host gives box disks: the free disk under its dataDir and what its boxes already wrote, less the
         *     headroom it keeps free. `diskHeldMib` is the sum of the disk sizes of the boxes it holds. A host
         *     admits a box only while its disk fits the budget beside the held ones; a supervisor older than
         *     the box disk budget sends neither. `memoryBudgetMib` is the memory the host gives boxes: MemTotal
         *     less the headroom it keeps free. `memoryHeldMib` is the sum of the `boxMemoryMib` of the boxes it
         *     holds. A host admits a box only while its memory fits the budget beside the held ones, whatever
         *     their count; a supervisor older than the memory budget sends neither.
         */
        HostUsage: {
            /** Format: int32 */
            boxesWarm: number;
            /** Format: double */
            loadAverage: number;
            /** Format: int64 */
            memoryAvailableMib: number;
            /** Format: int64 */
            diskBudgetMib?: number;
            /** Format: int64 */
            diskHeldMib?: number;
            /** Format: int64 */
            memoryBudgetMib?: number;
            /** Format: int64 */
            memoryHeldMib?: number;
        };
        /**
         * @description The harness of a guest image's GuestHarness: a catalog harness, or Shell for the test image the proof's Shell harness steps boot.
         * @enum {string}
         */
        ImageHarness: "ClaudeCode" | "Codex" | "OpenCode" | "PiDev" | "MistralAgent" | "Shell";
        /** @description A metric's declaration: its unit as OpenTelemetry writes it (s, MiB, {token}), its kind and what it measures. */
        MetricInstrument: {
            metric: components["schemas"]["MetricName"];
            unit: string;
            kind: components["schemas"]["MetricKind"];
            description: string;
        };
        /** @enum {string} */
        MetricKind: "Turn" | "Sample";
        /** @description A metric name in the OpenTelemetry style: dotted lower-case segments, at most 64 characters. */
        MetricName: string;
        ModelName: string;
        /** @description A path relative to the harness home in the box, such as .claude/settings.json. The harness catalog lists the paths each harness accepts. */
        PersonaFilePath: string;
        /**
         * Format: int64
         * @description The size of a persona file in bytes, at most PersonaFileLimit.PersonaBytes.
         */
        PersonaFileSize: number;
        Prompt: string;
        /**
         * @description One harness layer of a release, for one harness version and architecture: a read-only squashfs
         *     image compressed with zstd whose root is `/opt/harness/<harness>/<harnessVersion>` in the box.
         *     The squashfs file and its HarnessLayerManifest document are stored under
         *     `layers/<harness>/<harnessVersion>/<arch>/<digest>` by `layerDigest` and `manifestDigest`.
         *     `sizeBytes` is the size of the squashfs file. A host attaches a layer only once its sha256
         *     matches `layerDigest`.
         */
        ReleaseHarnessLayer: {
            harness: components["schemas"]["ImageHarness"];
            harnessVersion: components["schemas"]["HarnessVersion"];
            architecture: components["schemas"]["HostArchitecture"];
            layerDigest: components["schemas"]["Sha256Digest"];
            manifestDigest: components["schemas"]["Sha256Digest"];
            /** Format: int64 */
            sizeBytes: number;
        };
        /**
         * @description Why the box could not clone the session's repository.
         * @enum {string}
         */
        RepositoryCloneFailureCause: "Refused" | "TimedOut" | "DirectoryNotEmpty" | "Other";
        RepositoryUrl: string;
        /** @description One value of a Sample metric at a moment, with its dimensions. */
        SamplePoint: {
            metric: components["schemas"]["MetricName"];
            /** Format: date-time */
            at: string;
            /** Format: double */
            value: number;
            dimensions: {
                [key: string]: string;
            };
        };
        /** Format: int64 */
        Sequence: number;
        /** @description A lower-case hex SHA-256 digest: the name of a file in the image cache, or of a persona file blob. */
        Sha256Digest: string;
        StorageKey: string;
        /**
         * @description Why a supervisor update stopped. Every one but SupervisorUpdateRolledBack leaves the running binary in place.
         * @enum {string}
         */
        SupervisorUpdateFailureReason: "SupervisorUpdateFetchFailed" | "SupervisorUpdateChecksumMismatch" | "SupervisorUpdateDryRunFailed" | "SupervisorUpdateStateUnreadable" | "SupervisorUpdateIdleTimedOut" | "SupervisorUpdateSwapFailed" | "SupervisorUpdateRolledBack";
        /**
         * @description The phase a supervisor update entered. Fetching downloads and verifies the candidate binary,
         *     DryRunning runs it with `check` beside the running binary and keeps it once it passes, Staged
         *     is what supervisors before the box handover send while a candidate waits for the host to run no
         *     box, Restarting swaps the binaries, parks every running turn and execs the new one, which takes
         *     over the running boxes, and Online is the new binary reaching Welcome. WaitingForIdle is what supervisors before the idle claim send between DryRunning and
         *     Restarting; the control plane accepts it and records nothing.
         * @enum {string}
         */
        SupervisorUpdatePhase: "Fetching" | "DryRunning" | "Staged" | "WaitingForIdle" | "Restarting" | "Online";
        /**
         * @description Why a turn ended Failed. Each reason names the phase the turn stopped in.
         * @enum {string}
         */
        TurnFailureReason: "NotClaimed" | "Undelivered" | "NoFirstOutput" | "HostOffline" | "CredentialRefused" | "DispatchCredentialExpired" | "CredentialExpired" | "BoxBootFailed" | "PoolExhausted" | "SnapshotUnreadable" | "HarnessExited" | "HarnessOutOfMemory" | "BoxDiskFull" | "HarnessExitedWithoutResult" | "TurnTimedOut" | "TranscriptGap" | "PersonaFileUnreadable" | "RepositoryCloneFailed" | "HarnessReportedError" | "RepositoryTokenRefused" | "ImageNotReleased" | "ImageFetchFailed" | "ImageFetchTimedOut" | "HostUpdating" | "BoxLost" | "Cancelled" | "ConnectorDisconnected";
        /** @description One value of a Turn metric, with the turn and session it belongs to. */
        TurnPoint: {
            metric: components["schemas"]["MetricName"];
            /** Format: date-time */
            at: string;
            /** Format: double */
            value: number;
            dimensions: {
                [key: string]: string;
            };
            turnId: components["schemas"]["EntityId"];
            sessionId: components["schemas"]["EntityId"];
        };
    };
    responses: never;
    parameters: never;
    requestBodies: never;
    headers: never;
    pathItems: never;
}
export type $defs = Record<string, never>;
export type operations = Record<string, never>;
