import { z } from "zod";
export const ChannelProtocol = { Oldest: 18, Version: 31 };
export const GuestProtocol = { Oldest: 9, Version: 14 };
export const TenantApiProtocol = { Oldest: 1, Version: 10 };
export const ChunkExchange = { DigestsPerPart: 500 };
export const ChunkExchangeSchema = z.enum(ChunkExchange);
export const BaseLayout = { Version: 1 };
export const BaseLayoutSchema = z.enum(BaseLayout);
export const PersonaFileLimit = { InlineFileBytes: 65536, PersonaBytes: 262144 };
export const PersonaFileLimitSchema = z.enum(PersonaFileLimit);
export const BoxMemoryLimit = { MinMib: 512, DefaultMib: 2048, MaxMib: 65536 };
export const BoxMemoryLimitSchema = z.enum(BoxMemoryLimit);
export const BoxDiskLimit = { DefaultMib: 32768, MaxMib: 262144 };
export const BoxDiskLimitSchema = z.enum(BoxDiskLimit);
export const BoxRetentionSchema = z.enum(["Off", "Warm", "Auto"]);
export const HealthStatusSchema = z.enum(["Ok"]);
export const PrincipalRoleSchema = z.enum(["Owner", "Member"]);
export const HostStateSchema = z.enum(["Enrolled", "Online", "Offline", "Revoked"]);
export const SupervisorUpdatePhaseSchema = z.enum(["Fetching", "DryRunning", "Staged", "WaitingForIdle", "Restarting", "Online"]);
export const SupervisorUpdateFailureReasonSchema = z.enum(["SupervisorUpdateFetchFailed", "SupervisorUpdateChecksumMismatch", "SupervisorUpdateDryRunFailed", "SupervisorUpdateStateUnreadable", "SupervisorUpdateIdleTimedOut", "SupervisorUpdateSwapFailed", "SupervisorUpdateRolledBack"]);
export const HostArchitectureSchema = z.enum(["Amd64", "Arm64"]);
export const EnrolmentTokenStateSchema = z.enum(["Unused", "Spent"]);
export const SessionStateSchema = z.enum(["Starting", "Idle", "Running", "Stopping", "Stopped", "Archived", "Failed"]);
export const TurnStateSchema = z.enum(["Offered", "Running", "Completed", "Failed"]);
export const TurnFailureReasonSchema = z.enum(["NotClaimed", "Undelivered", "NoFirstOutput", "HostOffline", "CredentialRefused", "DispatchCredentialExpired", "CredentialExpired", "BoxBootFailed", "PoolExhausted", "SnapshotUnreadable", "HarnessExited", "HarnessOutOfMemory", "BoxDiskFull", "HarnessExitedWithoutResult", "TurnTimedOut", "TranscriptGap", "PersonaFileUnreadable", "RepositoryCloneFailed", "HarnessReportedError", "CreditExhausted", "RepositoryTokenRefused", "ImageNotReleased", "ImageFetchFailed", "ImageFetchTimedOut", "HostUpdating", "BoxLost", "Cancelled", "ConnectorDisconnected", "SnapshotNotStored"]);
export const RepositoryCloneFailureCauseSchema = z.enum(["Refused", "TimedOut", "DirectoryNotEmpty", "Other"]);
export const HarnessSchema = z.enum(["ClaudeCode", "Codex", "OpenCode", "PiDev", "MistralAgent"]);
export const ModelProviderSchema = z.enum(["Anthropic", "OpenAi", "Mistral", "Google", "OpenRouter"]);
export const PrebuildLayerAbsenceSchema = z.enum(["BuildsPrebuild", "HostNotAmd64", "NoAmd64Image", "NoPrebuild", "OtherGuestImage", "NotRecorded"]);
export const StopFailureReasonSchema = z.enum(["BoxDirty", "NotAnswered"]);
export const SteerStateSchema = z.enum(["Pending", "Delivered", "TurnEnded"]);
export const RepositoryCredentialSourceSchema = z.enum(["GitHubApp", "SecretSet", "None"]);
export const CredentialKindSchema = z.enum(["ApiKey", "SubscriptionToken", "CredentialFile"]);
export const CostBasisSchema = z.enum(["Billed", "NotBilled", "NotReported"]);
export const CredentialChoiceSchema = z.enum(["CatalogOrder", "ModelProvider"]);
export const TokenKindSchema = z.enum(["Input", "Output", "CacheRead", "CacheWrite"]);
export const PersonaFileSourceSchema = z.enum(["Inline", "Stored"]);
export const SecretKindSchema = z.enum(["Variable", "ApiKey", "SubscriptionToken", "CredentialFile"]);
export const MetricKindSchema = z.enum(["Turn", "Sample"]);
export const MetricBucketSchema = z.enum(["Minute", "Hour", "Day"]);
export const GitHubTriggerEventSchema = z.enum(["pull_request", "push", "status", "issues"]);
export const ProblemCodeSchema = z.enum(["InvalidRequest", "SignedOut", "Forbidden", "NotFound", "Conflict", "NotInvited", "EnrolmentTokenSpent", "EnrolmentTokenExpired", "HostRevoked", "NoHostAvailable", "PoolExhausted", "HostOffline", "HarnessNotInCatalog", "NoCredential", "CredentialExpired", "CredentialKindUnsupported", "ModelUnsupported", "TurnInFlight", "TurnNotWaiting", "TurnNotRunning", "SteerUnsupported", "SessionStopping", "SessionNotStopped", "SessionArchived", "SessionFailed", "GitHubAppMissing", "GitHubNotConnected", "IssueNotOpen", "IssueNotFound", "NoRelease", "ReleaseUnreadable", "TranscriptLineUnreadable", "ImageNotReleased", "NoBuildProvider", "BuildProviderUnavailable", "DispatchRefused", "GitHubAppPermissionMissing", "CallerWorkflowRefused", "RepositoryUnreadable", "GitHubInstallationUnreadable", "IssuerMissing", "JobTokenRefused", "JobTokenMismatch", "PrebuildNotUploading", "CircleCITokenRefused", "CircleCIProjectMissing", "CircleCIDefinitionMismatch", "CircleCIRefused", "CircleCIAuthorizationNotWaiting", "LayerNotUploaded", "OwnerRequired", "LastOwner", "InvitationExpired", "EventCursorExpired", "SubscriptionEnded", "SubscriptionCursorExpired", "NoHostOnline", "TriggerFieldMissing", "ClaudeSetupNotWaiting", "ClaudeSetupBoxTokenRefused", "DeployInProgress", "DeployDrainTokenRefused", "MetricRangeTooLarge", "MetricNotFound", "PrebuildTemplateNotFound", "DevcontainerMissing", "DevcontainerExists", "GitHubRefused", "ConnectorInUse", "ConnectorChanged", "ConnectorDiscoveryFailed", "ConnectorRegistrationUnsupported", "ConnectorDisconnected", "ConnectorRefreshFailed", "ConnectorTurnNotRunning", "ConnectorTurnTokenRefused", "ConnectorAuthRefused", "ConnectorUnreachable"]);
export const OAuthErrorCodeSchema = z.enum(["invalid_request", "invalid_client", "invalid_grant", "unsupported_grant_type", "unsupported_response_type", "invalid_target", "invalid_client_metadata", "invalid_redirect_uri", "authorization_pending", "slow_down", "access_denied", "expired_token"]);
export const PersonaFilePatchKindSchema = z.enum(["Put", "Remove", "Edit"]);
export const ImageHarnessSchema = z.enum(["ClaudeCode", "Codex", "OpenCode", "PiDev", "MistralAgent", "Shell"]);
export const GitHubAccountTypeSchema = z.enum(["User", "Organization"]);
export const GitHubInstallationStatusSchema = z.enum(["Active", "Suspended"]);
export const BuildProviderSchema = z.enum(["GitHubActions", "CircleCI", "Namespace"]);
export const PrebuildConfigSourceSchema = z.enum(["RepositoryFile", "Default"]);
export const PrebuildStateSchema = z.enum(["Dispatched", "Building", "Converting", "Done", "Failed"]);
export const PrebuildFailurePhaseSchema = z.enum(["Dispatch", "Build", "Upload", "Conversion"]);
export const PrebuildPreviewSourceSchema = z.enum(["RepositoryFile", "Supplied"]);
export const PrebuildLifecycleCommandSchema = z.enum(["OnCreateCommand", "UpdateContentCommand", "PostCreateCommand", "PostStartCommand"]);
export const PrebuildFindingCodeSchema = z.enum(["DevcontainerInvalid", "PrebuildImageUnsupported", "PrebuildFeaturesUnsupported", "ToolchainMismatch"]);
export const ToolchainSchema = z.enum(["Node", "Rust", "Python"]);
export const PullRequestStateSchema = z.enum(["Open", "Merged", "Closed"]);
export const ConnectionKindSchema = z.enum(["GitHub", "GitHubActions", "CircleCI", "Namespace", "OpenRouter"]);
export const ConnectionStateSchema = z.enum(["NotConfigured", "NotConnected", "Connected", "Expiring", "Expired"]);
export const ConfigChangeActionSchema = z.enum(["Create", "Update", "Delete", "Rewrite"]);
export const ConfigResourceSchema = z.enum(["Persona", "SecretSet", "HarnessPin", "Host", "Trigger"]);
export const CircleCICredentialKindSchema = z.enum(["Authorized", "Pasted"]);
export const CircleCIAuthorizationStateSchema = z.enum(["AwaitingRedirect", "ChoosingOrganization", "Completed", "Failed"]);
export const CircleCIAuthorizationFailureReasonSchema = z.enum(["AuthorizationTimedOut", "AccessDenied", "CodeRefused", "NoOrganization", "ExchangeFailed"]);
export const ClaudeSetupHarnessSchema = z.enum(["ClaudeCode", "Codex"]);
export const ClaudeSetupStateSchema = z.enum(["Starting", "AwaitingCode", "Minting", "Completed", "Failed"]);
export const ClaudeSetupMemberSchema = z.enum(["CLAUDE_CODE_OAUTH_TOKEN", "CODEX_AUTH_JSON"]);
export const ClaudeSetupFailureReasonSchema = z.enum(["SetupUrlMissing", "CodeRejected", "ClaudeCodeExited", "SetupTimedOut", "TokenNotStored", "NoHostOnline", "Superseded"]);
export const GitHubInstallRefusalSchema = z.enum(["OtherTenant", "NotInstaller", "InstallerUnknown"]);
export const GuestHarnessProtocolSchema = z.enum(["ClaudeStreamJson", "PiRpc", "ShellLines", "PromptOnStdin", "CodexExecJson"]);
export const SupervisorFailureSchema = z.enum(["NotEnrolled", "ChannelStateLost", "HostRevoked", "ProtocolError", "UsageUnreadable", "GuestDriveUnwritable", "UpdateNotOnline", "ChannelUnreachable", "FrameUndelivered"]);
export const GuestTurnEndReasonSchema = z.enum(["Completed", "HarnessExited", "HarnessStartFailed", "HarnessOutOfMemory", "Cancelled", "BoxDiskFull"]);
export const GuestClaudeSetupFailureReasonSchema = z.enum(["UrlNotPrinted", "CodeRejected", "ClaudeCodeExited", "TokenNotStored", "MintTimedOut"]);
export const OpenRouterAuthorizationFailureReasonSchema = z.enum(["AuthorizationTimedOut", "NotConnected", "CodeRefused", "ExchangeFailed", "KeyNotStored"]);
export const OpenRouterAuthorizationStateSchema = z.enum(["AwaitingCallback", "Exchanging", "Completed", "Failed"]);
export const ConnectorAuthSchema = z.enum(["Static", "OAuth"]);
export const ConnectorStateSchema = z.enum(["NotConnected", "Connected", "Disconnected", "AuthorizationFailed"]);
export const ConnectorAuthorizationFailureReasonSchema = z.enum(["AuthorizationDenied", "AuthorizationExpired", "TokenExchangeFailed", "RefreshRefused"]);
export const TenantEventTypeSchema = z.enum(["TurnStarted", "TurnCompleted", "TurnFailed", "SessionIdle", "SessionStopped", "SessionFailed", "SessionArchived", "HostOnline", "HostOffline", "PrebuildDone", "PrebuildFailed", "SubscriptionPaused", "SubscriptionEnded", "TriggerStartRefused"]);
export const SubscriptionEndReasonSchema = z.enum(["SessionArchived", "SessionFailed", "Expired", "GoalMet"]);
export const SubscriptionEventTypeSchema = z.enum(["TurnStarted", "TurnCompleted", "TurnFailed", "SessionIdle", "SessionStopped", "SessionFailed", "SessionArchived", "SubscriptionPaused", "SubscriptionEnded"]);
export const SubscriptionStateSchema = z.enum(["Active", "Paused", "Ended"]);
export const WebhookDeliverySchema = z.enum(["Delivering", "Failing"]);
export const SnapshotFailureReasonSchema = z.enum(["BoxNotFound", "UpperDirectoryUnreadable", "UploadExpired", "UploadRejected", "SnapshotTimedOut", "NotAnswered"]);
export const CloseCode = { ProtocolError: 4400, BadSignature: 4401, Revoked: 4403, HeartbeatDeadline: 4408, Replaced: 4409, UnsupportedVersion: 4426 };
export const CloseCodeSchema = z.enum(CloseCode);
export const BoxTeardownFailureReasonSchema = z.enum(["BoxDirty"]);
export const HostPresenceSchema = z.enum(["Online", "Offline"]);
export const SessionDeadlineNameSchema = z.enum(["FirstLine", "Total", "Snapshot", "SnapshotAnswer", "Teardown", "TeardownAnswer", "HostOffline"]);
export const IdentityAssertionSchema = z.object({
    type: z.literal("apiKey"),
    "in": z.literal("header"),
    name: z.literal("Cf-Access-Jwt-Assertion")
});
export const SupervisorUpdateStepReportSchema = z.object({
    fromSha256: z.string().regex(/^[0-9a-f]{64}$/),
    toSha256: z.string().regex(/^[0-9a-f]{64}$/),
    releaseVersion: z.string().min(1),
    boxesRunning: z.int().min(0),
    phase: SupervisorUpdatePhaseSchema,
    at: z.string().datetime({ offset: true })
});
export const SupervisorUpdateFailureReportSchema = z.object({
    fromSha256: z.string().regex(/^[0-9a-f]{64}$/),
    toSha256: z.string().regex(/^[0-9a-f]{64}$/),
    reason: SupervisorUpdateFailureReasonSchema,
    detail: z.string(),
    outputTail: z.array(z.string()).max(20),
    failedAt: z.string().datetime({ offset: true })
});
export const SupervisorUpdateNotReportedSchema = z.object({
    state: z.literal("NotReported")
});
export const SupervisorUpdateStepReportedSchema = z.object({
    state: z.literal("Reported"),
    step: SupervisorUpdateStepReportSchema
});
export const SupervisorUpdateFailureReportedSchema = z.object({
    state: z.literal("Reported"),
    failure: SupervisorUpdateFailureReportSchema
});
export const GuestProtocolRangeSchema = z.object({
    guestProtocolOldest: z.int().min(1),
    guestProtocolVersion: z.int().min(1)
});
export const HostProtocolNotReportedSchema = z.object({
    state: z.literal("NotReported")
});
export const HostChannelProtocolReportedSchema = z.object({
    state: z.literal("Reported"),
    channelProtocolOldest: z.int().min(1),
    channelProtocolVersion: z.int().min(1)
});
export const HostGuestProtocolReportedSchema = z.object({
    state: z.literal("Reported"),
    guestProtocolOldest: z.int().min(1),
    guestProtocolVersion: z.int().min(1)
});
export const HostUsageSchema = z.object({
    boxesWarm: z.int().min(0),
    loadAverage: z.number().min(0),
    memoryAvailableMib: z.int().min(0),
    diskBudgetMib: z.int().min(0).optional(),
    diskHeldMib: z.int().min(0).optional(),
    memoryBudgetMib: z.int().min(0).optional(),
    memoryHeldMib: z.int().min(0).optional()
});
export const ReportedHostUsageSchema = z.object({
    hostId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    boxCapacity: z.int().min(1).max(256),
    boxesRunning: z.int().min(0),
    boxesWarm: z.int().min(0),
    loadAverage: z.number().min(0),
    memoryAvailableMib: z.int().min(0),
    diskBudgetMib: z.int().min(0).optional(),
    diskHeldMib: z.int().min(0).optional(),
    memoryBudgetMib: z.int().min(0).optional(),
    memoryHeldMib: z.int().min(0).optional(),
    channelProtocol: z.int(),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const TenantSchema = z.object({
    tenantId: z.string().min(1).max(64),
    name: z.string().min(1).max(100),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const PrincipalSchema = z.object({
    principalId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    email: z.string().min(3).max(320),
    role: PrincipalRoleSchema,
    createdAt: z.int(),
    updatedAt: z.int()
});
export const MembershipSchema = z.object({
    tenant: TenantSchema,
    role: PrincipalRoleSchema,
    createdAt: z.int()
});
export const InvitationSchema = z.object({
    invitationId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    email: z.string().min(3).max(320),
    role: PrincipalRoleSchema,
    expiresAt: z.string().datetime({ offset: true }),
    createdAt: z.int()
});
export const DeviceSchema = z.object({
    deviceId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    name: z.string().min(1).max(100),
    createdAt: z.int(),
    lastUsedAt: z.int()
});
export const OAuthGrantSchema = z.object({
    grantId: z.string().min(1).max(64),
    clientId: z.string(),
    clientName: z.string(),
    redirectOrigin: z.string().url(),
    lastIssuedAt: z.int()
});
export const HostSchema = z.object({
    hostId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    name: z.string().min(1).max(100),
    state: HostStateSchema,
    architecture: HostArchitectureSchema,
    cpuCount: z.int().min(1),
    memoryBytes: z.int().min(1),
    publicKey: z.string().min(1),
    supervisorVersion: z.string().min(1),
    labels: z.array(z.string().regex(/^[a-z0-9][a-z0-9._=-]{0,62}$/)),
    supervisorUpdateStep: z.discriminatedUnion("state", [SupervisorUpdateNotReportedSchema, SupervisorUpdateStepReportedSchema]),
    supervisorUpdateFailure: z.discriminatedUnion("state", [SupervisorUpdateNotReportedSchema, SupervisorUpdateFailureReportedSchema]),
    channelProtocol: z.discriminatedUnion("state", [HostProtocolNotReportedSchema, HostChannelProtocolReportedSchema]),
    guestProtocol: z.discriminatedUnion("state", [HostProtocolNotReportedSchema, HostGuestProtocolReportedSchema]),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const EnrolmentTokenSchema = z.object({
    enrolmentTokenId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    state: EnrolmentTokenStateSchema,
    expiresAt: z.string().datetime({ offset: true }),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const SessionPromptOriginSchema = z.object({
    kind: z.literal("Prompt")
});
export const SessionIssueOriginSchema = z.object({
    kind: z.literal("Issue"),
    issueNumber: z.int().min(1),
    title: z.string(),
    htmlUrl: z.string().url(),
    branch: z.string()
});
export const PersonOriginSchema = z.object({
    kind: z.literal("Person"),
    principalId: z.string().min(1).max(64)
});
export const TurnOriginSchema = z.object({
    kind: z.literal("Turn"),
    sessionId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64)
});
export const TriggerOriginSchema = z.object({
    kind: z.literal("Trigger"),
    triggerId: z.string().min(1).max(64),
    deliveryId: z.string().min(1).max(200)
});
export const TurnFullImageSchema = z.object({
    kind: z.literal("Full"),
    guestImageDigest: z.string().regex(/^[0-9a-f]{64}$/)
});
export const TurnLayeredImageSchema = z.object({
    kind: z.literal("Layered"),
    baseImageDigest: z.string().regex(/^[0-9a-f]{64}$/),
    harnessLayerDigest: z.string().regex(/^[0-9a-f]{64}$/)
});
export const OfferedTurnSchema = z.object({
    turnId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    prompt: z.string().min(1).max(100000),
    goal: z.string().min(1).max(100000).optional(),
    lineCount: z.int().min(0),
    image: z.discriminatedUnion("kind", [TurnFullImageSchema, TurnLayeredImageSchema]).optional(),
    createdAt: z.int(),
    updatedAt: z.int(),
    state: z.literal("Offered")
});
export const RunningTurnSchema = z.object({
    turnId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    prompt: z.string().min(1).max(100000),
    goal: z.string().min(1).max(100000).optional(),
    lineCount: z.int().min(0),
    image: z.discriminatedUnion("kind", [TurnFullImageSchema, TurnLayeredImageSchema]).optional(),
    createdAt: z.int(),
    updatedAt: z.int(),
    state: z.literal("Running")
});
export const CompletedTurnSchema = z.object({
    turnId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    prompt: z.string().min(1).max(100000),
    goal: z.string().min(1).max(100000).optional(),
    lineCount: z.int().min(0),
    image: z.discriminatedUnion("kind", [TurnFullImageSchema, TurnLayeredImageSchema]).optional(),
    createdAt: z.int(),
    updatedAt: z.int(),
    state: z.literal("Completed"),
    warning: z.string().min(1).optional()
});
export const FailedTurnSchema = z.object({
    turnId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    prompt: z.string().min(1).max(100000),
    goal: z.string().min(1).max(100000).optional(),
    lineCount: z.int().min(0),
    image: z.discriminatedUnion("kind", [TurnFullImageSchema, TurnLayeredImageSchema]).optional(),
    createdAt: z.int(),
    updatedAt: z.int(),
    state: z.literal("Failed"),
    reason: TurnFailureReasonSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true })
});
export const SessionPrebuildLayerStoredSchema = z.object({
    layer: z.literal("Prebuild"),
    prebuildId: z.string().min(1).max(64),
    layerDigest: z.string().regex(/^[0-9a-f]{64}$/)
});
export const SessionPrebuildLayerAbsentSchema = z.object({
    layer: z.literal("None"),
    reason: PrebuildLayerAbsenceSchema,
    detail: z.string()
});
export const SessionSchema = z.object({
    sessionId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    hostId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    personaId: z.string().min(1).max(64),
    turnTotalBudgetSeconds: z.int().min(1).max(86400),
    repository: z.string().min(1).max(500),
    origin: z.discriminatedUnion("kind", [SessionPromptOriginSchema, SessionIssueOriginSchema]),
    startedBy: z.discriminatedUnion("kind", [PersonOriginSchema, TurnOriginSchema, TriggerOriginSchema]),
    tags: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).max(16),
    harness: HarnessSchema,
    harnessVersion: z.string(),
    model: z.string().min(1).max(200),
    state: SessionStateSchema,
    lastTurnId: z.string().min(1).max(64),
    lastTurnState: TurnStateSchema,
    lastTurnAt: z.string().datetime({ offset: true }),
    lastTurn: z.discriminatedUnion("state", [OfferedTurnSchema, RunningTurnSchema, CompletedTurnSchema, FailedTurnSchema]),
    lastTurnImage: z.discriminatedUnion("kind", [TurnFullImageSchema, TurnLayeredImageSchema]).optional(),
    prebuildLayer: z.discriminatedUnion("layer", [SessionPrebuildLayerStoredSchema, SessionPrebuildLayerAbsentSchema]).optional(),
    boxRetention: BoxRetentionSchema,
    createdAt: z.int(),
    updatedAt: z.int()
});
export const SessionIssueSchema = z.object({
    sessionId: z.string().min(1).max(64),
    issueNumber: z.int().min(1),
    title: z.string(),
    htmlUrl: z.string().url(),
    branch: z.string()
});
export const TurnBaseSchema = z.object({
    turnId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    prompt: z.string().min(1).max(100000),
    goal: z.string().min(1).max(100000).optional(),
    lineCount: z.int().min(0),
    image: z.discriminatedUnion("kind", [TurnFullImageSchema, TurnLayeredImageSchema]).optional(),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const StopFailureSchema = z.object({
    stopFailureId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    reason: StopFailureReasonSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true }),
    createdAt: z.int()
});
export const SteerSchema = z.object({
    steerId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64),
    prompt: z.string().min(1).max(100000),
    state: SteerStateSchema,
    createdAt: z.int()
});
export const SteerCreateSchema = z.object({
    prompt: z.string().min(1).max(100000)
});
export const TurnFailureSchema = z.object({
    turnId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    reason: TurnFailureReasonSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true }),
    createdAt: z.int()
});
export const TranscriptLineSchema = z.object({
    sessionId: z.string().min(1).max(64),
    lineSeq: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64),
    text: z.string(),
    createdAt: z.int()
});
export const SnapshotStoredSchema = z.object({
    state: z.literal("Stored"),
    uploadedBytes: z.int().min(0)
});
export const SnapshotFailureSchema = z.object({
    state: z.literal("Failed"),
    reason: SnapshotFailureReasonSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true })
});
export const SnapshotSchema = z.object({
    snapshotId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64),
    snapshotSeq: z.int().min(0),
    storageKey: z.string().min(1).max(1000),
    outcome: z.discriminatedUnion("state", [SnapshotStoredSchema, SnapshotFailureSchema]),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const CredentialHandoverSchema = z.object({
    credentialHandoverId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64),
    hostId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    variableNames: z.array(z.string()),
    repositoryCredentialSource: RepositoryCredentialSourceSchema,
    createdAt: z.int()
});
export const FixedVariableSchema = z.object({
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    value: z.string().min(1)
});
export const ModelSupportListedSchema = z.object({
    kind: z.literal("Listed"),
    models: z.array(z.string().min(1).max(200)).min(1)
});
export const ModelSupportProviderCheckedSchema = z.object({
    kind: z.literal("ProviderChecked")
});
export const HarnessCredentialSchema = z.object({
    provider: ModelProviderSchema,
    kind: CredentialKindSchema,
    variable: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    fixed: z.array(FixedVariableSchema),
    arguments: z.array(z.string()),
    costBasis: CostBasisSchema,
    path: z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200).optional(),
    modelSupport: z.discriminatedUnion("kind", [ModelSupportListedSchema, ModelSupportProviderCheckedSchema])
});
export const NpmInstallRecipeSchema = z.object({
    kind: z.literal("Npm"),
    "package": z.string().min(1),
    packageVersion: z.string().min(1)
});
export const InstallArchiveSchema = z.object({
    architecture: HostArchitectureSchema,
    url: z.string().min(1),
    sha256: z.string().regex(/^[0-9a-f]{64}$/),
    binaryPath: z.string().min(1),
    siblingBinaryPaths: z.array(z.string())
});
export const ArchiveInstallRecipeSchema = z.object({
    kind: z.literal("Archive"),
    archives: z.array(InstallArchiveSchema).min(1),
    stripComponents: z.int().min(0)
});
export const HarnessCatalogEntrySchema = z.object({
    harness: HarnessSchema,
    harnessVersion: z.string().min(1),
    credentials: z.array(HarnessCredentialSchema).min(1),
    credentialChoice: CredentialChoiceSchema,
    personaFilePaths: z.array(z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200)),
    installRecipe: z.discriminatedUnion("kind", [NpmInstallRecipeSchema, ArchiveInstallRecipeSchema]),
    compactTranscript: z.boolean(),
    goals: z.boolean()
});
export const HarnessPinSchema = z.object({
    harness: HarnessSchema,
    harnessVersion: z.string().min(1),
    updatedAt: z.int()
});
export const EffectiveHarnessVersionSchema = z.object({
    harness: HarnessSchema,
    harnessVersion: z.string().min(1),
    pinned: z.boolean()
});
export const InlinePersonaFileReadSchema = z.object({
    source: z.literal("Inline"),
    path: z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200),
    content: z.string().max(87384),
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(0).max(262144),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const StoredPersonaFileReadSchema = z.object({
    source: z.literal("Stored"),
    path: z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200),
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(0).max(262144),
    downloadUrl: z.string().url(),
    downloadExpiresAt: z.string().datetime({ offset: true }),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const PersonaSchema = z.object({
    personaId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    name: z.string().min(1).max(100),
    turnTotalBudgetSeconds: z.int().min(1).max(86400),
    harness: HarnessSchema,
    secretSetId: z.string().min(1).max(64),
    connectorIds: z.array(z.string().min(1).max(64)),
    boxMemoryMib: z.int().min(512).max(65536).optional(),
    boxDiskMib: z.int().min(32768).max(262144).optional(),
    boxRetention: BoxRetentionSchema,
    tumpelMcp: z.boolean(),
    files: z.array(z.discriminatedUnion("source", [InlinePersonaFileReadSchema, StoredPersonaFileReadSchema])),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const InlinePersonaFileSchema = z.object({
    source: z.literal("Inline"),
    path: z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200),
    content: z.string().max(87384)
});
export const StoredPersonaFileSchema = z.object({
    source: z.literal("Stored"),
    path: z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200),
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(0).max(262144)
});
export const SecretVariableMemberSchema = z.object({
    kind: z.literal("Variable"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100)
});
export const ApiKeyMemberSchema = z.object({
    kind: z.literal("ApiKey"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema
});
export const SubscriptionTokenMemberSchema = z.object({
    kind: z.literal("SubscriptionToken"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    expiresAt: z.string().datetime({ offset: true })
});
export const CredentialFileMemberSchema = z.object({
    kind: z.literal("CredentialFile"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    expiresAt: z.string().datetime({ offset: true })
});
export const SecretVariableKeySchema = z.object({
    kind: z.literal("Variable"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    updatedAt: z.int()
});
export const ApiKeyKeySchema = z.object({
    kind: z.literal("ApiKey"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    updatedAt: z.int()
});
export const SubscriptionTokenKeySchema = z.object({
    kind: z.literal("SubscriptionToken"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    expiresAt: z.string().datetime({ offset: true }),
    updatedAt: z.int()
});
export const CredentialFileKeySchema = z.object({
    kind: z.literal("CredentialFile"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    expiresAt: z.string().datetime({ offset: true }),
    updatedAt: z.int()
});
export const SecretVariableValueSchema = z.object({
    kind: z.literal("Variable"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    value: z.string().min(1).max(10000)
});
export const ApiKeyValueSchema = z.object({
    kind: z.literal("ApiKey"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    value: z.string().min(1).max(10000)
});
export const SubscriptionTokenValueSchema = z.object({
    kind: z.literal("SubscriptionToken"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    expiresAt: z.string().datetime({ offset: true }),
    value: z.string().min(1).max(10000)
});
export const CredentialFileValueSchema = z.object({
    kind: z.literal("CredentialFile"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    expiresAt: z.string().datetime({ offset: true }),
    value: z.string().min(1).max(10000)
});
export const StoredValueChangeSchema = z.object({
    value: z.string().min(1).max(10000).optional(),
    previousName: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100).optional()
});
export const SecretVariableUpdateSchema = z.object({
    kind: z.literal("Variable"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    value: z.string().min(1).max(10000).optional(),
    previousName: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100).optional()
});
export const ApiKeyUpdateSchema = z.object({
    kind: z.literal("ApiKey"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    value: z.string().min(1).max(10000).optional(),
    previousName: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100).optional()
});
export const SubscriptionTokenUpdateSchema = z.object({
    kind: z.literal("SubscriptionToken"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    expiresAt: z.string().datetime({ offset: true }),
    value: z.string().min(1).max(10000).optional(),
    previousName: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100).optional()
});
export const CredentialFileUpdateSchema = z.object({
    kind: z.literal("CredentialFile"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    expiresAt: z.string().datetime({ offset: true }),
    value: z.string().min(1).max(10000).optional(),
    previousName: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100).optional()
});
export const SecretSetSchema = z.object({
    secretSetId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    name: z.string().min(1).max(100),
    keys: z.array(z.discriminatedUnion("kind", [SecretVariableKeySchema, ApiKeyKeySchema, SubscriptionTokenKeySchema, CredentialFileKeySchema])),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const ControlPlaneSettingsSchema = z.object({
    dispatchGrantTtlSeconds: z.int().min(1),
    snapshotDelaySeconds: z.int().min(0),
    snapshotDeadlineSeconds: z.int().min(1),
    turnOfferTtlSeconds: z.int().min(1),
    turnImageFetchBudgetSeconds: z.int().min(1),
    turnFirstLineBudgetSeconds: z.int().min(1),
    turnTotalBudgetSeconds: z.int().min(1).max(86400),
    transcriptChunkLines: z.int().min(1).max(1000),
    prebuildUploadBudgetSeconds: z.int().min(1).max(604800),
    prebuildDispatchBudgetSeconds: z.int().min(1).max(86400),
    prebuildBuildBudgetSeconds: z.int().min(1).max(86400),
    claudeSetupUrlBudgetSeconds: z.int().min(1).max(3600),
    claudeSetupCodeBudgetSeconds: z.int().min(1).max(3600),
    claudeSetupMintBudgetSeconds: z.int().min(1).max(3600),
    claudeSetupMintGraceSeconds: z.int().min(1).max(60),
    heartbeatIntervalSeconds: z.int().min(1).max(300),
    heartbeatDeadlineSeconds: z.int().min(1).max(900),
    devicePollIntervalSeconds: z.int().min(1).max(60),
    deviceSlowDownStepSeconds: z.int().min(1).max(60),
    gitHubActionsIssuer: z.string().url()
});
export const HealthSchema = z.object({
    status: HealthStatusSchema
});
export const MetricInstrumentSchema = z.object({
    metric: z.string().regex(/^[a-z][a-z0-9_]*(\.[a-z0-9_]+)*$/).max(64),
    unit: z.string().min(1),
    kind: MetricKindSchema,
    description: z.string().min(1)
});
export const SamplePointSchema = z.object({
    metric: z.string().regex(/^[a-z][a-z0-9_]*(\.[a-z0-9_]+)*$/).max(64),
    at: z.string().datetime({ offset: true }),
    value: z.number(),
    dimensions: z.record(z.string(), z.string())
});
export const TurnPointSchema = z.object({
    metric: z.string().regex(/^[a-z][a-z0-9_]*(\.[a-z0-9_]+)*$/).max(64),
    at: z.string().datetime({ offset: true }),
    value: z.number(),
    dimensions: z.record(z.string(), z.string()),
    turnId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64)
});
export const MetricBatchSchema = z.object({
    instruments: z.array(MetricInstrumentSchema),
    samples: z.array(SamplePointSchema).max(500),
    turns: z.array(TurnPointSchema).max(500)
});
export const MetricFacetValueSchema = z.object({
    value: z.string(),
    seriesCount: z.int()
});
export const MetricFacetSchema = z.object({
    dimension: z.string(),
    values: z.array(MetricFacetValueSchema)
});
export const MetricEntrySchema = z.object({
    metric: z.string().regex(/^[a-z][a-z0-9_]*(\.[a-z0-9_]+)*$/).max(64),
    unit: z.string().min(1),
    kind: MetricKindSchema,
    description: z.string().min(1),
    facets: z.array(MetricFacetSchema)
});
export const MetricCatalogSchema = z.object({
    metrics: z.array(MetricEntrySchema)
});
export const MetricPointSchema = z.object({
    bucketStart: z.string().datetime({ offset: true }),
    count: z.int(),
    sum: z.number(),
    min: z.number(),
    max: z.number(),
    p50: z.number(),
    p90: z.number(),
    p99: z.number()
});
export const MetricSeriesSchema = z.object({
    group: z.record(z.string(), z.string()),
    points: z.array(MetricPointSchema)
});
export const MetricSeriesSetSchema = z.object({
    metric: z.string().regex(/^[a-z][a-z0-9_]*(\.[a-z0-9_]+)*$/).max(64),
    unit: z.string(),
    bucket: MetricBucketSchema,
    series: z.array(MetricSeriesSchema)
});
export const MetricTurnPointSchema = z.object({
    turnId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    at: z.string().datetime({ offset: true }),
    value: z.number(),
    dimensions: z.record(z.string(), z.string())
});
export const MetricTurnPageSchema = z.object({
    points: z.array(MetricTurnPointSchema),
    cursor: z.string(),
    finished: z.boolean()
});
export const TriggerConditionSchema = z.object({
    field: z.string().regex(/^[A-Za-z0-9_\-]+(\.[A-Za-z0-9_\-]+)*$/).max(200),
    values: z.array(z.string().max(500)).min(1).max(20)
});
export const GitHubTriggerSourceSchema = z.object({
    kind: z.literal("GitHub"),
    event: GitHubTriggerEventSchema,
    conditions: z.array(TriggerConditionSchema).max(20)
});
export const TriggerSchema = z.object({
    triggerId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    name: z.string().min(1).max(100),
    source: GitHubTriggerSourceSchema,
    personaId: z.string().min(1).max(64),
    model: z.string().min(1).max(200),
    prompt: z.string().min(1).max(100000),
    principalId: z.string().min(1).max(64),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const TriggerCreateSchema = z.object({
    name: z.string().min(1).max(100),
    source: GitHubTriggerSourceSchema,
    personaId: z.string().min(1).max(64),
    model: z.string().min(1).max(200),
    prompt: z.string().min(1).max(100000)
});
export const TriggerPatchSchema = z.object({
    name: z.string().min(1).max(100).optional(),
    source: GitHubTriggerSourceSchema.optional(),
    personaId: z.string().min(1).max(64).optional(),
    model: z.string().min(1).max(200).optional(),
    prompt: z.string().min(1).max(100000).optional()
});
export const TriggerPathSchema = z.object({
    triggerId: z.string().min(1).max(64)
});
export const TriggerPayloadSchema = z.object({});
export const StoredTriggerTestSchema = z.object({
    kind: z.literal("Stored"),
    triggerId: z.string().min(1).max(64),
    payload: z.record(z.string(), z.unknown())
});
export const DraftTriggerTestSchema = z.object({
    kind: z.literal("Draft"),
    trigger: TriggerCreateSchema,
    payload: z.record(z.string(), z.unknown())
});
export const TriggerConditionVerdictSchema = z.object({
    field: z.string().regex(/^[A-Za-z0-9_\-]+(\.[A-Za-z0-9_\-]+)*$/).max(200),
    values: z.array(z.string().max(500)).min(1).max(20),
    actual: z.array(z.string()),
    holds: z.boolean()
});
export const TriggerTestResultSchema = z.object({
    matched: z.boolean(),
    conditions: z.array(TriggerConditionVerdictSchema),
    prompt: z.string(),
    missingFields: z.array(z.string().regex(/^[A-Za-z0-9_\-]+(\.[A-Za-z0-9_\-]+)*$/).max(200))
});
export const TriggerStartRefusalSchema = z.object({
    code: ProblemCodeSchema,
    detail: z.string()
});
export const ProblemSchema = z.object({
    code: ProblemCodeSchema,
    title: z.string(),
    detail: z.string(),
    fix: z.string()
});
export const ProblemResponseSchema = z.object({
    statusCode: z.union([z.literal(400), z.literal(401), z.literal(403), z.literal(404), z.literal(409), z.literal(410), z.literal(422), z.literal(429), z.literal(503)]),
    body: ProblemSchema
});
export const SessionPathSchema = z.object({
    sessionId: z.string().min(1).max(64)
});
export const TurnPathSchema = z.object({
    turnId: z.string().min(1).max(64)
});
export const HostPathSchema = z.object({
    hostId: z.string().min(1).max(64)
});
export const DevicePathSchema = z.object({
    deviceId: z.string().min(1).max(64)
});
export const EnrolmentTokenPathSchema = z.object({
    enrolmentTokenId: z.string().min(1).max(64)
});
export const OAuthGrantPathSchema = z.object({
    grantId: z.string().min(1).max(64)
});
export const SnapshotPathSchema = z.object({
    snapshotId: z.string().min(1).max(64)
});
export const PersonaPathSchema = z.object({
    personaId: z.string().min(1).max(64)
});
export const MemberPathSchema = z.object({
    principalId: z.string().min(1).max(64)
});
export const InvitationPathSchema = z.object({
    invitationId: z.string().min(1).max(64)
});
export const SecretSetPathSchema = z.object({
    secretSetId: z.string().min(1).max(64)
});
export const SecretMemberPathSchema = z.object({
    secretSetId: z.string().min(1).max(64),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100)
});
export const GitHubInstallationPathSchema = z.object({
    installationId: z.number().min(1)
});
export const GitHubRepositoryPathSchema = z.object({
    owner: z.string().regex(/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$/),
    name: z.string().regex(/^[A-Za-z0-9._-]{1,100}$/)
});
export const HarnessPathSchema = z.object({
    harness: HarnessSchema
});
export const GitHubInstallStartQuerySchema = z.object({
    returnUrl: z.string().url().optional(),
    gitHubAccountId: z.number().min(1).optional()
});
export const SignUpSchema = z.object({
    name: z.string().min(1).max(100)
});
export const WhoamiSchema = z.object({
    tenant: TenantSchema,
    principal: PrincipalSchema
});
export const WhoamiWithEndpointSchema = z.object({
    tenant: TenantSchema,
    principal: PrincipalSchema,
    endpoint: z.string().url()
});
export const OAuthErrorSchema = z.object({
    error: OAuthErrorCodeSchema,
    error_description: z.string()
});
export const OAuthErrorResponseSchema = z.object({
    statusCode: z.union([z.literal(400), z.literal(405), z.literal(429)]),
    body: OAuthErrorSchema
});
export const DeviceCodeRequestSchema = z.object({
    device_name: z.string().min(1).max(100)
});
export const DeviceAuthorizationSchema = z.object({
    device_code: z.string(),
    user_code: z.string(),
    verification_uri: z.string().url(),
    verification_uri_complete: z.string().url(),
    expires_in: z.int().min(1),
    interval: z.int().min(1)
});
export const DeviceDecisionSchema = z.object({
    userCode: z.string()
});
export const DeviceApprovalSchema = z.object({
    userCode: z.string(),
    tenantId: z.string().min(1).max(64)
});
export const InvitationCreateSchema = z.object({
    email: z.string().min(3).max(320),
    role: PrincipalRoleSchema
});
export const InvitationCreatedSchema = z.object({
    invitation: InvitationSchema,
    acceptUrl: z.string().url()
});
export const InvitationAcceptSchema = z.object({
    token: z.string().min(1)
});
export const DeviceTokenRequestSchema = z.object({
    grant_type: z.literal("urn:ietf:params:oauth:grant-type:device_code"),
    device_code: z.string()
});
export const DeviceTokenSchema = z.object({
    access_token: z.string(),
    token_type: z.literal("Bearer")
});
export const ProtectedResourceMetadataSchema = z.object({
    resource: z.string().url(),
    authorization_servers: z.array(z.string().url()),
    scopes_supported: z.array(z.string()),
    bearer_methods_supported: z.array(z.string()),
    resource_name: z.string()
});
export const AuthorizationServerMetadataSchema = z.object({
    issuer: z.string().url(),
    authorization_endpoint: z.string().url(),
    token_endpoint: z.string().url(),
    revocation_endpoint: z.string().url(),
    registration_endpoint: z.string().url(),
    scopes_supported: z.array(z.string()),
    response_types_supported: z.array(z.string()),
    response_modes_supported: z.array(z.string()),
    grant_types_supported: z.array(z.string()),
    token_endpoint_auth_methods_supported: z.array(z.string()),
    code_challenge_methods_supported: z.array(z.string()),
    authorization_response_iss_parameter_supported: z.boolean(),
    resource_indicators_supported: z.boolean()
});
export const OAuthClientRegistrationSchema = z.object({
    redirect_uris: z.array(z.string().url()).min(1).max(10),
    client_name: z.string().optional()
});
export const OAuthClientSchema = z.object({
    client_id: z.string(),
    client_id_issued_at: z.int(),
    client_name: z.string(),
    redirect_uris: z.array(z.string().url()),
    grant_types: z.array(z.string()),
    response_types: z.array(z.string()),
    token_endpoint_auth_method: z.literal("none"),
    scope: z.string()
});
export const OAuthClientRegisteredSchema = z.object({
    statusCode: z.literal(201),
    body: OAuthClientSchema
});
export const OAuthAuthorizeQuerySchema = z.object({
    response_type: z.string(),
    client_id: z.string(),
    redirect_uri: z.string().optional(),
    state: z.string().optional(),
    code_challenge: z.string(),
    code_challenge_method: z.string(),
    resource: z.string().optional()
});
export const SeeOtherSchema = z.object({
    statusCode: z.literal(303),
    location: z.string()
});
export const OAuthAuthorizationCodeRequestSchema = z.object({
    grant_type: z.literal("authorization_code"),
    client_id: z.string(),
    code: z.string(),
    code_verifier: z.string(),
    redirect_uri: z.string(),
    resource: z.string().optional()
});
export const OAuthRefreshTokenRequestSchema = z.object({
    grant_type: z.literal("refresh_token"),
    client_id: z.string(),
    refresh_token: z.string(),
    resource: z.string().optional()
});
export const OAuthTokenSchema = z.object({
    access_token: z.string(),
    token_type: z.literal("Bearer"),
    expires_in: z.int(),
    refresh_token: z.string(),
    scope: z.string()
});
export const OAuthRevocationRequestSchema = z.object({
    token: z.string(),
    client_id: z.string(),
    token_type_hint: z.string().optional()
});
export const OAuthRevokedSchema = z.object({
    statusCode: z.literal(200)
});
export const EnrolmentTokenMintSchema = z.object({
    expiresInSeconds: z.int().min(60).max(86400)
});
export const MintedEnrolmentTokenSchema = z.object({
    enrolmentToken: EnrolmentTokenSchema,
    token: z.string(),
    installCommand: z.string()
});
export const HostEnrolSchema = z.object({
    name: z.string().min(1).max(100),
    architecture: HostArchitectureSchema,
    cpuCount: z.int().min(1),
    memoryBytes: z.int().min(1),
    publicKey: z.string().min(1),
    supervisorVersion: z.string().min(1),
    enrolmentToken: z.string().min(1)
});
export const HostLabelsSchema = z.object({
    labels: z.array(z.string().regex(/^[a-z0-9][a-z0-9._=-]{0,62}$/))
});
export const HostLabelsPatchSchema = z.object({
    add: z.array(z.string().regex(/^[a-z0-9][a-z0-9._=-]{0,62}$/)).optional(),
    remove: z.array(z.string().regex(/^[a-z0-9][a-z0-9._=-]{0,62}$/)).optional()
});
export const SessionStartSchema = z.object({
    personaId: z.string().min(1).max(64),
    repository: z.string().min(1).max(500),
    model: z.string().min(1).max(200),
    turnTotalBudgetSeconds: z.int().min(1).max(86400).optional(),
    prompt: z.string().min(1).max(100000),
    boxRetention: BoxRetentionSchema.optional(),
    tags: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).max(16).optional()
});
export const SessionStartFromIssueSchema = z.object({
    turnTotalBudgetSeconds: z.int().min(1).max(86400).optional(),
    personaId: z.string().min(1).max(64),
    owner: z.string().regex(/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$/),
    name: z.string().regex(/^[A-Za-z0-9._-]{1,100}$/),
    issueNumber: z.int().min(1),
    model: z.string().min(1).max(200),
    boxRetention: BoxRetentionSchema.optional(),
    tags: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).max(16).optional()
});
export const SessionTagsSchema = z.object({
    tags: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).max(16)
});
export const SessionTagsPatchSchema = z.object({
    add: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).optional(),
    remove: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).optional()
});
export const StartedSessionSchema = z.object({
    session: SessionSchema,
    turn: z.discriminatedUnion("state", [OfferedTurnSchema, RunningTurnSchema, CompletedTurnSchema, FailedTurnSchema])
});
export const StartedSessionFromIssueSchema = z.object({
    session: SessionSchema,
    turn: z.discriminatedUnion("state", [OfferedTurnSchema, RunningTurnSchema, CompletedTurnSchema, FailedTurnSchema]),
    issue: SessionIssueSchema
});
export const SessionListQuerySchema = z.object({
    state: SessionStateSchema.optional(),
    hostId: z.string().min(1).max(64).optional(),
    lastTurnBefore: z.string().datetime({ offset: true }).optional(),
    tag: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).max(16).optional(),
    triggerId: z.string().min(1).max(64).optional()
});
export const SessionStopQuerySchema = z.object({
    cancelTurn: z.boolean().optional()
});
export const TurnSendSchema = z.object({
    prompt: z.string().min(1).max(100000),
    goal: z.string().min(1).max(100000).optional()
});
export const MetricWindowSchema = z.object({
    from: z.string().datetime({ offset: true }),
    to: z.string().datetime({ offset: true }),
    filter: z.array(z.string()).optional()
});
export const MetricPathSchema = z.object({
    metric: z.string().regex(/^[a-z][a-z0-9_]*(\.[a-z0-9_]+)*$/).max(64)
});
export const MetricSeriesQuerySchema = z.object({
    from: z.string().datetime({ offset: true }),
    to: z.string().datetime({ offset: true }),
    filter: z.array(z.string()).optional(),
    bucket: MetricBucketSchema,
    groupBy: z.array(z.string()).max(2).optional()
});
export const MetricTurnQuerySchema = z.object({
    from: z.string().datetime({ offset: true }),
    to: z.string().datetime({ offset: true }),
    filter: z.array(z.string()).optional(),
    sessionId: z.string().min(1).max(64).optional(),
    cursor: z.string().optional()
});
export const TurnWaitQuerySchema = z.object({
    turnId: z.array(z.string().min(1).max(64)).min(1).max(50),
    timeoutSeconds: z.number().min(0).max(50)
});
export const TranscriptQuerySchema = z.object({
    after: z.number().min(0).optional(),
    turnId: z.string().min(1).max(64).optional(),
    limit: z.number().min(1).max(1000).optional(),
    maxBytes: z.number().min(1).max(1048576).optional(),
    compact: z.boolean().optional()
});
export const RawTranscriptPageSchema = z.object({
    form: z.literal("Raw"),
    sessionState: SessionStateSchema,
    lines: z.array(TranscriptLineSchema),
    cursor: z.int().min(0),
    finished: z.boolean()
});
export const CompactTranscriptLineSchema = z.object({
    lineSeq: z.int().min(0),
    text: z.string()
});
export const CompactTranscriptTurnSchema = z.object({
    turnId: z.string().min(1).max(64),
    lines: z.array(CompactTranscriptLineSchema)
});
export const CompactTranscriptPageSchema = z.object({
    form: z.literal("Compact"),
    sessionId: z.string().min(1).max(64),
    sessionState: SessionStateSchema,
    turns: z.array(CompactTranscriptTurnSchema),
    cursor: z.int().min(0),
    finished: z.boolean()
});
export const PersonaCreateSchema = z.object({
    name: z.string().min(1).max(100),
    harness: HarnessSchema,
    secretSetId: z.string().min(1).max(64),
    connectorIds: z.array(z.string().min(1).max(64)),
    boxMemoryMib: z.int().min(512).max(65536).optional(),
    boxDiskMib: z.int().min(32768).max(262144).optional(),
    turnTotalBudgetSeconds: z.int().min(1).max(86400).optional(),
    files: z.array(z.discriminatedUnion("source", [InlinePersonaFileSchema, StoredPersonaFileSchema])).optional(),
    boxRetention: BoxRetentionSchema.optional(),
    tumpelMcp: z.boolean().optional()
});
export const PersonaUpdateSchema = z.object({
    name: z.string().min(1).max(100),
    secretSetId: z.string().min(1).max(64),
    connectorIds: z.array(z.string().min(1).max(64)),
    boxMemoryMib: z.int().min(512).max(65536).optional(),
    boxDiskMib: z.int().min(32768).max(262144).optional(),
    turnTotalBudgetSeconds: z.int().min(1).max(86400).optional(),
    files: z.array(z.discriminatedUnion("source", [InlinePersonaFileSchema, StoredPersonaFileSchema])),
    boxRetention: BoxRetentionSchema.optional(),
    tumpelMcp: z.boolean().optional()
});
export const PersonaPatchSchema = z.object({
    name: z.string().min(1).max(100).optional(),
    secretSetId: z.string().min(1).max(64).optional(),
    connectorIds: z.array(z.string().min(1).max(64)).optional(),
    boxMemoryMib: z.int().min(512).max(65536).optional(),
    boxDiskMib: z.int().min(32768).max(262144).optional(),
    turnTotalBudgetSeconds: z.int().min(1).max(86400).optional(),
    boxRetention: BoxRetentionSchema.optional(),
    tumpelMcp: z.boolean().optional()
});
export const PutPersonaFilePatchSchema = z.object({
    kind: z.literal("Put"),
    file: z.discriminatedUnion("source", [InlinePersonaFileSchema, StoredPersonaFileSchema])
});
export const RemovePersonaFilePatchSchema = z.object({
    kind: z.literal("Remove"),
    path: z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200)
});
export const EditPersonaFilePatchSchema = z.object({
    kind: z.literal("Edit"),
    path: z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200),
    oldText: z.string().min(1),
    newText: z.string()
});
export const PersonaFileUploadRequestSchema = z.object({
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(0).max(262144)
});
export const PersonaFileUploadSchema = z.object({
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(0).max(262144),
    uploadUrl: z.string().url(),
    uploadExpiresAt: z.string().datetime({ offset: true })
});
export const HarnessPinCreateSchema = z.object({
    harness: HarnessSchema,
    harnessVersion: z.string().min(1)
});
export const SecretSetCreateSchema = z.object({
    name: z.string().min(1).max(100),
    secrets: z.array(z.discriminatedUnion("kind", [SecretVariableValueSchema, ApiKeyValueSchema, SubscriptionTokenValueSchema, CredentialFileValueSchema]))
});
export const SecretSetUpdateSchema = z.object({
    name: z.string().min(1).max(100),
    secrets: z.array(z.discriminatedUnion("kind", [SecretVariableUpdateSchema, ApiKeyUpdateSchema, SubscriptionTokenUpdateSchema, CredentialFileUpdateSchema]))
});
export const SecretSetPatchSchema = z.object({
    name: z.string().min(1).max(100).optional(),
    secrets: z.array(z.discriminatedUnion("kind", [SecretVariableUpdateSchema, ApiKeyUpdateSchema, SubscriptionTokenUpdateSchema, CredentialFileUpdateSchema])).optional()
});
export const OpenIdConfigurationSchema = z.object({
    issuer: z.string().url(),
    jwks_uri: z.string().url(),
    response_types_supported: z.array(z.literal("id_token")),
    subject_types_supported: z.array(z.literal("public")),
    id_token_signing_alg_values_supported: z.array(z.literal("RS256")),
    scopes_supported: z.array(z.literal("openid")),
    claims_supported: z.array(z.union([z.literal("iss"), z.literal("sub"), z.literal("aud"), z.literal("iat"), z.literal("nbf"), z.literal("exp"), z.literal("jti")]))
});
export const IssuerJwkSchema = z.object({
    kty: z.literal("RSA"),
    use: z.literal("sig"),
    alg: z.literal("RS256"),
    kid: z.string().regex(/^[A-Za-z0-9_-]{43}$/),
    n: z.string().min(1),
    e: z.string().min(1)
});
export const IssuerJwksSchema = z.object({
    keys: z.array(IssuerJwkSchema)
});
export const ReleaseSupervisorSchema = z.object({
    architecture: HostArchitectureSchema,
    sha256: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(1),
    supervisorVersion: z.string().min(1),
    downloadUrl: z.string().url(),
    guestProtocolVersion: z.int().min(1)
});
export const ReleaseCliSchema = z.object({
    architecture: HostArchitectureSchema,
    sha256: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(1),
    cliVersion: z.string().min(1),
    downloadUrl: z.string().url()
});
export const ReleaseImageSchema = z.object({
    harness: ImageHarnessSchema,
    harnessVersion: z.string().min(1),
    architecture: HostArchitectureSchema,
    imageDigest: z.string().regex(/^[0-9a-f]{64}$/),
    kernelDigest: z.string().regex(/^[0-9a-f]{64}$/),
    manifestDigest: z.string().regex(/^[0-9a-f]{64}$/),
    ociDigest: z.string().regex(/^[0-9a-f]{64}$/),
    rootfsDigest: z.string().regex(/^[0-9a-f]{64}$/)
});
export const ReleaseHarnessLayerSchema = z.object({
    harness: ImageHarnessSchema,
    harnessVersion: z.string().min(1),
    architecture: HostArchitectureSchema,
    layerDigest: z.string().regex(/^[0-9a-f]{64}$/),
    manifestDigest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(1)
});
export const ReleaseBaseImageSchema = z.object({
    architecture: HostArchitectureSchema,
    imageDigest: z.string().regex(/^[0-9a-f]{64}$/),
    kernelDigest: z.string().regex(/^[0-9a-f]{64}$/),
    manifestDigest: z.string().regex(/^[0-9a-f]{64}$/),
    ociDigest: z.string().regex(/^[0-9a-f]{64}$/),
    rootfsDigest: z.string().regex(/^[0-9a-f]{64}$/)
});
export const ReleaseManifestSchema = z.object({
    releaseVersion: z.string().min(1),
    commit: z.string().regex(/^[0-9a-f]{40}$/),
    channelProtocolVersion: z.int().min(1),
    supervisors: z.array(ReleaseSupervisorSchema).min(1),
    clis: z.array(ReleaseCliSchema).min(1),
    images: z.array(ReleaseImageSchema),
    harnessLayers: z.array(ReleaseHarnessLayerSchema).min(1),
    bases: z.array(ReleaseBaseImageSchema).min(1),
    rollback: z.boolean().optional()
});
export const ReleaseSupervisorPathSchema = z.object({
    architecture: HostArchitectureSchema
});
export const SupervisorDownloadSchema = z.object({
    statusCode: z.literal(302),
    location: z.string()
});
export const ReleaseCliPathSchema = z.object({
    architecture: HostArchitectureSchema
});
export const CliDownloadSchema = z.object({
    statusCode: z.literal(302),
    location: z.string()
});
export const CliInstallScriptSchema = z.object({
    contentType: z.literal("text/plain"),
    script: z.string()
});
export const RolloutHostSchema = z.object({
    hostId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    runningTurns: z.int().min(0)
});
export const RolloutChannelProtocolSchema = z.object({
    channelProtocolVersion: z.int().min(1),
    hostCount: z.int().min(1)
});
export const ReleaseRolloutSchema = z.object({
    deployedCommit: z.string().regex(/^[0-9a-f]{40}$/),
    drained: z.boolean(),
    hosts: z.array(RolloutHostSchema),
    channelProtocols: z.array(RolloutChannelProtocolSchema)
});
export const DeployDrainTokenSchema = z.object({
    type: z.literal("http"),
    scheme: z.literal("Bearer")
});
export const GitHubAppReadySchema = z.object({
    state: z.literal("Ready"),
    appSlug: z.string()
});
export const GitHubAppMissingSchema = z.object({
    state: z.literal("AppMissing"),
    setupUrl: z.string().url()
});
export const GitHubConnectionSchema = z.object({
    tenantId: z.string().min(1).max(64),
    app: z.discriminatedUnion("state", [GitHubAppReadySchema, GitHubAppMissingSchema])
});
export const GitHubInstallationSchema = z.object({
    installationId: z.int().min(1),
    tenantId: z.string().min(1).max(64),
    accountLogin: z.string().regex(/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$/),
    accountType: GitHubAccountTypeSchema,
    status: GitHubInstallationStatusSchema,
    createdAt: z.int(),
    updatedAt: z.int()
});
export const GitHubInstallStartSchema = z.object({
    installUrl: z.string().url(),
    expiresAt: z.string().datetime({ offset: true })
});
export const GitHubRepositorySchema = z.object({
    owner: z.string().regex(/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$/),
    name: z.string().regex(/^[A-Za-z0-9._-]{1,100}$/),
    defaultBranch: z.string(),
    "private": z.boolean(),
    htmlUrl: z.string().url()
});
export const GitHubIssueSchema = z.object({
    issueNumber: z.int().min(1),
    title: z.string(),
    htmlUrl: z.string().url(),
    labels: z.array(z.string()),
    updatedAt: z.string().datetime({ offset: true })
});
export const PrebuildStartSchema = z.object({
    repository: z.string().min(1).max(500),
    personaId: z.string().min(1).max(64),
    provider: BuildProviderSchema,
    rebuild: z.boolean().optional()
});
export const PrebuildDispatchedSchema = z.object({
    state: z.literal("Dispatched")
});
export const PrebuildBuildingSchema = z.object({
    state: z.literal("Building")
});
export const PrebuildConvertingSchema = z.object({
    state: z.literal("Converting"),
    layerDigest: z.string().regex(/^[0-9a-f]{64}$/),
    layerSizeBytes: z.int().min(1),
    uploadedAt: z.string().datetime({ offset: true })
});
export const PrebuildDoneSchema = z.object({
    state: z.literal("Done"),
    layerDigest: z.string().regex(/^[0-9a-f]{64}$/),
    layerSizeBytes: z.int().min(0),
    finishedAt: z.string().datetime({ offset: true })
});
export const PrebuildFailedSchema = z.object({
    state: z.literal("Failed"),
    phase: PrebuildFailurePhaseSchema,
    finishedAt: z.string().datetime({ offset: true })
});
export const PrebuildSchema = z.object({
    prebuildId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    personaId: z.string().min(1).max(64),
    repository: z.string().min(1).max(500),
    inputDigest: z.string().regex(/^[0-9a-f]{64}$/),
    guestImageDigest: z.string().regex(/^[0-9a-f]{64}$/),
    provider: BuildProviderSchema,
    configSource: PrebuildConfigSourceSchema,
    status: z.discriminatedUnion("state", [PrebuildDispatchedSchema, PrebuildBuildingSchema, PrebuildConvertingSchema, PrebuildDoneSchema, PrebuildFailedSchema]),
    startedAt: z.string().datetime({ offset: true }),
    logUrl: z.string().url(),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const PrebuildListQuerySchema = z.object({
    repository: z.string().min(1).max(500).optional()
});
export const PrebuildPreviewOfRepositorySchema = z.object({
    source: z.literal("RepositoryFile"),
    repository: z.string().min(1).max(500),
    personaId: z.string().min(1).max(64)
});
export const PrebuildPreviewOfSuppliedSchema = z.object({
    source: z.literal("Supplied"),
    repository: z.string().min(1).max(500),
    personaId: z.string().min(1).max(64),
    devcontainer: z.string().max(65536)
});
export const PrebuildPreviewCommandSchema = z.object({
    lifecycle: PrebuildLifecycleCommandSchema,
    label: z.string(),
    argv: z.array(z.string())
});
export const PrebuildFindingSchema = z.object({
    code: PrebuildFindingCodeSchema,
    field: z.string(),
    detail: z.string(),
    fix: z.string()
});
export const PrebuildPreviewSchema = z.object({
    repository: z.string().min(1).max(500),
    configSource: PrebuildPreviewSourceSchema,
    commands: z.array(PrebuildPreviewCommandSchema),
    containerEnv: z.record(z.string(), z.string()),
    inputDigest: z.string().regex(/^[0-9a-f]{64}$/),
    findings: z.array(PrebuildFindingSchema)
});
export const PrebuildPathSchema = z.object({
    prebuildId: z.string().min(1).max(64)
});
export const PrebuildFailureSchema = z.object({
    prebuildId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    phase: PrebuildFailurePhaseSchema,
    detail: z.string(),
    fix: z.string(),
    createdAt: z.int()
});
export const PrebuildTemplateToolchainSchema = z.object({
    toolchain: ToolchainSchema,
    toolchainVersion: z.string().min(1)
});
export const PrebuildTemplateVersionSummarySchema = z.object({
    prebuildTemplateVersion: z.int().min(1),
    summary: z.string().min(1),
    installs: z.array(z.string()),
    toolchains: z.array(PrebuildTemplateToolchainSchema),
    digest: z.string().regex(/^[0-9a-f]{64}$/)
});
export const PrebuildTemplateSchema = z.object({
    prebuildTemplateId: z.string().regex(/^[a-z][a-z0-9-]{0,39}$/),
    versions: z.array(PrebuildTemplateVersionSummarySchema)
});
export const PrebuildTemplateManifestSchema = z.object({
    summary: z.string().min(1),
    installs: z.array(z.string()),
    toolchains: z.array(PrebuildTemplateToolchainSchema)
});
export const PrebuildTemplateVersionPathSchema = z.object({
    prebuildTemplateId: z.string().regex(/^[a-z][a-z0-9-]{0,39}$/),
    prebuildTemplateVersion: z.number().min(1)
});
export const PrebuildTemplateVersionSchema = z.object({
    prebuildTemplateId: z.string().regex(/^[a-z][a-z0-9-]{0,39}$/),
    prebuildTemplateVersion: z.int().min(1),
    summary: z.string().min(1),
    installs: z.array(z.string()),
    toolchains: z.array(PrebuildTemplateToolchainSchema),
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    devcontainer: z.string()
});
export const PrebuildTemplatePullRequestOpenSchema = z.object({
    repository: z.string().min(1).max(500),
    prebuildTemplateId: z.string().regex(/^[a-z][a-z0-9-]{0,39}$/),
    prebuildTemplateVersion: z.int().min(1),
    replace: z.boolean()
});
export const PrebuildTemplatePullRequestSchema = z.object({
    repository: z.string().min(1).max(500),
    branch: z.string(),
    pullRequestNumber: z.int().min(1),
    url: z.string().url(),
    state: PullRequestStateSchema
});
export const PrebuildTemplatePullRequestQuerySchema = z.object({
    repository: z.string().min(1).max(500)
});
export const PrebuildJobInputsSchema = z.object({
    prebuildId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    rootfsUrl: z.string().url(),
    imageDigest: z.string().regex(/^[0-9a-f]{64}$/)
});
export const ProviderJobTokenSchema = z.object({
    type: z.literal("http"),
    scheme: z.literal("Bearer")
});
export const PrebuildUploadStartSchema = z.object({
    tenantId: z.string().min(1).max(64),
    layerDigest: z.string().regex(/^[0-9a-f]{64}$/),
    layerSizeBytes: z.int().min(1).max(5368709120)
});
export const PrebuildUploadGrantSchema = z.object({
    prebuildId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sha256: z.string().regex(/^[0-9a-f]{64}$/),
    url: z.string().url(),
    uploadExpiresAt: z.string().datetime({ offset: true })
});
export const PrebuildUploadCompleteSchema = z.object({
    tenantId: z.string().min(1).max(64)
});
export const ConnectedConnectionSchema = z.object({
    kind: ConnectionKindSchema,
    state: z.literal("Connected"),
    account: z.string()
});
export const ExpiringConnectionSchema = z.object({
    kind: ConnectionKindSchema,
    state: z.literal("Expiring"),
    account: z.string(),
    expiresAt: z.string().datetime({ offset: true })
});
export const ExpiredConnectionSchema = z.object({
    kind: ConnectionKindSchema,
    state: z.literal("Expired"),
    account: z.string(),
    expiredAt: z.string().datetime({ offset: true })
});
export const NotConnectedConnectionSchema = z.object({
    kind: ConnectionKindSchema,
    state: z.literal("NotConnected")
});
export const NotConfiguredConnectionSchema = z.object({
    kind: ConnectionKindSchema,
    state: z.literal("NotConfigured")
});
export const ConfigPersonaFileSchema = z.object({
    path: z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200),
    from: z.string().min(1).max(1000)
});
export const ConfigPersonaSchema = z.object({
    name: z.string().min(1).max(100),
    harness: HarnessSchema,
    boxMemoryMib: z.int().min(512).max(65536).optional(),
    boxDiskMib: z.int().min(32768).max(262144).optional(),
    turnTotalBudgetSeconds: z.int().min(1).max(86400).optional(),
    boxRetention: BoxRetentionSchema.optional(),
    tumpelMcp: z.boolean().optional(),
    secretSetName: z.string().min(1).max(100),
    connectorNames: z.array(z.string().min(1).max(100)),
    files: z.array(ConfigPersonaFileSchema)
});
export const SecretValueSourceSchema = z.object({
    env: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(200)
});
export const ConfigSecretVariableSchema = z.object({
    kind: z.literal("Variable"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    valueFrom: SecretValueSourceSchema
});
export const ConfigApiKeySchema = z.object({
    kind: z.literal("ApiKey"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    valueFrom: SecretValueSourceSchema
});
export const ConfigSubscriptionTokenSchema = z.object({
    kind: z.literal("SubscriptionToken"),
    name: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(100),
    provider: ModelProviderSchema,
    expiresAt: z.union([z.string().datetime({ offset: true }), SecretValueSourceSchema]),
    valueFrom: SecretValueSourceSchema
});
export const ConfigSecretSetSchema = z.object({
    name: z.string().min(1).max(100),
    secrets: z.array(z.discriminatedUnion("kind", [ConfigSecretVariableSchema, ConfigApiKeySchema, ConfigSubscriptionTokenSchema]))
});
export const ConfigHostSchema = z.object({
    hostId: z.string().min(1).max(64),
    labels: z.array(z.string().regex(/^[a-z0-9][a-z0-9._=-]{0,62}$/))
});
export const ConfigTriggerSchema = z.object({
    name: z.string().min(1).max(100),
    source: GitHubTriggerSourceSchema,
    model: z.string().min(1).max(200),
    prompt: z.string().min(1).max(100000),
    personaName: z.string().min(1).max(100)
});
export const TenantConfigSchema = z.object({
    $schema: z.string().url().optional(),
    personas: z.array(ConfigPersonaSchema),
    secretSets: z.array(ConfigSecretSetSchema),
    harnessPins: z.array(HarnessPinCreateSchema),
    hosts: z.array(ConfigHostSchema),
    triggers: z.array(ConfigTriggerSchema).optional()
});
export const ConfigFileDigestSchema = z.object({
    from: z.string().min(1).max(1000),
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(0).max(262144)
});
export const ConfigExpiryValueSchema = z.object({
    env: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(200),
    expiresAt: z.string().datetime({ offset: true })
});
export const TenantConfigPlanRequestSchema = z.object({
    config: TenantConfigSchema,
    files: z.array(ConfigFileDigestSchema),
    expiryValues: z.array(ConfigExpiryValueSchema),
    secretValues: z.array(SecretValueSourceSchema)
});
export const ConfigChangeSchema = z.object({
    action: ConfigChangeActionSchema,
    resource: ConfigResourceSchema,
    name: z.string(),
    description: z.string()
});
export const ConfigPlanSchema = z.object({
    changes: z.array(ConfigChangeSchema)
});
export const InlineConfigFileSchema = z.object({
    source: z.literal("Inline"),
    from: z.string().min(1).max(1000),
    content: z.string().max(87384)
});
export const StoredConfigFileSchema = z.object({
    source: z.literal("Stored"),
    from: z.string().min(1).max(1000),
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(0).max(262144)
});
export const ConfigSecretValueSchema = z.object({
    env: z.string().regex(/^[A-Z_][A-Z0-9_]*$/).max(200),
    value: z.string().min(1).max(10000)
});
export const TenantConfigApplySchema = z.object({
    config: TenantConfigSchema,
    files: z.array(z.discriminatedUnion("source", [InlineConfigFileSchema, StoredConfigFileSchema])),
    secretValues: z.array(ConfigSecretValueSchema),
    expiryValues: z.array(ConfigExpiryValueSchema)
});
export const GitHubActionsConnectionSchema = z.object({
    gitHubActionsConnectionId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    accountLabel: z.string().min(1).max(100),
    callerWorkflow: z.string().regex(/^\.github\/workflows\/[A-Za-z0-9._-]+\.ya?ml$/).max(200),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const GitHubActionsConnectedSchema = z.object({
    state: z.literal("Connected"),
    connection: GitHubActionsConnectionSchema
});
export const GitHubActionsNotConnectedSchema = z.object({
    state: z.literal("NotConnected")
});
export const GitHubActionsConnectionLinkSchema = z.object({
    tenantId: z.string().min(1).max(64),
    link: z.discriminatedUnion("state", [GitHubActionsConnectedSchema, GitHubActionsNotConnectedSchema]),
    reusableWorkflow: z.string(),
    callerWorkflowExample: z.string()
});
export const GitHubActionsConnectionStartSchema = z.object({
    accountLabel: z.string().min(1).max(100),
    callerWorkflow: z.string().regex(/^\.github\/workflows\/[A-Za-z0-9._-]+\.ya?ml$/).max(200)
});
export const NamespaceConnectionSchema = z.object({
    namespaceConnectionId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    accountLabel: z.string().min(1).max(100),
    workspaceId: z.string().regex(/^tenant_[A-Za-z0-9]+$/).max(100),
    issuer: z.string().url(),
    subjectPattern: z.string(),
    audience: z.string().min(1).max(500),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const NamespaceConnectedSchema = z.object({
    state: z.literal("Connected"),
    connection: NamespaceConnectionSchema
});
export const NamespaceNotConnectedSchema = z.object({
    state: z.literal("NotConnected"),
    issuer: z.string().url(),
    subjectPattern: z.string(),
    audience: z.string().min(1).max(500)
});
export const NamespaceNotConfiguredSchema = z.object({
    state: z.literal("NotConfigured"),
    detail: z.string(),
    fix: z.string()
});
export const NamespaceConnectionLinkSchema = z.object({
    tenantId: z.string().min(1).max(64),
    link: z.discriminatedUnion("state", [NamespaceConnectedSchema, NamespaceNotConnectedSchema, NamespaceNotConfiguredSchema])
});
export const NamespaceConnectionStartSchema = z.object({
    accountLabel: z.string().min(1).max(100),
    workspaceId: z.string().regex(/^tenant_[A-Za-z0-9]+$/).max(100)
});
export const CircleCIAuthorizedCredentialSchema = z.object({
    kind: z.literal("Authorized"),
    expiresAt: z.string().datetime({ offset: true })
});
export const CircleCIPastedCredentialSchema = z.object({
    kind: z.literal("Pasted")
});
export const CircleCIConnectionSchema = z.object({
    circleCIConnectionId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    accountLabel: z.string().min(1).max(100),
    organizationId: z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/),
    issuer: z.string().url(),
    credential: z.discriminatedUnion("kind", [CircleCIAuthorizedCredentialSchema, CircleCIPastedCredentialSchema]),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const CircleCIConnectedSchema = z.object({
    state: z.literal("Connected"),
    connection: CircleCIConnectionSchema
});
export const CircleCINotConnectedSchema = z.object({
    state: z.literal("NotConnected")
});
export const CircleCIConnectionLinkSchema = z.object({
    tenantId: z.string().min(1).max(64),
    link: z.discriminatedUnion("state", [CircleCIConnectedSchema, CircleCINotConnectedSchema]),
    orb: z.string(),
    configExample: z.string()
});
export const CircleCIConnectionStartSchema = z.object({
    accountLabel: z.string().min(1).max(100),
    organizationId: z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/),
    apiToken: z.string().min(1).max(10000)
});
export const CircleCIAuthorizationAwaitingRedirectSchema = z.object({
    state: z.literal("AwaitingRedirect"),
    authorizeUrl: z.string().url(),
    redirectUri: z.string().url(),
    redirectDueAt: z.string().datetime({ offset: true })
});
export const CircleCIOrganizationSchema = z.object({
    organizationId: z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/),
    name: z.string().min(1).max(100),
    slug: z.string()
});
export const CircleCIAuthorizationChoosingOrganizationSchema = z.object({
    state: z.literal("ChoosingOrganization"),
    organizations: z.array(CircleCIOrganizationSchema),
    chooseDueAt: z.string().datetime({ offset: true })
});
export const CircleCIAuthorizationCompletedSchema = z.object({
    state: z.literal("Completed"),
    organizationId: z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/),
    accountLabel: z.string().min(1).max(100),
    expiresAt: z.string().datetime({ offset: true }),
    completedAt: z.string().datetime({ offset: true })
});
export const CircleCIAuthorizationFailedSchema = z.object({
    state: z.literal("Failed"),
    reason: CircleCIAuthorizationFailureReasonSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true })
});
export const CircleCIAuthorizationSchema = z.object({
    circleCIAuthorizationId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    status: z.discriminatedUnion("state", [CircleCIAuthorizationAwaitingRedirectSchema, CircleCIAuthorizationChoosingOrganizationSchema, CircleCIAuthorizationCompletedSchema, CircleCIAuthorizationFailedSchema]),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const CircleCIAuthorizationCompleteSchema = z.object({
    circleCIAuthorizationId: z.string().min(1).max(64),
    redirectedUrl: z.string().min(1).max(4000)
});
export const CircleCIAuthorizationChooseSchema = z.object({
    circleCIAuthorizationId: z.string().min(1).max(64),
    organizationId: z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/)
});
export const CircleCIProjectSchema = z.object({
    circleCIProjectId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    repository: z.string().min(1).max(500),
    projectSlug: z.string().regex(/^(gh|github|circleci)\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/).max(200),
    projectId: z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/),
    pipelineDefinitionId: z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const CircleCIProjectAddSchema = z.object({
    repository: z.string().min(1).max(500),
    projectSlug: z.string().regex(/^(gh|github|circleci)\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/).max(200),
    pipelineDefinitionId: z.string().regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/)
});
export const CircleCIProjectPathSchema = z.object({
    circleCIProjectId: z.string().min(1).max(64)
});
export const ClaudeSetupStartSchema = z.object({
    secretSetId: z.string().min(1).max(64),
    harness: ClaudeSetupHarnessSchema.optional()
});
export const ClaudeSetupStartingSchema = z.object({
    state: z.literal("Starting"),
    urlDueAt: z.string().datetime({ offset: true })
});
export const ClaudeSetupAwaitingCodeSchema = z.object({
    state: z.literal("AwaitingCode"),
    signInUrl: z.string().url(),
    userCode: z.string().min(1).max(64).optional(),
    codeDueAt: z.string().datetime({ offset: true })
});
export const ClaudeSetupMintingSchema = z.object({
    state: z.literal("Minting"),
    tokenDueAt: z.string().datetime({ offset: true })
});
export const ClaudeSetupCompletedSchema = z.object({
    state: z.literal("Completed"),
    memberName: ClaudeSetupMemberSchema,
    expiresAt: z.string().datetime({ offset: true }),
    completedAt: z.string().datetime({ offset: true })
});
export const ClaudeSetupFailedSchema = z.object({
    state: z.literal("Failed"),
    reason: ClaudeSetupFailureReasonSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true })
});
export const ClaudeSetupSchema = z.object({
    claudeSetupId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    secretSetId: z.string().min(1).max(64),
    hostId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    harness: ClaudeSetupHarnessSchema,
    harnessVersion: z.string().min(1),
    status: z.discriminatedUnion("state", [ClaudeSetupStartingSchema, ClaudeSetupAwaitingCodeSchema, ClaudeSetupMintingSchema, ClaudeSetupCompletedSchema, ClaudeSetupFailedSchema]),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const ClaudeSetupListQuerySchema = z.object({
    secretSetId: z.string().min(1).max(64)
});
export const ClaudeSetupPathSchema = z.object({
    claudeSetupId: z.string().min(1).max(64)
});
export const ClaudeSetupCodeSubmitSchema = z.object({
    code: z.string().min(1).max(2000)
});
export const ClaudeSetupTokenWriteSchema = z.object({
    tenantId: z.string().min(1).max(64),
    value: z.string().min(1).max(10000),
    expiresAt: z.string().datetime({ offset: true }).optional()
});
export const ClaudeSetupBoxTokenSchema = z.object({
    type: z.literal("http"),
    scheme: z.literal("Bearer")
});
export const SupervisorReleaseBinarySchema = z.object({
    architecture: HostArchitectureSchema,
    sha256: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(1)
});
export const SupervisorReleaseSchema = z.object({
    supervisorVersion: z.string().regex(/^[0-9]+\.[0-9]+\.[0-9]+(-rc\.[0-9]+)?$/),
    tumpelApiVersion: z.string().regex(/^[0-9]+\.[0-9]+\.[0-9]+(-rc\.[0-9]+)?$/),
    channelProtocolOldest: z.int().min(1),
    channelProtocolVersion: z.int().min(1),
    guestProtocolOldest: z.int().min(1),
    guestProtocolVersion: z.int().min(1),
    binaries: z.array(SupervisorReleaseBinarySchema).min(1)
});
export const GuestImageComponentSchema = z.object({
    name: z.string().min(1),
    version: z.string().min(1),
    url: z.string().url(),
    digest: z.string().regex(/^[0-9a-f]{64}$/)
});
export const BaseImageManifestSchema = z.object({
    imageDigest: z.string().regex(/^[0-9a-f]{64}$/),
    kernelUrl: z.string().url(),
    kernelDigest: z.string().regex(/^[0-9a-f]{64}$/),
    baseRootfsUrl: z.string().url(),
    baseRootfsDigest: z.string().regex(/^[0-9a-f]{64}$/),
    baseLayoutVersion: z.int().min(1),
    components: z.array(GuestImageComponentSchema)
});
export const GuestEnvironmentSchema = z.object({
    PATH: z.string().min(1),
    HOME: z.string().min(1),
    LANG: z.string().min(1)
});
export const GuestHarnessSchema = z.object({
    harness: z.string().min(1),
    harnessVersion: z.string().min(1),
    protocol: GuestHarnessProtocolSchema,
    command: z.array(z.string()).min(1),
    workingDirectory: z.string().min(1),
    cloneSeconds: z.int().min(1),
    environment: GuestEnvironmentSchema,
    fixedVariables: z.array(FixedVariableSchema)
});
export const HarnessLayerManifestSchema = z.object({
    layerDigest: z.string().regex(/^[0-9a-f]{64}$/),
    recipeDigest: z.string().regex(/^[0-9a-f]{64}$/),
    architecture: HostArchitectureSchema,
    harness: GuestHarnessSchema
});
export const ImageReleaseSchema = z.object({
    imageReleaseVersion: z.string().regex(/^images-v[0-9]+\.[0-9]+\.[0-9]+$/),
    commit: z.string().regex(/^[0-9a-f]{40}$/),
    guestProtocolVersion: z.int().min(1),
    images: z.array(ReleaseImageSchema).min(1),
    baseLayoutVersion: z.int().min(1),
    bases: z.array(ReleaseBaseImageSchema).min(1)
});
export const DeployDrainSchema = z.object({
    drainToken: z.string().regex(/^[A-Za-z0-9_-]{43}$/)
});
export const CliCredentialsSchema = z.object({
    endpoint: z.string().url(),
    token: z.string().min(1)
});
export const CliProofCredentialsSchema = z.object({
    clientId: z.string().min(1),
    clientSecret: z.string().min(1)
});
export const SupervisorConfigSchema = z.object({
    endpoint: z.string().url(),
    hostId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64)
});
export const SupervisorHostKeySchema = z.object({
    publicKey: z.string().min(1),
    privateKey: z.string().min(1)
});
export const StoredHostFrameSchema = z.object({
    type: z.literal("Frame"),
    seq: z.int().min(0),
    ack: z.int().min(0),
    message: z.unknown()
});
export const SupervisorChannelReplaySchema = z.object({
    seq: z.int().min(0),
    replays: z.int().min(1)
});
export const SupervisorChannelStateSchema = z.object({
    received: z.int().min(0),
    sent: z.int().min(0),
    unacked: z.array(StoredHostFrameSchema),
    replays: z.array(SupervisorChannelReplaySchema).optional()
});
export const SupervisorUpdatePendingSchema = z.object({
    fromSha256: z.string().regex(/^[0-9a-f]{64}$/),
    toSha256: z.string().regex(/^[0-9a-f]{64}$/),
    swappedAt: z.string().datetime({ offset: true })
});
export const SupervisorHandoverMachineSchema = z.object({
    processId: z.int().min(1),
    apiSocket: z.string(),
    vsock: z.string(),
    guestFd: z.int().min(0),
    guestBuffer: z.string(),
    stdoutFd: z.int().min(0),
    stderrFd: z.int().min(0),
    consoleTail: z.string()
});
export const GuestImageManifestSchema = z.object({
    imageDigest: z.string().regex(/^[0-9a-f]{64}$/),
    kernelUrl: z.string().url(),
    kernelDigest: z.string().regex(/^[0-9a-f]{64}$/),
    baseRootfsUrl: z.string().url(),
    baseRootfsDigest: z.string().regex(/^[0-9a-f]{64}$/),
    harness: GuestHarnessSchema,
    components: z.array(GuestImageComponentSchema)
});
export const SupervisorHandoverFullImageSchema = z.object({
    kind: z.literal("Full"),
    manifest: GuestImageManifestSchema
});
export const SupervisorHandoverLayeredImageSchema = z.object({
    kind: z.literal("Layered"),
    base: BaseImageManifestSchema,
    layer: HarnessLayerManifestSchema,
    layerPath: z.string()
});
export const SupervisorHandoverWarmSchema = z.object({
    kind: z.literal("Warm"),
    warmMilliseconds: z.int().min(0),
    expired: z.boolean()
});
export const SupervisorHandoverTurnErrorSchema = z.object({
    reason: TurnFailureReasonSchema,
    detail: z.string()
});
export const SupervisorHandoverTurnSchema = z.object({
    kind: z.literal("Turn"),
    turnId: z.string().min(1).max(64),
    turnMilliseconds: z.int().min(0),
    firstLineMilliseconds: z.int().min(0),
    repositoryReady: z.boolean(),
    seenLine: z.boolean(),
    error: SupervisorHandoverTurnErrorSchema.optional(),
    cancelled: z.boolean().optional()
});
export const SupervisorHandoverSnapshotSchema = z.object({
    kind: z.literal("Snapshot"),
    snapshotId: z.string().min(1).max(64),
    snapshotSeq: z.int().min(0),
    uploadUrl: z.string(),
    uploadExpiresAt: z.string().datetime({ offset: true })
});
export const SupervisorHandoverTeardownSchema = z.object({
    kind: z.literal("Teardown")
});
export const SupervisorHandoverDiscardSchema = z.object({
    kind: z.literal("Discard")
});
export const SupervisorHandoverBoxSchema = z.object({
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    tapIndex: z.int().min(0).max(255),
    machine: SupervisorHandoverMachineSchema,
    image: z.discriminatedUnion("kind", [SupervisorHandoverFullImageSchema, SupervisorHandoverLayeredImageSchema]),
    dirty: z.boolean(),
    credentialFile: z.string().optional(),
    state: z.discriminatedUnion("kind", [SupervisorHandoverWarmSchema, SupervisorHandoverTurnSchema]),
    queued: z.array(z.discriminatedUnion("kind", [SupervisorHandoverSnapshotSchema, SupervisorHandoverTeardownSchema, SupervisorHandoverDiscardSchema]))
});
export const SupervisorHandoverSchema = z.object({
    handedAt: z.string().datetime({ offset: true }),
    boxes: z.array(SupervisorHandoverBoxSchema)
});
export const SupervisorUpdateRefusalSchema = z.object({
    toSha256: z.string().regex(/^[0-9a-f]{64}$/),
    reason: SupervisorUpdateFailureReasonSchema,
    refusedAt: z.string().datetime({ offset: true })
});
export const SupervisorCheckReportSchema = z.object({
    supervisorVersion: z.string().min(1),
    channelProtocolVersion: z.int().min(1),
    guestProtocolVersion: z.int().min(1)
});
export const BoxBudgetsSchema = z.object({
    bootSeconds: z.int().min(1),
    firstLineSeconds: z.int().min(1),
    snapshotSeconds: z.int().min(1)
});
export const SupervisorRuntimeSchema = z.object({
    firecrackerPath: z.string().min(1),
    imageCacheDir: z.string().min(1),
    dataDir: z.string().min(1),
    boxCapacity: z.int().min(1).max(256),
    vcpuCount: z.int().min(1),
    memoryMib: z.int().min(128),
    overlayMib: z.int().min(64),
    layerCacheMib: z.int().min(1),
    budgets: BoxBudgetsSchema,
    heartbeatIntervalSeconds: z.int().min(1).max(300),
    updateGraceSeconds: z.int().min(0)
});
export const GuestHelloSchema = z.object({
    type: z.literal("GuestHello"),
    protocolVersion: z.int().min(1),
    harness: z.string().min(1),
    harnessVersion: z.string().min(1),
    lastLineSeq: z.int().min(0)
});
export const GuestPersonaFileSchema = z.object({
    path: z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200),
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    content: z.string()
});
export const DispatchVariableSchema = z.object({
    name: z.string().min(1),
    value: z.string().min(1)
});
export const DispatchConnectorSchema = z.object({
    connectorId: z.string().min(1).max(64),
    name: z.string().min(1).max(100).optional(),
    url: z.string().url(),
    tokenUrl: z.string().url(),
    tokenCredential: z.string().min(43)
});
export const DispatchGrantSchema = z.object({
    credentialHandoverId: z.string().min(1).max(64),
    expiresAt: z.string().datetime({ offset: true }),
    variables: z.array(DispatchVariableSchema),
    arguments: z.array(z.string()).optional(),
    credentialFile: z.object({ path: z.string().min(1), value: z.string().min(1) }).optional(),
    connectors: z.array(DispatchConnectorSchema)
});
export const GuestTurnStartSchema = z.object({
    type: z.literal("TurnStart"),
    turnId: z.string().min(1).max(64),
    model: z.string().min(1).max(200),
    prompt: z.string().min(1).max(100000),
    credential: DispatchGrantSchema,
    files: z.array(GuestPersonaFileSchema),
    repository: z.string().min(1).max(500),
    gitAuthorName: z.string().min(1).max(100),
    gitAuthorEmail: z.string().min(3).max(320),
    lastLineSeq: z.int().min(0),
    prebuildCommitSha: z.string().regex(/^[0-9a-f]{40}$/).optional(),
    turnSeconds: z.int().min(1).optional()
});
export const GuestTurnRepositoryReadySchema = z.object({
    type: z.literal("TurnRepositoryReady"),
    turnId: z.string().min(1).max(64)
});
export const GuestTurnLineSchema = z.object({
    type: z.literal("TurnLine"),
    turnId: z.string().min(1).max(64),
    lineSeq: z.int().min(0),
    text: z.string()
});
export const GuestTurnRepositoryCloneFailedSchema = z.object({
    type: z.literal("TurnRepositoryCloneFailed"),
    turnId: z.string().min(1).max(64),
    cause: RepositoryCloneFailureCauseSchema,
    detail: z.string()
});
export const GuestMetricSchema = z.object({
    metric: z.string().regex(/^[a-z][a-z0-9_]*(\.[a-z0-9_]+)*$/).max(64),
    unit: z.string().min(1),
    kind: MetricKindSchema,
    description: z.string().min(1),
    value: z.number(),
    dimensions: z.record(z.string(), z.string())
});
export const GuestTurnEndSchema = z.object({
    type: z.literal("TurnEnd"),
    turnId: z.string().min(1).max(64),
    reason: GuestTurnEndReasonSchema,
    lastLineSeq: z.int().min(0),
    detail: z.string(),
    credentialFile: z.string().min(1).optional(),
    metrics: z.array(GuestMetricSchema).optional(),
    warning: z.string().min(1).optional()
});
export const GuestClaudeSetupStartSchema = z.object({
    type: z.literal("ClaudeSetupStart"),
    claudeSetupId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    tokenUrl: z.string().url(),
    tokenCredential: z.string().min(43)
});
export const GuestClaudeSetupCodeSchema = z.object({
    type: z.literal("ClaudeSetupCode"),
    claudeSetupId: z.string().min(1).max(64),
    code: z.string().min(1).max(2000),
    mintBudgetSeconds: z.int().min(1).max(3600)
});
export const GuestTurnCancelSchema = z.object({
    type: z.literal("TurnCancel"),
    turnId: z.string().min(1).max(64)
});
export const GuestClaudeSetupUrlSchema = z.object({
    type: z.literal("ClaudeSetupUrl"),
    claudeSetupId: z.string().min(1).max(64),
    signInUrl: z.string().url(),
    userCode: z.string().min(1).max(64).optional()
});
export const GuestClaudeSetupStoredSchema = z.object({
    type: z.literal("ClaudeSetupStored"),
    claudeSetupId: z.string().min(1).max(64)
});
export const GuestClaudeSetupFailedSchema = z.object({
    type: z.literal("ClaudeSetupFailed"),
    claudeSetupId: z.string().min(1).max(64),
    reason: GuestClaudeSetupFailureReasonSchema,
    detail: z.string()
});
export const SnapshotEntryCommonSchema = z.object({
    path: z.string().min(1),
    mode: z.int().min(0).max(4095),
    uid: z.int().min(0),
    gid: z.int().min(0),
    mtimeSeconds: z.int(),
    mtimeNanos: z.int().min(0).max(999999999)
});
export const ChunkPlacementSchema = z.object({
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    packDigest: z.string().regex(/^[0-9a-f]{64}$/),
    offset: z.int().min(0),
    length: z.int().min(1)
});
export const SnapshotFileEntrySchema = z.object({
    kind: z.literal("File"),
    path: z.string().min(1),
    mode: z.int().min(0).max(4095),
    uid: z.int().min(0),
    gid: z.int().min(0),
    mtimeSeconds: z.int(),
    mtimeNanos: z.int().min(0).max(999999999),
    sizeBytes: z.int().min(0),
    chunks: z.array(ChunkPlacementSchema)
});
export const SnapshotDirectoryEntrySchema = z.object({
    kind: z.literal("Directory"),
    path: z.string().min(1),
    mode: z.int().min(0).max(4095),
    uid: z.int().min(0),
    gid: z.int().min(0),
    mtimeSeconds: z.int(),
    mtimeNanos: z.int().min(0).max(999999999)
});
export const SnapshotOpaqueDirectoryEntrySchema = z.object({
    kind: z.literal("OpaqueDirectory"),
    path: z.string().min(1),
    mode: z.int().min(0).max(4095),
    uid: z.int().min(0),
    gid: z.int().min(0),
    mtimeSeconds: z.int(),
    mtimeNanos: z.int().min(0).max(999999999)
});
export const SnapshotSymlinkEntrySchema = z.object({
    kind: z.literal("Symlink"),
    path: z.string().min(1),
    mode: z.int().min(0).max(4095),
    uid: z.int().min(0),
    gid: z.int().min(0),
    mtimeSeconds: z.int(),
    mtimeNanos: z.int().min(0).max(999999999),
    target: z.string().min(1)
});
export const SnapshotWhiteoutEntrySchema = z.object({
    kind: z.literal("Whiteout"),
    path: z.string().min(1),
    mode: z.int().min(0).max(4095),
    uid: z.int().min(0),
    gid: z.int().min(0),
    mtimeSeconds: z.int(),
    mtimeNanos: z.int().min(0).max(999999999)
});
export const SnapshotManifestSchema = z.object({
    entries: z.array(z.discriminatedUnion("kind", [SnapshotFileEntrySchema, SnapshotDirectoryEntrySchema, SnapshotOpaqueDirectoryEntrySchema, SnapshotSymlinkEntrySchema, SnapshotWhiteoutEntrySchema]))
});
export const SnapshotRootSchema = z.object({
    manifest: z.array(ChunkPlacementSchema)
});
export const OpenRouterAuthorizationAwaitingCallbackSchema = z.object({
    state: z.literal("AwaitingCallback"),
    authorizeUrl: z.string().url(),
    callbackDueAt: z.string().datetime({ offset: true })
});
export const OpenRouterAuthorizationExchangingSchema = z.object({
    state: z.literal("Exchanging"),
    exchangeDueAt: z.string().datetime({ offset: true })
});
export const OpenRouterAuthorizationCompletedSchema = z.object({
    state: z.literal("Completed"),
    keyLabel: z.string().min(1).max(100),
    completedAt: z.string().datetime({ offset: true })
});
export const OpenRouterAuthorizationFailedSchema = z.object({
    state: z.literal("Failed"),
    reason: OpenRouterAuthorizationFailureReasonSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true })
});
export const OpenRouterAuthorizationSchema = z.object({
    openRouterAuthorizationId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    secretSetId: z.string().min(1).max(64),
    status: z.discriminatedUnion("state", [OpenRouterAuthorizationAwaitingCallbackSchema, OpenRouterAuthorizationExchangingSchema, OpenRouterAuthorizationCompletedSchema, OpenRouterAuthorizationFailedSchema]),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const OpenRouterAuthorizationStartSchema = z.object({
    secretSetId: z.string().min(1).max(64)
});
export const OpenRouterAuthorizationPathSchema = z.object({
    openRouterAuthorizationId: z.string().min(1).max(64)
});
export const ConnectorNotConnectedSchema = z.object({
    state: z.literal("NotConnected")
});
export const ConnectorConnectedSchema = z.object({
    state: z.literal("Connected"),
    connectedAt: z.string().datetime({ offset: true })
});
export const ConnectorDisconnectedSchema = z.object({
    state: z.literal("Disconnected"),
    disconnectedAt: z.string().datetime({ offset: true })
});
export const ConnectorAuthorizationFailedSchema = z.object({
    state: z.literal("AuthorizationFailed"),
    reason: ConnectorAuthorizationFailureReasonSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true })
});
export const ConnectorFieldsSchema = z.object({
    connectorId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    name: z.string().min(1).max(100),
    url: z.string().url().regex(/^https:\/\/[^\/@?#\s]+(\/[^?#\s]*)?$/).max(2048),
    status: z.discriminatedUnion("state", [ConnectorNotConnectedSchema, ConnectorConnectedSchema, ConnectorDisconnectedSchema, ConnectorAuthorizationFailedSchema]),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const StaticConnectorSchema = z.object({
    auth: z.literal("Static"),
    connectorId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    name: z.string().min(1).max(100),
    url: z.string().url().regex(/^https:\/\/[^\/@?#\s]+(\/[^?#\s]*)?$/).max(2048),
    status: z.discriminatedUnion("state", [ConnectorNotConnectedSchema, ConnectorConnectedSchema, ConnectorDisconnectedSchema, ConnectorAuthorizationFailedSchema]),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const OAuthConnectorSchema = z.object({
    auth: z.literal("OAuth"),
    connectorId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    name: z.string().min(1).max(100),
    url: z.string().url().regex(/^https:\/\/[^\/@?#\s]+(\/[^?#\s]*)?$/).max(2048),
    status: z.discriminatedUnion("state", [ConnectorNotConnectedSchema, ConnectorConnectedSchema, ConnectorDisconnectedSchema, ConnectorAuthorizationFailedSchema]),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const StaticConnectorCreateSchema = z.object({
    name: z.string().min(1).max(100),
    url: z.string().url().regex(/^https:\/\/[^\/@?#\s]+(\/[^?#\s]*)?$/).max(2048)
});
export const OAuthConnectorCreateSchema = z.object({
    name: z.string().min(1).max(100),
    url: z.string().url().regex(/^https:\/\/[^\/@?#\s]+(\/[^?#\s]*)?$/).max(2048)
});
export const ConnectorUpdateSchema = z.object({
    name: z.string().min(1).max(100)
});
export const StaticConnectorTokenWriteSchema = z.object({
    value: z.string().min(1).max(10000)
});
export const ConnectorAuthorizationSchema = z.object({
    connectorAuthorizationId: z.string().min(1).max(64),
    connectorId: z.string().min(1).max(64),
    authorizeUrl: z.string().url(),
    callbackDueAt: z.string().datetime({ offset: true })
});
export const ConnectorAccessTokenSchema = z.object({
    accessToken: z.string().min(1).max(10000),
    expiresAt: z.string().datetime({ offset: true }).optional()
});
export const ConnectorTurnTokenSchema = z.object({
    type: z.literal("http"),
    scheme: z.literal("Bearer")
});
export const ConnectorPathSchema = z.object({
    connectorId: z.string().min(1).max(64)
});
export const ConnectorTokenPathSchema = z.object({
    turnId: z.string().min(1).max(64),
    connectorId: z.string().min(1).max(64)
});
export const ConnectorWritePathSchema = z.object({
    connectorId: z.string().min(1).max(64),
    updatedAt: z.number()
});
export const TenantEventEnvelopeSchema = z.object({
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int()
});
export const TurnStartedEventSchema = z.object({
    event: z.literal("TurnStarted"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    turnId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64)
});
export const TurnCompletedEventSchema = z.object({
    event: z.literal("TurnCompleted"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    turnId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64)
});
export const TurnFailedEventSchema = z.object({
    event: z.literal("TurnFailed"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    turnId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    reason: TurnFailureReasonSchema,
    detail: z.string()
});
export const SessionIdleEventSchema = z.object({
    event: z.literal("SessionIdle"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    sessionId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64)
});
export const SessionStoppedEventSchema = z.object({
    event: z.literal("SessionStopped"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    sessionId: z.string().min(1).max(64)
});
export const SessionFailedEventSchema = z.object({
    event: z.literal("SessionFailed"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    sessionId: z.string().min(1).max(64)
});
export const SessionArchivedEventSchema = z.object({
    event: z.literal("SessionArchived"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    sessionId: z.string().min(1).max(64)
});
export const HostOnlineEventSchema = z.object({
    event: z.literal("HostOnline"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    hostId: z.string().min(1).max(64)
});
export const HostOfflineEventSchema = z.object({
    event: z.literal("HostOffline"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    hostId: z.string().min(1).max(64)
});
export const PrebuildDoneEventSchema = z.object({
    event: z.literal("PrebuildDone"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    prebuildId: z.string().min(1).max(64),
    repository: z.string().min(1).max(500)
});
export const PrebuildFailedEventSchema = z.object({
    event: z.literal("PrebuildFailed"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    prebuildId: z.string().min(1).max(64),
    repository: z.string().min(1).max(500),
    phase: PrebuildFailurePhaseSchema
});
export const SubscriptionPausedByRequestSchema = z.object({
    kind: z.literal("ByRequest"),
    message: z.string().min(1).max(500)
});
export const SubscriptionPausedDeliveryFailedSchema = z.object({
    kind: z.literal("DeliveryFailed"),
    turnId: z.string().min(1).max(64)
});
export const SubscriptionPausedCrewFailingSchema = z.object({
    kind: z.literal("CrewFailing")
});
export const SubscriptionPausedCreditExhaustedSchema = z.object({
    kind: z.literal("CreditExhausted"),
    turnId: z.string().min(1).max(64)
});
export const SubscriptionPausedEventSchema = z.object({
    event: z.literal("SubscriptionPaused"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    subscriptionId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    reason: z.discriminatedUnion("kind", [SubscriptionPausedByRequestSchema, SubscriptionPausedDeliveryFailedSchema, SubscriptionPausedCrewFailingSchema, SubscriptionPausedCreditExhaustedSchema])
});
export const SubscriptionEndedEventSchema = z.object({
    event: z.literal("SubscriptionEnded"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    subscriptionId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    reason: SubscriptionEndReasonSchema
});
export const TriggerStartRefusedEventSchema = z.object({
    event: z.literal("TriggerStartRefused"),
    eventId: z.int().min(0),
    tenantId: z.string().min(1).max(64),
    createdAt: z.int(),
    triggerId: z.string().min(1).max(64),
    deliveryId: z.string().min(1).max(200),
    refusal: TriggerStartRefusalSchema
});
export const EventPageSchema = z.object({
    events: z.array(z.discriminatedUnion("event", [TurnStartedEventSchema, TurnCompletedEventSchema, TurnFailedEventSchema, SessionIdleEventSchema, SessionStoppedEventSchema, SessionFailedEventSchema, SessionArchivedEventSchema, HostOnlineEventSchema, HostOfflineEventSchema, PrebuildDoneEventSchema, PrebuildFailedEventSchema, SubscriptionPausedEventSchema, SubscriptionEndedEventSchema, TriggerStartRefusedEventSchema])).max(100),
    lastEventId: z.int().min(0)
});
export const EventCursorExpiredProblemSchema = z.object({
    title: z.string(),
    detail: z.string(),
    fix: z.string(),
    code: z.literal("EventCursorExpired"),
    oldestEventId: z.int().min(0)
});
export const EventProblemResponseSchema = z.object({
    statusCode: z.union([z.literal(400), z.literal(401), z.literal(403), z.literal(404), z.literal(409), z.literal(410), z.literal(422), z.literal(429), z.literal(503)]),
    body: z.union([EventCursorExpiredProblemSchema, ProblemSchema])
});
export const EventQuerySchema = z.object({
    afterEventId: z.number().min(0).optional(),
    event: z.array(TenantEventTypeSchema).optional(),
    sessionId: z.string().min(1).max(64).optional(),
    triggerId: z.string().min(1).max(64).optional(),
    waitSeconds: z.number().min(0).max(50)
});
export const SubscriptionBaseSchema = z.object({
    subscriptionId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    prompt: z.string().min(1).max(100000),
    goal: z.string().min(1).max(100000),
    events: z.array(SubscriptionEventTypeSchema).min(1),
    crewTags: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).max(16),
    expiresAt: z.string().datetime({ offset: true }),
    cursorEventId: z.int().min(0),
    crewFailuresInARow: z.int().min(0),
    deliveryFailuresInARow: z.int().min(0),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const ActiveSubscriptionSchema = z.object({
    subscriptionId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    prompt: z.string().min(1).max(100000),
    goal: z.string().min(1).max(100000),
    events: z.array(SubscriptionEventTypeSchema).min(1),
    crewTags: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).max(16),
    expiresAt: z.string().datetime({ offset: true }),
    cursorEventId: z.int().min(0),
    crewFailuresInARow: z.int().min(0),
    deliveryFailuresInARow: z.int().min(0),
    createdAt: z.int(),
    updatedAt: z.int(),
    state: z.literal("Active")
});
export const PausedSubscriptionSchema = z.object({
    subscriptionId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    prompt: z.string().min(1).max(100000),
    goal: z.string().min(1).max(100000),
    events: z.array(SubscriptionEventTypeSchema).min(1),
    crewTags: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).max(16),
    expiresAt: z.string().datetime({ offset: true }),
    cursorEventId: z.int().min(0),
    crewFailuresInARow: z.int().min(0),
    deliveryFailuresInARow: z.int().min(0),
    createdAt: z.int(),
    updatedAt: z.int(),
    state: z.literal("Paused"),
    reason: z.discriminatedUnion("kind", [SubscriptionPausedByRequestSchema, SubscriptionPausedDeliveryFailedSchema, SubscriptionPausedCrewFailingSchema, SubscriptionPausedCreditExhaustedSchema]),
    pausedAt: z.string().datetime({ offset: true })
});
export const EndedSubscriptionSchema = z.object({
    subscriptionId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    prompt: z.string().min(1).max(100000),
    goal: z.string().min(1).max(100000),
    events: z.array(SubscriptionEventTypeSchema).min(1),
    crewTags: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).max(16),
    expiresAt: z.string().datetime({ offset: true }),
    cursorEventId: z.int().min(0),
    crewFailuresInARow: z.int().min(0),
    deliveryFailuresInARow: z.int().min(0),
    createdAt: z.int(),
    updatedAt: z.int(),
    state: z.literal("Ended"),
    reason: SubscriptionEndReasonSchema,
    endedAt: z.string().datetime({ offset: true })
});
export const SubscriptionCreateSchema = z.object({
    sessionId: z.string().min(1).max(64),
    prompt: z.string().min(1).max(100000),
    goal: z.string().min(1).max(100000),
    events: z.array(SubscriptionEventTypeSchema).min(1),
    crewTags: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).max(16),
    expiresAt: z.string().datetime({ offset: true })
});
export const SubscriptionPauseSchema = z.object({
    message: z.string().min(1).max(500)
});
export const SubscriptionPathSchema = z.object({
    subscriptionId: z.string().min(1).max(64)
});
export const SubscriptionListQuerySchema = z.object({
    sessionId: z.string().min(1).max(64).optional(),
    state: SubscriptionStateSchema.optional()
});
export const WebhookDeliveringSchema = z.object({
    delivery: z.literal("Delivering")
});
export const WebhookFailingSchema = z.object({
    delivery: z.literal("Failing"),
    detail: z.string(),
    failingSince: z.string().datetime({ offset: true })
});
export const WebhookEndpointSchema = z.object({
    webhookEndpointId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    url: z.string().url().regex(/^https:\/\/[^\/@?#\s]+(\/[^#\s]*)?$/).max(2048),
    events: z.array(TenantEventTypeSchema).min(1),
    status: z.discriminatedUnion("delivery", [WebhookDeliveringSchema, WebhookFailingSchema]),
    createdAt: z.int()
});
export const WebhookEndpointCreateSchema = z.object({
    url: z.string().url().regex(/^https:\/\/[^\/@?#\s]+(\/[^#\s]*)?$/).max(2048),
    events: z.array(TenantEventTypeSchema).min(1)
});
export const WebhookEndpointPathSchema = z.object({
    webhookEndpointId: z.string().min(1).max(64)
});
export const WebhookSigningKeySchema = z.object({
    algorithm: z.literal("Ed25519"),
    publicKey: z.string().regex(/^[A-Za-z0-9_-]{43}$/)
});
export const PushSubscriptionKeysSchema = z.object({
    p256dh: z.string().regex(/^[A-Za-z0-9_-]{87}$/),
    auth: z.string().regex(/^[A-Za-z0-9_-]{22}$/)
});
export const PushSubscriptionSchema = z.object({
    pushSubscriptionId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    endpoint: z.string().url().regex(/^https:\/\/[^\/@?#\s]+(\/[^#\s]*)?$/).max(2048),
    events: z.array(TenantEventTypeSchema).min(1),
    createdAt: z.int()
});
export const PushSubscriptionCreateSchema = z.object({
    endpoint: z.string().url().regex(/^https:\/\/[^\/@?#\s]+(\/[^#\s]*)?$/).max(2048),
    events: z.array(TenantEventTypeSchema).min(1),
    keys: PushSubscriptionKeysSchema
});
export const PushSubscriptionPathSchema = z.object({
    pushSubscriptionId: z.string().min(1).max(64)
});
export const PushNotificationSchema = z.object({
    title: z.string(),
    body: z.string(),
    path: z.string().regex(/^\//)
});
export const PushKeySchema = z.object({
    applicationServerKey: z.string().regex(/^[A-Za-z0-9_-]{87}$/)
});
export const SequencedSchema = z.object({
    seq: z.int().min(0),
    ack: z.int().min(0)
});
export const ChallengeSchema = z.object({
    type: z.literal("Challenge"),
    nonce: z.string().min(43)
});
export const HelloSchema = z.object({
    type: z.literal("Hello"),
    hostId: z.string().min(1).max(64),
    protocolVersion: z.int().min(1),
    channelProtocolOldest: z.int().min(1).optional(),
    supervisorVersion: z.string().min(1),
    signature: z.string().min(1),
    boxCapacity: z.int().min(1).max(256),
    usage: HostUsageSchema,
    guestProtocol: GuestProtocolRangeSchema.optional()
});
export const WelcomeSchema = z.object({
    type: z.literal("Welcome"),
    hostId: z.string().min(1).max(64),
    protocolVersion: z.int().min(1),
    ack: z.int().min(0).optional()
});
export const HeartbeatSchema = z.object({
    type: z.literal("Heartbeat"),
    sentAt: z.string().datetime({ offset: true })
});
export const ReleasePublishedSchema = z.object({
    type: z.literal("ReleasePublished"),
    releaseVersion: z.string().min(1)
});
export const FrameRefusedSchema = z.object({
    type: z.literal("FrameRefused"),
    seq: z.int().min(0),
    reason: z.string().min(1)
});
export const HostHeartbeatSchema = z.object({
    type: z.literal("Heartbeat"),
    sentAt: z.string().datetime({ offset: true }),
    usage: HostUsageSchema,
    heldSessionIds: z.array(z.string().min(1).max(64))
});
export const SnapshotDownloadSchema = z.object({
    snapshotId: z.string().min(1).max(64),
    snapshotSeq: z.int().min(0),
    storageKey: z.string().min(1).max(1000),
    downloadUrl: z.string().url(),
    downloadExpiresAt: z.string().datetime({ offset: true })
});
export const PersonaFileDownloadSchema = z.object({
    path: z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200),
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(0).max(262144),
    downloadUrl: z.string().url(),
    downloadExpiresAt: z.string().datetime({ offset: true })
});
export const GuestImageDownloadSchema = z.object({
    kind: z.literal("Full"),
    imageDigest: z.string().regex(/^[0-9a-f]{64}$/),
    kernelDigest: z.string().regex(/^[0-9a-f]{64}$/),
    manifestDigest: z.string().regex(/^[0-9a-f]{64}$/),
    imageUrl: z.string().url(),
    kernelUrl: z.string().url(),
    manifestUrl: z.string().url(),
    downloadExpiresAt: z.string().datetime({ offset: true }),
    fetchSeconds: z.int().min(1)
});
export const BaseImageDownloadSchema = z.object({
    imageDigest: z.string().regex(/^[0-9a-f]{64}$/),
    kernelDigest: z.string().regex(/^[0-9a-f]{64}$/),
    manifestDigest: z.string().regex(/^[0-9a-f]{64}$/),
    imageUrl: z.string().url(),
    kernelUrl: z.string().url(),
    manifestUrl: z.string().url()
});
export const HarnessLayerDownloadSchema = z.object({
    layer: ReleaseHarnessLayerSchema,
    layerUrl: z.string().url(),
    manifestUrl: z.string().url()
});
export const LayeredImageDownloadSchema = z.object({
    kind: z.literal("Layered"),
    base: BaseImageDownloadSchema,
    layer: HarnessLayerDownloadSchema,
    downloadExpiresAt: z.string().datetime({ offset: true }),
    fetchSeconds: z.int().min(1)
});
export const TurnOfferSchema = z.object({
    turnTotalBudgetSeconds: z.int().min(1).max(86400),
    type: z.literal("TurnOffer"),
    turnId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    repository: z.string().min(1).max(500),
    harness: HarnessSchema,
    harnessVersion: z.string().min(1),
    model: z.string().min(1).max(200),
    prompt: z.string().min(1).max(100000),
    credential: DispatchGrantSchema,
    lastLineSeq: z.int().min(0),
    snapshots: z.array(SnapshotDownloadSchema).max(1),
    personaFiles: z.array(PersonaFileDownloadSchema),
    image: z.discriminatedUnion("kind", [GuestImageDownloadSchema, LayeredImageDownloadSchema]),
    gitAuthorName: z.string().min(1).max(100),
    gitAuthorEmail: z.string().min(3).max(320),
    boxMemoryMib: z.int().min(128).max(65536).optional(),
    boxDiskMib: z.int().min(64).max(262144).optional(),
    prebuildCommitSha: z.string().regex(/^[0-9a-f]{40}$/).optional()
});
export const TurnWithdrawnSchema = z.object({
    type: z.literal("TurnWithdrawn"),
    turnId: z.string().min(1).max(64)
});
export const TurnClaimSchema = z.object({
    type: z.literal("TurnClaim"),
    turnId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64)
});
export const TurnClaimedSchema = z.object({
    type: z.literal("TurnClaimed"),
    turnId: z.string().min(1).max(64)
});
export const TurnImageFetchingSchema = z.object({
    type: z.literal("TurnImageFetching"),
    turnId: z.string().min(1).max(64),
    imageDigest: z.string().regex(/^[0-9a-f]{64}$/)
});
export const TurnRepositoryReadySchema = z.object({
    type: z.literal("TurnRepositoryReady"),
    turnId: z.string().min(1).max(64)
});
export const TurnLineSchema = z.object({
    type: z.literal("TurnLine"),
    turnId: z.string().min(1).max(64),
    lineSeq: z.int().min(0),
    text: z.string()
});
export const TurnCompleteSchema = z.object({
    type: z.literal("TurnComplete"),
    turnId: z.string().min(1).max(64),
    lastLineSeq: z.int().min(0),
    completedAt: z.string().datetime({ offset: true }),
    credentialFile: z.string().min(1).optional(),
    warning: z.string().min(1).optional()
});
export const TurnRepositoryCloneFailedSchema = z.object({
    type: z.literal("TurnRepositoryCloneFailed"),
    turnId: z.string().min(1).max(64),
    cause: RepositoryCloneFailureCauseSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true })
});
export const TurnFailedSchema = z.object({
    type: z.literal("TurnFailed"),
    turnId: z.string().min(1).max(64),
    reason: TurnFailureReasonSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true }),
    credentialFile: z.string().min(1).optional()
});
export const TurnCancelSchema = z.object({
    type: z.literal("TurnCancel"),
    turnId: z.string().min(1).max(64)
});
export const SnapshotRequestSchema = z.object({
    type: z.literal("SnapshotRequest"),
    snapshotId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64),
    snapshotSeq: z.int().min(0),
    storageKey: z.string().min(1).max(1000),
    uploadUrl: z.string().url(),
    uploadExpiresAt: z.string().datetime({ offset: true })
});
export const PackSchema = z.object({
    packDigest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(1)
});
export const PackUrlSchema = z.object({
    packDigest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(1),
    url: z.string().url()
});
export const SnapshotChunksSchema = z.object({
    type: z.literal("SnapshotChunks"),
    snapshotId: z.string().min(1).max(64),
    part: z.int().min(1),
    digests: z.array(z.string().regex(/^[0-9a-f]{64}$/)).max(500)
});
export const SnapshotChunksHeldSchema = z.object({
    type: z.literal("SnapshotChunksHeld"),
    snapshotId: z.string().min(1).max(64),
    part: z.int().min(1),
    held: z.array(ChunkPlacementSchema).max(500)
});
export const SnapshotPacksSchema = z.object({
    type: z.literal("SnapshotPacks"),
    snapshotId: z.string().min(1).max(64),
    part: z.int().min(1),
    packs: z.array(PackSchema).max(500),
    chunks: z.array(ChunkPlacementSchema).max(500)
});
export const SnapshotPackUploadsSchema = z.object({
    type: z.literal("SnapshotPackUploads"),
    snapshotId: z.string().min(1).max(64),
    part: z.int().min(1),
    uploads: z.array(PackUrlSchema).max(500),
    uploadExpiresAt: z.string().datetime({ offset: true })
});
export const RestoreChunksSchema = z.object({
    type: z.literal("RestoreChunks"),
    turnId: z.string().min(1).max(64),
    part: z.int().min(1),
    chunks: z.array(ChunkPlacementSchema).max(500)
});
export const RestoreDownloadsSchema = z.object({
    type: z.literal("RestoreDownloads"),
    turnId: z.string().min(1).max(64),
    part: z.int().min(1),
    packs: z.array(PackUrlSchema).max(500),
    downloadExpiresAt: z.string().datetime({ offset: true })
});
export const SnapshotDoneSchema = z.object({
    type: z.literal("SnapshotDone"),
    snapshotId: z.string().min(1).max(64),
    uploadedBytes: z.int().min(0)
});
export const SnapshotFailedSchema = z.object({
    type: z.literal("SnapshotFailed"),
    snapshotId: z.string().min(1).max(64),
    reason: SnapshotFailureReasonSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true })
});
export const BoxTeardownSchema = z.object({
    type: z.literal("BoxTeardown"),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64)
});
export const BoxDiscardSchema = z.object({
    type: z.literal("BoxDiscard"),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64)
});
export const BoxGoneSchema = z.object({
    type: z.literal("BoxGone"),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64)
});
export const BoxTeardownFailedSchema = z.object({
    type: z.literal("BoxTeardownFailed"),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    reason: BoxTeardownFailureReasonSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true })
});
export const ClaudeSetupBoxOfferSchema = z.object({
    type: z.literal("ClaudeSetupBoxOffer"),
    claudeSetupId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    harness: ClaudeSetupHarnessSchema.optional(),
    harnessVersion: z.string().min(1),
    image: z.discriminatedUnion("kind", [GuestImageDownloadSchema, LayeredImageDownloadSchema]),
    tokenUrl: z.string().url(),
    tokenCredential: z.string().min(43),
    expiresAt: z.string().datetime({ offset: true })
});
export const ClaudeSetupBoxCodeSchema = z.object({
    type: z.literal("ClaudeSetupBoxCode"),
    claudeSetupId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    code: z.string().min(1).max(2000),
    mintBudgetSeconds: z.int().min(1).max(3600)
});
export const ClaudeSetupBoxDiscardSchema = z.object({
    type: z.literal("ClaudeSetupBoxDiscard"),
    claudeSetupId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64)
});
export const ClaudeSetupBoxUrlSchema = z.object({
    type: z.literal("ClaudeSetupBoxUrl"),
    claudeSetupId: z.string().min(1).max(64),
    signInUrl: z.string().url(),
    userCode: z.string().min(1).max(64).optional()
});
export const ClaudeSetupBoxFailedSchema = z.object({
    type: z.literal("ClaudeSetupBoxFailed"),
    claudeSetupId: z.string().min(1).max(64),
    reason: ClaudeSetupFailureReasonSchema,
    detail: z.string(),
    failedAt: z.string().datetime({ offset: true })
});
export const SupervisorUpdateStepSchema = z.object({
    type: z.literal("SupervisorUpdateStep"),
    fromSha256: z.string().regex(/^[0-9a-f]{64}$/),
    toSha256: z.string().regex(/^[0-9a-f]{64}$/),
    releaseVersion: z.string().min(1),
    boxesRunning: z.int().min(0),
    phase: SupervisorUpdatePhaseSchema,
    at: z.string().datetime({ offset: true })
});
export const SupervisorUpdateFailedSchema = z.object({
    type: z.literal("SupervisorUpdateFailed"),
    fromSha256: z.string().regex(/^[0-9a-f]{64}$/),
    toSha256: z.string().regex(/^[0-9a-f]{64}$/),
    reason: SupervisorUpdateFailureReasonSchema,
    detail: z.string(),
    outputTail: z.array(z.string()).max(20),
    failedAt: z.string().datetime({ offset: true })
});
export const TelemetryBatchSchema = z.object({
    type: z.literal("TelemetryBatch"),
    instruments: z.array(MetricInstrumentSchema),
    samples: z.array(SamplePointSchema).max(500),
    turns: z.array(TurnPointSchema).max(500)
});
export const HostFrameSchema = z.object({
    type: z.literal("Frame"),
    seq: z.int().min(0),
    ack: z.int().min(0),
    message: z.discriminatedUnion("type", [TurnImageFetchingSchema, TurnClaimSchema, TurnRepositoryReadySchema, TurnLineSchema, TurnCompleteSchema, TurnRepositoryCloneFailedSchema, TurnFailedSchema, SnapshotChunksSchema, SnapshotPacksSchema, RestoreChunksSchema, SnapshotDoneSchema, SnapshotFailedSchema, BoxGoneSchema, BoxTeardownFailedSchema, ClaudeSetupBoxUrlSchema, ClaudeSetupBoxFailedSchema, SupervisorUpdateStepSchema, SupervisorUpdateFailedSchema, TelemetryBatchSchema])
});
export const ControlFrameSchema = z.object({
    type: z.literal("Frame"),
    seq: z.int().min(0),
    ack: z.int().min(0),
    message: z.discriminatedUnion("type", [TurnOfferSchema, TurnWithdrawnSchema, TurnClaimedSchema, TurnCancelSchema, SnapshotRequestSchema, SnapshotChunksHeldSchema, SnapshotPackUploadsSchema, RestoreDownloadsSchema, BoxTeardownSchema, BoxDiscardSchema, ClaudeSetupBoxOfferSchema, ClaudeSetupBoxCodeSchema, ClaudeSetupBoxDiscardSchema])
});
export const StoredFileSchema = z.object({
    path: z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200),
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(0).max(262144)
});
export const StoredFileReadSchema = z.object({
    path: z.string().regex(/^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/).max(200),
    digest: z.string().regex(/^[0-9a-f]{64}$/),
    sizeBytes: z.int().min(0).max(262144),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const StoredPersonaSchema = z.object({
    turnTotalBudgetSeconds: z.int().min(1).max(86400),
    personaId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    name: z.string().min(1).max(100),
    harness: HarnessSchema,
    secretSetId: z.string().min(1).max(64),
    connectorIds: z.array(z.string().min(1).max(64)),
    boxMemoryMib: z.int().min(512).max(65536).optional(),
    boxDiskMib: z.int().min(32768).max(262144).optional(),
    boxRetention: BoxRetentionSchema,
    tumpelMcp: z.boolean(),
    files: z.array(StoredFileReadSchema),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const PersonaChangeSchema = z.object({
    turnTotalBudgetSeconds: z.int().min(1).max(86400),
    name: z.string().min(1).max(100),
    secretSetId: z.string().min(1).max(64),
    connectorIds: z.array(z.string().min(1).max(64)),
    boxMemoryMib: z.int().min(512).max(65536),
    boxDiskMib: z.int().min(32768).max(262144),
    boxRetention: BoxRetentionSchema,
    tumpelMcp: z.boolean(),
    files: z.array(StoredFileSchema)
});
export const PersonaWriteSchema = z.object({
    turnTotalBudgetSeconds: z.int().min(1).max(86400),
    name: z.string().min(1).max(100),
    secretSetId: z.string().min(1).max(64),
    connectorIds: z.array(z.string().min(1).max(64)),
    boxMemoryMib: z.int().min(512).max(65536),
    boxDiskMib: z.int().min(32768).max(262144),
    boxRetention: BoxRetentionSchema,
    tumpelMcp: z.boolean(),
    files: z.array(StoredFileSchema),
    harness: HarnessSchema
});
export const ListPersonasInputSchema = z.object({
    tenantId: z.string().min(1).max(64)
});
export const GetPersonaInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    personaId: z.string().min(1).max(64)
});
export const CreatePersonaInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    persona: PersonaWriteSchema,
    now: z.int()
});
export const UpdatePersonaInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    personaId: z.string().min(1).max(64),
    persona: PersonaChangeSchema,
    now: z.int()
});
export const PersonaPatchChangeSchema = z.object({
    turnTotalBudgetSeconds: z.int().min(1).max(86400).optional(),
    name: z.string().min(1).max(100).optional(),
    secretSetId: z.string().min(1).max(64).optional(),
    connectorIds: z.array(z.string().min(1).max(64)).optional(),
    boxMemoryMib: z.int().min(512).max(65536).optional(),
    boxDiskMib: z.int().min(32768).max(262144).optional(),
    boxRetention: BoxRetentionSchema.optional(),
    tumpelMcp: z.boolean().optional()
});
export const PatchPersonaInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    personaId: z.string().min(1).max(64),
    patch: PersonaPatchChangeSchema,
    now: z.int()
});
export const DeletePersonaInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    personaId: z.string().min(1).max(64)
});
export const OpenInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    now: z.int()
});
export const SupervisorUpdateInputSchema = z.object({
    hostId: z.string().min(1).max(64),
    message: z.union([SupervisorUpdateStepSchema, SupervisorUpdateFailedSchema])
});
export const SupervisorUpdatesInputSchema = z.object({
    hostIds: z.array(z.string().min(1).max(64))
});
export const ListSecretSetsInputSchema = z.object({
    tenantId: z.string().min(1).max(64)
});
export const GetSecretSetInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    secretSetId: z.string().min(1).max(64)
});
export const GitHubUserSchema = z.object({
    githubUserId: z.int(),
    login: z.string()
});
export const CreateSecretSetInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    secretSet: SecretSetCreateSchema,
    githubUser: z.union([GitHubUserSchema, z.null()]),
    now: z.int()
});
export const UpdateSecretSetInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    secretSetId: z.string().min(1).max(64),
    change: SecretSetUpdateSchema,
    githubUser: z.union([GitHubUserSchema, z.null()]),
    now: z.int()
});
export const PatchSecretSetInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    secretSetId: z.string().min(1).max(64),
    patch: SecretSetPatchSchema,
    githubUser: z.union([GitHubUserSchema, z.null()]),
    now: z.int()
});
export const SetSecretMemberInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    secretSetId: z.string().min(1).max(64),
    member: z.discriminatedUnion("kind", [SecretVariableValueSchema, ApiKeyValueSchema, SubscriptionTokenValueSchema, CredentialFileValueSchema]),
    githubUser: z.union([GitHubUserSchema, z.null()]),
    now: z.int()
});
export const RemoveSecretMemberInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    secretSetId: z.string().min(1).max(64),
    name: z.string(),
    now: z.int()
});
export const DeleteSecretSetInputSchema = z.object({
    secretSetId: z.string().min(1).max(64)
});
export const CreateSecretSetWriteSchema = z.object({
    kind: z.literal("CreateSecretSet"),
    secretSetId: z.string().min(1).max(64),
    secretSet: SecretSetCreateSchema,
    githubUser: z.union([GitHubUserSchema, z.null()])
});
export const RewriteSecretSetWriteSchema = z.object({
    kind: z.literal("RewriteSecretSet"),
    secretSetId: z.string().min(1).max(64),
    secretSet: SecretSetCreateSchema,
    githubUser: z.union([GitHubUserSchema, z.null()])
});
export const DeleteSecretSetWriteSchema = z.object({
    kind: z.literal("DeleteSecretSet"),
    secretSetId: z.string().min(1).max(64)
});
export const CreatePersonaWriteSchema = z.object({
    kind: z.literal("CreatePersona"),
    persona: PersonaWriteSchema
});
export const UpdatePersonaWriteSchema = z.object({
    kind: z.literal("UpdatePersona"),
    personaId: z.string().min(1).max(64),
    persona: PersonaChangeSchema
});
export const DeletePersonaWriteSchema = z.object({
    kind: z.literal("DeletePersona"),
    personaId: z.string().min(1).max(64)
});
export const PinWriteSchema = z.object({
    kind: z.literal("Pin"),
    pin: HarnessPinCreateSchema
});
export const UnpinWriteSchema = z.object({
    kind: z.literal("Unpin"),
    harness: z.string()
});
export const CreateTriggerWriteSchema = z.object({
    kind: z.literal("CreateTrigger"),
    trigger: ConfigTriggerSchema,
    principalId: z.string().min(1).max(64)
});
export const UpdateTriggerWriteSchema = z.object({
    kind: z.literal("UpdateTrigger"),
    triggerId: z.string().min(1).max(64),
    trigger: ConfigTriggerSchema,
    principalId: z.string().min(1).max(64)
});
export const DeleteTriggerWriteSchema = z.object({
    kind: z.literal("DeleteTrigger"),
    triggerId: z.string().min(1).max(64)
});
export const ApplyConfigInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    writes: z.array(z.discriminatedUnion("kind", [CreateSecretSetWriteSchema, RewriteSecretSetWriteSchema, DeleteSecretSetWriteSchema, CreatePersonaWriteSchema, UpdatePersonaWriteSchema, DeletePersonaWriteSchema, PinWriteSchema, UnpinWriteSchema, CreateTriggerWriteSchema, UpdateTriggerWriteSchema, DeleteTriggerWriteSchema])),
    now: z.int()
});
export const ListPinsInputSchema = z.object({});
export const PinInputSchema = z.object({
    pin: HarnessPinCreateSchema,
    now: z.int()
});
export const UnpinInputSchema = z.object({
    harness: z.string()
});
export const ListConnectorsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    now: z.int()
});
export const GetConnectorInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    connectorId: z.string().min(1).max(64),
    now: z.int()
});
export const CreateConnectorInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    auth: ConnectorAuthSchema,
    name: z.string(),
    url: z.string(),
    now: z.int()
});
export const RenameConnectorInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    connectorId: z.string().min(1).max(64),
    updatedAt: z.int(),
    name: z.string(),
    now: z.int()
});
export const DeleteConnectorInputSchema = z.object({
    connectorId: z.string().min(1).max(64),
    updatedAt: z.int()
});
export const SetStaticTokenInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    connectorId: z.string().min(1).max(64),
    updatedAt: z.int(),
    value: z.string(),
    now: z.int()
});
export const ClearConnectorCredentialInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    connectorId: z.string().min(1).max(64),
    updatedAt: z.int(),
    now: z.int()
});
export const StartConnectorAuthorizationInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    connectorId: z.string().min(1).max(64),
    updatedAt: z.int(),
    controlPlaneOrigin: z.string(),
    now: z.int()
});
export const ConnectorStateClaimsSchema = z.object({
    purpose: z.literal("ConnectorAuthorization"),
    tenantId: z.string().min(1),
    connectorId: z.string().min(1),
    connectorAuthorizationId: z.string().min(1),
    principalId: z.string().min(1)
});
export const ConnectorCallbackCodeSchema = z.object({
    kind: z.literal("Code"),
    code: z.string(),
    issuer: z.union([z.string(), z.null()])
});
export const ConnectorCallbackErrorSchema = z.object({
    kind: z.literal("Error"),
    error: z.string()
});
export const ConnectorCallbackInputSchema = z.object({
    claims: ConnectorStateClaimsSchema,
    stateHash: z.string(),
    callback: z.union([ConnectorCallbackCodeSchema, ConnectorCallbackErrorSchema]),
    initiatorIsOwner: z.boolean(),
    now: z.int()
});
export const ServeConnectorTokenInputSchema = z.object({
    turnId: z.string().min(1).max(64),
    connectorId: z.string().min(1).max(64),
    now: z.int()
});
export const UnknownConnectorsInputSchema = z.object({
    connectorIds: z.array(z.string().min(1).max(64))
});
export const NewOpenRouterAuthorizationSchema = z.object({
    secretSetId: z.string().min(1).max(64),
    controlPlaneOrigin: z.string()
});
export const StartOpenRouterAuthorizationInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    input: NewOpenRouterAuthorizationSchema,
    now: z.int()
});
export const GetOpenRouterAuthorizationInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    openRouterAuthorizationId: z.string().min(1).max(64)
});
export const OpenRouterCallbackCodeSchema = z.object({
    kind: z.literal("Code"),
    code: z.string()
});
export const OpenRouterCallbackNoCodeSchema = z.object({
    kind: z.literal("NoCode")
});
export const OpenRouterCallbackInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    openRouterAuthorizationId: z.string().min(1).max(64),
    callback: z.union([OpenRouterCallbackCodeSchema, OpenRouterCallbackNoCodeSchema]),
    now: z.int()
});
export const OpenRouterAuthorizationDeadlineSchema = z.object({
    openRouterAuthorizationId: z.string().min(1).max(64),
    at: z.int()
});
export const OpenRouterAuthorizationDeadlineReachedInputSchema = z.object({
    deadline: OpenRouterAuthorizationDeadlineSchema
});
export const OpenRouterSecretSetsInputSchema = z.object({});
export const StartCircleCIAuthorizationInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    now: z.int()
});
export const CompleteCircleCIAuthorizationInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    circleCIAuthorizationId: z.string().min(1).max(64),
    redirectedUrl: z.string(),
    now: z.int()
});
export const ChooseCircleCIOrganizationInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    circleCIAuthorizationId: z.string().min(1).max(64),
    organizationId: z.string(),
    now: z.int()
});
export const CircleCIAuthorizationDeadlineSchema = z.object({
    circleCIAuthorizationId: z.string().min(1).max(64),
    at: z.int()
});
export const CircleCIAuthorizationDeadlineReachedInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    deadline: CircleCIAuthorizationDeadlineSchema
});
export const HostRecordSchema = z.object({
    hostId: z.string().min(1).max(64),
    tenantId: z.string().min(1).max(64),
    name: z.string().min(1).max(100),
    state: HostStateSchema,
    architecture: HostArchitectureSchema,
    cpuCount: z.int().min(1),
    memoryBytes: z.int().min(1),
    publicKey: z.string().min(1),
    supervisorVersion: z.string().min(1),
    labels: z.array(z.string().regex(/^[a-z0-9][a-z0-9._=-]{0,62}$/)),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const NewClaudeSetupSchema = z.object({
    principalId: z.string().min(1).max(64),
    secretSetId: z.string().min(1).max(64),
    harness: ClaudeSetupHarnessSchema,
    harnessVersion: z.string(),
    hosts: z.array(HostRecordSchema),
    endpoint: z.string()
});
export const StartClaudeSetupInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    input: NewClaudeSetupSchema,
    now: z.int()
});
export const GetClaudeSetupInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    claudeSetupId: z.string().min(1).max(64),
    now: z.int()
});
export const ListClaudeSetupsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    secretSetId: z.string().min(1).max(64),
    now: z.int()
});
export const SubmitClaudeSetupCodeInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    claudeSetupId: z.string().min(1).max(64),
    code: z.string(),
    now: z.int()
});
export const WriteClaudeSetupTokenInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    claudeSetupId: z.string().min(1).max(64),
    credential: z.string(),
    token: z.string(),
    tokenExpiresAt: z.string().optional(),
    now: z.int()
});
export const ClaudeSetupDeadlineSchema = z.object({
    claudeSetupId: z.string().min(1).max(64),
    at: z.int()
});
export const ClaudeSetupDeadlineReachedInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    deadline: ClaudeSetupDeadlineSchema
});
export const StoredClaudeSetupOfferSchema = z.object({
    type: z.literal("ClaudeSetupBoxOffer"),
    claudeSetupId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64)
});
export const StoredClaudeSetupCodeSchema = z.object({
    type: z.literal("ClaudeSetupBoxCode"),
    claudeSetupId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64)
});
export const PrepareClaudeSetupInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    stored: z.union([StoredClaudeSetupOfferSchema, StoredClaudeSetupCodeSchema]),
    hostId: z.string().min(1).max(64),
    now: z.int()
});
export const ListPrebuildsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    repository: z.union([z.string(), z.null()])
});
export const ListLatestPrebuildsInputSchema = z.object({
    tenantId: z.string().min(1).max(64)
});
export const GetPrebuildInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    prebuildId: z.string().min(1).max(64)
});
export const PrebuildKeySchema = z.object({
    repository: z.string(),
    inputDigest: z.string(),
    guestImageDigest: z.string()
});
export const HeldPrebuildInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    key: PrebuildKeySchema
});
export const RecordPrebuildBuildingInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    prebuildId: z.string().min(1).max(64),
    now: z.int()
});
export const JobInputsTargetInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    repository: z.string(),
    headSha: z.string(),
    runId: z.int()
});
export const BindJobRunInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    prebuildId: z.string().min(1).max(64),
    runId: z.int(),
    now: z.int()
});
export const RunEventSchema = z.object({
    action: z.string(),
    runId: z.int(),
    repository: z.string(),
    path: z.string(),
    headSha: z.string(),
    htmlUrl: z.string(),
    conclusion: z.union([z.string(), z.null()])
});
export const WorkflowRunReportedInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    event: RunEventSchema,
    now: z.int()
});
export const PrebuildDeadlineSchema = z.object({
    prebuildId: z.string().min(1).max(64),
    at: z.int()
});
export const PrebuildDispatchDueSchema = z.object({
    name: z.literal("PrebuildDispatch"),
    deadline: PrebuildDeadlineSchema
});
export const PrebuildBuildDueSchema = z.object({
    name: z.literal("PrebuildBuild"),
    deadline: PrebuildDeadlineSchema
});
export const PrebuildDeadlineReachedInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    due: z.union([PrebuildDispatchDueSchema, PrebuildBuildDueSchema])
});
export const RepositoryRefSchema = z.object({
    owner: z.string(),
    name: z.string()
});
export const GitHubActionsStartSchema = z.object({
    prebuildId: z.string().min(1).max(64),
    personaId: z.string().min(1).max(64),
    target: RepositoryRefSchema,
    repository: z.string(),
    guestImageDigest: z.string(),
    rootfsKey: z.string(),
    callerWorkflow: z.string(),
    apiOrigin: z.string(),
    rebuild: z.boolean()
});
export const StartGitHubActionsPrebuildInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    start: GitHubActionsStartSchema,
    now: z.int()
});
export const PrebuildCommitStartSchema = z.object({
    prebuildId: z.string().min(1).max(64),
    personaId: z.string().min(1).max(64),
    key: PrebuildKeySchema,
    configSource: PrebuildConfigSourceSchema,
    defaultBranch: z.string(),
    headSha: z.string(),
    rootfsKey: z.string()
});
export const NewSessionSchema = z.object({
    principalId: z.string().min(1).max(64),
    startedBy: z.discriminatedUnion("kind", [PersonOriginSchema, TurnOriginSchema, TriggerOriginSchema]),
    hosts: z.array(HostRecordSchema),
    harness: HarnessSchema,
    harnessVersion: z.string(),
    endpoint: z.string(),
    start: SessionStartSchema
});
export const StartHostPrebuildInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    commit: PrebuildCommitStartSchema,
    provider: BuildProviderSchema,
    input: NewSessionSchema,
    apiOrigin: z.string(),
    now: z.int()
});
export const UploadTargetInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    prebuildId: z.string().min(1).max(64)
});
export const CircleCIUploadJobSchema = z.object({
    pipelineId: z.string(),
    headSha: z.string(),
    jobId: z.string()
});
export const BindCircleCIUploadJobInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    prebuildId: z.string().min(1).max(64),
    upload: CircleCIUploadJobSchema,
    now: z.int()
});
export const PrebuildLayerUploadSchema = z.object({
    layerDigest: z.string(),
    layerSizeBytes: z.int()
});
export const StartPrebuildUploadInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    prebuildId: z.string().min(1).max(64),
    upload: PrebuildLayerUploadSchema,
    now: z.int()
});
export const CompletePrebuildUploadInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    prebuildId: z.string().min(1).max(64),
    upload: PrebuildLayerUploadSchema,
    now: z.int()
});
export const GetPrebuildFailureInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    prebuildId: z.string().min(1).max(64)
});
export const PrebuildStartRecordSchema = z.object({
    prebuildId: z.string().min(1).max(64),
    personaId: z.string().min(1).max(64),
    key: PrebuildKeySchema,
    configSource: PrebuildConfigSourceSchema,
    target: RepositoryRefSchema,
    defaultBranch: z.string(),
    headSha: z.string(),
    rootfsKey: z.string()
});
export const DispatchCircleCIPrebuildInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    start: PrebuildStartRecordSchema,
    project: CircleCIProjectSchema,
    parameters: z.record(z.string(), z.string()),
    now: z.int()
});
export const CircleCIWorkflowCompletedEventSchema = z.object({
    type: z.string(),
    workflow: z.object({ name: z.string(), status: z.string(), url: z.string().url() }),
    pipelineId: z.string(),
    projectId: z.string()
});
export const CircleCIWorkflowCompletedInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    event: CircleCIWorkflowCompletedEventSchema,
    now: z.int()
});
export const RepositoryReadTokenInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    personaId: z.string().min(1).max(64),
    repository: RepositoryRefSchema,
    now: z.int(),
    permissions: z.record(z.string(), z.union([z.literal("read"), z.literal("write")]))
});
export const StartSessionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    input: NewSessionSchema,
    now: z.int()
});
export const IssueOfSessionSchema = z.object({
    issueNumber: z.int().min(1),
    title: z.string(),
    htmlUrl: z.string().url(),
    branch: z.string()
});
export const StartSessionFromIssueInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    input: NewSessionSchema,
    issue: IssueOfSessionSchema,
    now: z.int()
});
export const SendTurnInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    send: TurnSendSchema,
    hosts: z.array(HostRecordSchema),
    now: z.int()
});
export const StopSessionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    cancelledBy: z.union([z.string(), z.null()]),
    now: z.int()
});
export const ArchiveSessionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    now: z.int()
});
export const SetSessionTagsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    tags: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).max(16),
    now: z.int()
});
export const PatchSessionTagsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    patch: SessionTagsPatchSchema,
    now: z.int()
});
export const DeleteSessionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64)
});
export const GetSessionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64)
});
export const SessionFilterSchema = z.object({
    state: SessionStateSchema.optional(),
    hostId: z.string().min(1).max(64).optional(),
    lastTurnBefore: z.int().optional(),
    tags: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/)).max(16).optional(),
    triggerId: z.string().min(1).max(64).optional()
});
export const ListSessionsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    filter: SessionFilterSchema
});
export const ListTurnsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64)
});
export const GetTurnInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64)
});
export const SteerTurnInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64),
    steer: SteerCreateSchema,
    now: z.int()
});
export const ListSteersInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64)
});
export const TakeSteersInputSchema = z.object({
    turnId: z.string().min(1).max(64),
    now: z.int()
});
export const CancelTurnInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64),
    cancelledBy: z.string(),
    now: z.int()
});
export const WaitTurnsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    turnIds: z.array(z.string().min(1).max(64)),
    timeoutSeconds: z.int()
});
export const ListEventsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    afterEventId: z.union([z.int().min(0), z.null()]),
    events: z.array(TenantEventTypeSchema),
    sessionId: z.union([z.string().min(1).max(64), z.null()]),
    triggerId: z.union([z.string().min(1).max(64), z.null()]),
    waitSeconds: z.int().min(0).max(50)
});
export const ListWebhookEndpointsInputSchema = z.object({
    tenantId: z.string().min(1).max(64)
});
export const CreateWebhookEndpointInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    endpoint: WebhookEndpointCreateSchema,
    now: z.int()
});
export const GetWebhookEndpointInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    webhookEndpointId: z.string().min(1).max(64)
});
export const DeleteWebhookEndpointInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    webhookEndpointId: z.string().min(1).max(64)
});
export const SetWebhookEndpointStatusInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    webhookEndpointId: z.string().min(1).max(64),
    status: z.discriminatedUnion("delivery", [WebhookDeliveringSchema, WebhookFailingSchema])
});
export const ListPushSubscriptionsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64)
});
export const CreatePushSubscriptionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    subscription: PushSubscriptionCreateSchema,
    now: z.int()
});
export const DeletePushSubscriptionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    principalId: z.string().min(1).max(64),
    pushSubscriptionId: z.string().min(1).max(64)
});
export const ForgetPushSubscriptionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    pushSubscriptionId: z.string().min(1).max(64)
});
export const PushTargetInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    pushSubscriptionId: z.string().min(1).max(64)
});
export const CreateSubscriptionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    subscription: SubscriptionCreateSchema,
    now: z.int()
});
export const SubscriptionFilterSchema = z.object({
    sessionId: z.string().min(1).max(64).optional(),
    state: SubscriptionStateSchema.optional()
});
export const ListSubscriptionsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    filter: SubscriptionFilterSchema
});
export const GetSubscriptionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    subscriptionId: z.string().min(1).max(64)
});
export const PauseSubscriptionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    subscriptionId: z.string().min(1).max(64),
    message: z.string().min(1).max(500),
    now: z.int()
});
export const ResumeSubscriptionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    subscriptionId: z.string().min(1).max(64),
    now: z.int()
});
export const DeleteSubscriptionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    subscriptionId: z.string().min(1).max(64),
    now: z.int()
});
export const CompleteSubscriptionInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    subscriptionId: z.string().min(1).max(64),
    now: z.int()
});
export const CreateTriggerInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    trigger: TriggerCreateSchema,
    principalId: z.string().min(1).max(64),
    now: z.int()
});
export const ListTriggersInputSchema = z.object({
    tenantId: z.string().min(1).max(64)
});
export const GetTriggerInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    triggerId: z.string().min(1).max(64)
});
export const UpdateTriggerInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    triggerId: z.string().min(1).max(64),
    patch: TriggerPatchSchema,
    principalId: z.string().min(1).max(64),
    now: z.int()
});
export const DeleteTriggerInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    triggerId: z.string().min(1).max(64),
    now: z.int()
});
export const TriggerFiredMatchedSchema = z.object({
    kind: z.literal("Matched"),
    repository: z.string().min(1).max(500),
    prompt: z.string().min(1).max(100000)
});
export const TriggerFiredRefusedSchema = z.object({
    kind: z.literal("Refused"),
    refusal: TriggerStartRefusalSchema
});
export const TriggerFiredInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    triggerId: z.string().min(1).max(64),
    deliveryId: z.string().min(1).max(200),
    fired: z.union([TriggerFiredMatchedSchema, TriggerFiredRefusedSchema]),
    now: z.int()
});
export const GetTurnFailureInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64)
});
export const ListStopFailuresInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64)
});
export const ListSnapshotsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64)
});
export const ListCredentialHandoversInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64)
});
export const GetSnapshotInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    snapshotId: z.string().min(1).max(64)
});
export const TranscriptCursorInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    after: z.int(),
    turnId: z.union([z.string().min(1).max(64), z.null()]),
    limit: z.int(),
    maxBytes: z.int().optional()
});
export const ConnectedAccountsInputSchema = z.object({});
export const DeleteBuildConnectionInputSchema = z.object({
    provider: BuildProviderSchema
});
export const CircleCIConnectionInputSchema = z.object({});
export const CircleCITokenInputSchema = z.object({});
export const ConnectCircleCIInputSchema = z.object({
    start: CircleCIConnectionStartSchema,
    now: z.int()
});
export const ListCircleCIProjectsInputSchema = z.object({
    tenantId: z.string().min(1).max(64)
});
export const CircleCIProjectBoundToInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    projectId: z.string()
});
export const CircleCIProjectOfInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    repository: z.string()
});
export const CircleCIBindingSchema = z.object({
    repository: z.string(),
    projectSlug: z.string(),
    projectId: z.string(),
    pipelineDefinitionId: z.string(),
    webhookId: z.string(),
    signingSecret: z.string()
});
export const AddCircleCIProjectInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    binding: CircleCIBindingSchema,
    now: z.int()
});
export const CircleCIWebhooksInputSchema = z.object({});
export const CircleCIWebhookSecretInputSchema = z.object({
    projectId: z.string()
});
export const DeleteCircleCIProjectInputSchema = z.object({
    circleCIProjectId: z.string().min(1).max(64)
});
export const GitHubActionsConnectionInputSchema = z.object({
    tenantId: z.string().min(1).max(64)
});
export const ConnectGitHubActionsInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    start: GitHubActionsConnectionStartSchema,
    now: z.int()
});
export const NamespaceConnectionInputSchema = z.object({});
export const ConnectNamespaceInputSchema = z.object({
    start: NamespaceConnectionStartSchema,
    now: z.int()
});
export const OfferSentInputSchema = z.object({
    turnId: z.string().min(1).max(64)
});
export const HostHelloInputSchema = z.object({
    hostId: z.string().min(1).max(64),
    boxCapacity: z.int(),
    usage: HostUsageSchema,
    now: z.int(),
    channelProtocol: z.int()
});
export const HostUsageInputSchema = z.object({
    hostId: z.string().min(1).max(64),
    usage: HostUsageSchema,
    now: z.int()
});
export const ReconcileHeldBoxesInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    hostId: z.string().min(1).max(64),
    heldSessionIds: z.array(z.string().min(1).max(64)),
    now: z.int()
});
export const ForgetHostUsageInputSchema = z.object({
    hostId: z.string().min(1).max(64)
});
export const RunningTurnsByHostInputSchema = z.object({});
export const ListHostUsageInputSchema = z.object({
    tenantId: z.string().min(1).max(64)
});
export const DeferredOffersInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    hostId: z.string().min(1).max(64)
});
export const TurnMetricDimensionsInputSchema = z.object({
    turnIds: z.array(z.string().min(1).max(64))
});
export const PrepareOfferInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    turnId: z.string().min(1).max(64),
    hostId: z.string().min(1).max(64),
    now: z.int()
});
export const HostPresenceInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    hostId: z.string().min(1).max(64),
    presence: HostPresenceSchema,
    now: z.int()
});
export const HostMessageInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    hostId: z.string().min(1).max(64),
    message: z.union([TurnImageFetchingSchema, TurnClaimSchema, TurnRepositoryReadySchema, TurnLineSchema, TurnCompleteSchema, TurnRepositoryCloneFailedSchema, TurnFailedSchema, SnapshotChunksSchema, SnapshotPacksSchema, RestoreChunksSchema, SnapshotDoneSchema, SnapshotFailedSchema, BoxGoneSchema, BoxTeardownFailedSchema, ClaudeSetupBoxUrlSchema, ClaudeSetupBoxFailedSchema])
});
export const TurnDeadlineSchema = z.object({
    turnId: z.string().min(1).max(64),
    at: z.int()
});
export const SessionDueDeadlineSchema = z.object({
    name: SessionDeadlineNameSchema,
    deadline: TurnDeadlineSchema
});
export const DeadlineReachedInputSchema = z.object({
    tenantId: z.string().min(1).max(64),
    due: SessionDueDeadlineSchema
});
export const ListPersonasRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listPersonas"),
    input: ListPersonasInputSchema
});
export const GetPersonaRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getPersona"),
    input: GetPersonaInputSchema
});
export const CreatePersonaRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("createPersona"),
    input: CreatePersonaInputSchema
});
export const UpdatePersonaRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("updatePersona"),
    input: UpdatePersonaInputSchema
});
export const PatchPersonaRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("patchPersona"),
    input: PatchPersonaInputSchema
});
export const DeletePersonaRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("deletePersona"),
    input: DeletePersonaInputSchema
});
export const OpenRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("open"),
    input: OpenInputSchema
});
export const SupervisorUpdateRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("supervisorUpdate"),
    input: SupervisorUpdateInputSchema
});
export const SupervisorUpdatesRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("supervisorUpdates"),
    input: SupervisorUpdatesInputSchema
});
export const ListSecretSetsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listSecretSets"),
    input: ListSecretSetsInputSchema
});
export const GetSecretSetRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getSecretSet"),
    input: GetSecretSetInputSchema
});
export const CreateSecretSetRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("createSecretSet"),
    input: CreateSecretSetInputSchema
});
export const UpdateSecretSetRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("updateSecretSet"),
    input: UpdateSecretSetInputSchema
});
export const PatchSecretSetRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("patchSecretSet"),
    input: PatchSecretSetInputSchema
});
export const SetSecretMemberRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("setSecretMember"),
    input: SetSecretMemberInputSchema
});
export const RemoveSecretMemberRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("removeSecretMember"),
    input: RemoveSecretMemberInputSchema
});
export const DeleteSecretSetRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("deleteSecretSet"),
    input: DeleteSecretSetInputSchema
});
export const ApplyConfigRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("applyConfig"),
    input: ApplyConfigInputSchema
});
export const ListPinsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listPins"),
    input: ListPinsInputSchema
});
export const PinRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("pin"),
    input: PinInputSchema
});
export const UnpinRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("unpin"),
    input: UnpinInputSchema
});
export const ListConnectorsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listConnectors"),
    input: ListConnectorsInputSchema
});
export const GetConnectorRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getConnector"),
    input: GetConnectorInputSchema
});
export const CreateConnectorRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("createConnector"),
    input: CreateConnectorInputSchema
});
export const RenameConnectorRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("renameConnector"),
    input: RenameConnectorInputSchema
});
export const DeleteConnectorRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("deleteConnector"),
    input: DeleteConnectorInputSchema
});
export const SetStaticTokenRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("setStaticToken"),
    input: SetStaticTokenInputSchema
});
export const ClearConnectorCredentialRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("clearConnectorCredential"),
    input: ClearConnectorCredentialInputSchema
});
export const StartConnectorAuthorizationRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("startConnectorAuthorization"),
    input: StartConnectorAuthorizationInputSchema
});
export const ConnectorCallbackRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("connectorCallback"),
    input: ConnectorCallbackInputSchema
});
export const ServeConnectorTokenRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("serveConnectorToken"),
    input: ServeConnectorTokenInputSchema
});
export const UnknownConnectorsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("unknownConnectors"),
    input: UnknownConnectorsInputSchema
});
export const StartOpenRouterAuthorizationRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("startOpenRouterAuthorization"),
    input: StartOpenRouterAuthorizationInputSchema
});
export const GetOpenRouterAuthorizationRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getOpenRouterAuthorization"),
    input: GetOpenRouterAuthorizationInputSchema
});
export const OpenRouterCallbackRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("openRouterCallback"),
    input: OpenRouterCallbackInputSchema
});
export const OpenRouterAuthorizationDeadlineReachedRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("openRouterAuthorizationDeadlineReached"),
    input: OpenRouterAuthorizationDeadlineReachedInputSchema
});
export const OpenRouterSecretSetsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("openRouterSecretSets"),
    input: OpenRouterSecretSetsInputSchema
});
export const StartCircleCIAuthorizationRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("startCircleCIAuthorization"),
    input: StartCircleCIAuthorizationInputSchema
});
export const CompleteCircleCIAuthorizationRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("completeCircleCIAuthorization"),
    input: CompleteCircleCIAuthorizationInputSchema
});
export const ChooseCircleCIOrganizationRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("chooseCircleCIOrganization"),
    input: ChooseCircleCIOrganizationInputSchema
});
export const CircleCIAuthorizationDeadlineReachedRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("circleCIAuthorizationDeadlineReached"),
    input: CircleCIAuthorizationDeadlineReachedInputSchema
});
export const StartClaudeSetupRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("startClaudeSetup"),
    input: StartClaudeSetupInputSchema
});
export const GetClaudeSetupRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getClaudeSetup"),
    input: GetClaudeSetupInputSchema
});
export const ListClaudeSetupsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listClaudeSetups"),
    input: ListClaudeSetupsInputSchema
});
export const SubmitClaudeSetupCodeRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("submitClaudeSetupCode"),
    input: SubmitClaudeSetupCodeInputSchema
});
export const WriteClaudeSetupTokenRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("writeClaudeSetupToken"),
    input: WriteClaudeSetupTokenInputSchema
});
export const ClaudeSetupDeadlineReachedRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("claudeSetupDeadlineReached"),
    input: ClaudeSetupDeadlineReachedInputSchema
});
export const PrepareClaudeSetupRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("prepareClaudeSetup"),
    input: PrepareClaudeSetupInputSchema
});
export const ListPrebuildsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listPrebuilds"),
    input: ListPrebuildsInputSchema
});
export const ListLatestPrebuildsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listLatestPrebuilds"),
    input: ListLatestPrebuildsInputSchema
});
export const GetPrebuildRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getPrebuild"),
    input: GetPrebuildInputSchema
});
export const HeldPrebuildRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("heldPrebuild"),
    input: HeldPrebuildInputSchema
});
export const RecordPrebuildBuildingRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("recordPrebuildBuilding"),
    input: RecordPrebuildBuildingInputSchema
});
export const JobInputsTargetRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("jobInputsTarget"),
    input: JobInputsTargetInputSchema
});
export const BindJobRunRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("bindJobRun"),
    input: BindJobRunInputSchema
});
export const WorkflowRunReportedRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("workflowRunReported"),
    input: WorkflowRunReportedInputSchema
});
export const PrebuildDeadlineReachedRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("prebuildDeadlineReached"),
    input: PrebuildDeadlineReachedInputSchema
});
export const StartGitHubActionsPrebuildRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("startGitHubActionsPrebuild"),
    input: StartGitHubActionsPrebuildInputSchema
});
export const StartHostPrebuildRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("startHostPrebuild"),
    input: StartHostPrebuildInputSchema
});
export const UploadTargetRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("uploadTarget"),
    input: UploadTargetInputSchema
});
export const BindCircleCIUploadJobRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("bindCircleCIUploadJob"),
    input: BindCircleCIUploadJobInputSchema
});
export const StartPrebuildUploadRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("startPrebuildUpload"),
    input: StartPrebuildUploadInputSchema
});
export const CompletePrebuildUploadRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("completePrebuildUpload"),
    input: CompletePrebuildUploadInputSchema
});
export const GetPrebuildFailureRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getPrebuildFailure"),
    input: GetPrebuildFailureInputSchema
});
export const DispatchCircleCIPrebuildRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("dispatchCircleCIPrebuild"),
    input: DispatchCircleCIPrebuildInputSchema
});
export const CircleCIWorkflowCompletedRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("circleCIWorkflowCompleted"),
    input: CircleCIWorkflowCompletedInputSchema
});
export const RepositoryReadTokenRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("repositoryReadToken"),
    input: RepositoryReadTokenInputSchema
});
export const StartSessionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("startSession"),
    input: StartSessionInputSchema
});
export const StartSessionFromIssueRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("startSessionFromIssue"),
    input: StartSessionFromIssueInputSchema
});
export const SendTurnRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("sendTurn"),
    input: SendTurnInputSchema
});
export const StopSessionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("stopSession"),
    input: StopSessionInputSchema
});
export const ArchiveSessionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("archiveSession"),
    input: ArchiveSessionInputSchema
});
export const SetSessionTagsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("setSessionTags"),
    input: SetSessionTagsInputSchema
});
export const PatchSessionTagsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("patchSessionTags"),
    input: PatchSessionTagsInputSchema
});
export const DeleteSessionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("deleteSession"),
    input: DeleteSessionInputSchema
});
export const GetSessionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getSession"),
    input: GetSessionInputSchema
});
export const ListSessionsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listSessions"),
    input: ListSessionsInputSchema
});
export const ListTurnsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listTurns"),
    input: ListTurnsInputSchema
});
export const GetTurnRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getTurn"),
    input: GetTurnInputSchema
});
export const CancelTurnRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("cancelTurn"),
    input: CancelTurnInputSchema
});
export const SteerTurnRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("steerTurn"),
    input: SteerTurnInputSchema
});
export const ListSteersRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listSteers"),
    input: ListSteersInputSchema
});
export const TakeSteersRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("takeSteers"),
    input: TakeSteersInputSchema
});
export const WaitTurnsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("waitTurns"),
    input: WaitTurnsInputSchema
});
export const ListEventsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listEvents"),
    input: ListEventsInputSchema
});
export const ListWebhookEndpointsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listWebhookEndpoints"),
    input: ListWebhookEndpointsInputSchema
});
export const CreateWebhookEndpointRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("createWebhookEndpoint"),
    input: CreateWebhookEndpointInputSchema
});
export const GetWebhookEndpointRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getWebhookEndpoint"),
    input: GetWebhookEndpointInputSchema
});
export const DeleteWebhookEndpointRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("deleteWebhookEndpoint"),
    input: DeleteWebhookEndpointInputSchema
});
export const SetWebhookEndpointStatusRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("setWebhookEndpointStatus"),
    input: SetWebhookEndpointStatusInputSchema
});
export const ListPushSubscriptionsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listPushSubscriptions"),
    input: ListPushSubscriptionsInputSchema
});
export const CreatePushSubscriptionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("createPushSubscription"),
    input: CreatePushSubscriptionInputSchema
});
export const DeletePushSubscriptionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("deletePushSubscription"),
    input: DeletePushSubscriptionInputSchema
});
export const ForgetPushSubscriptionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("forgetPushSubscription"),
    input: ForgetPushSubscriptionInputSchema
});
export const PushTargetRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("pushTarget"),
    input: PushTargetInputSchema
});
export const CreateSubscriptionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("createSubscription"),
    input: CreateSubscriptionInputSchema
});
export const ListSubscriptionsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listSubscriptions"),
    input: ListSubscriptionsInputSchema
});
export const GetSubscriptionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getSubscription"),
    input: GetSubscriptionInputSchema
});
export const PauseSubscriptionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("pauseSubscription"),
    input: PauseSubscriptionInputSchema
});
export const ResumeSubscriptionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("resumeSubscription"),
    input: ResumeSubscriptionInputSchema
});
export const DeleteSubscriptionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("deleteSubscription"),
    input: DeleteSubscriptionInputSchema
});
export const CompleteSubscriptionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("completeSubscription"),
    input: CompleteSubscriptionInputSchema
});
export const CreateTriggerRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("createTrigger"),
    input: CreateTriggerInputSchema
});
export const ListTriggersRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listTriggers"),
    input: ListTriggersInputSchema
});
export const GetTriggerRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getTrigger"),
    input: GetTriggerInputSchema
});
export const UpdateTriggerRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("updateTrigger"),
    input: UpdateTriggerInputSchema
});
export const DeleteTriggerRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("deleteTrigger"),
    input: DeleteTriggerInputSchema
});
export const TriggerFiredRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("triggerFired"),
    input: TriggerFiredInputSchema
});
export const GetTurnFailureRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getTurnFailure"),
    input: GetTurnFailureInputSchema
});
export const ListStopFailuresRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listStopFailures"),
    input: ListStopFailuresInputSchema
});
export const ListSnapshotsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listSnapshots"),
    input: ListSnapshotsInputSchema
});
export const ListCredentialHandoversRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listCredentialHandovers"),
    input: ListCredentialHandoversInputSchema
});
export const GetSnapshotRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("getSnapshot"),
    input: GetSnapshotInputSchema
});
export const TranscriptCursorRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("transcriptCursor"),
    input: TranscriptCursorInputSchema
});
export const ConnectedAccountsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("connectedAccounts"),
    input: ConnectedAccountsInputSchema
});
export const DeleteBuildConnectionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("deleteBuildConnection"),
    input: DeleteBuildConnectionInputSchema
});
export const CircleCIConnectionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("circleCIConnection"),
    input: CircleCIConnectionInputSchema
});
export const CircleCITokenRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("circleCIToken"),
    input: CircleCITokenInputSchema
});
export const ConnectCircleCIRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("connectCircleCI"),
    input: ConnectCircleCIInputSchema
});
export const ListCircleCIProjectsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listCircleCIProjects"),
    input: ListCircleCIProjectsInputSchema
});
export const CircleCIProjectBoundToRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("circleCIProjectBoundTo"),
    input: CircleCIProjectBoundToInputSchema
});
export const CircleCIProjectOfRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("circleCIProjectOf"),
    input: CircleCIProjectOfInputSchema
});
export const AddCircleCIProjectRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("addCircleCIProject"),
    input: AddCircleCIProjectInputSchema
});
export const CircleCIWebhooksRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("circleCIWebhooks"),
    input: CircleCIWebhooksInputSchema
});
export const CircleCIWebhookSecretRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("circleCIWebhookSecret"),
    input: CircleCIWebhookSecretInputSchema
});
export const DeleteCircleCIProjectRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("deleteCircleCIProject"),
    input: DeleteCircleCIProjectInputSchema
});
export const GitHubActionsConnectionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("gitHubActionsConnection"),
    input: GitHubActionsConnectionInputSchema
});
export const ConnectGitHubActionsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("connectGitHubActions"),
    input: ConnectGitHubActionsInputSchema
});
export const NamespaceConnectionRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("namespaceConnection"),
    input: NamespaceConnectionInputSchema
});
export const ConnectNamespaceRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("connectNamespace"),
    input: ConnectNamespaceInputSchema
});
export const OfferSentRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("offerSent"),
    input: OfferSentInputSchema
});
export const HostHelloRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("hostHello"),
    input: HostHelloInputSchema
});
export const HostUsageRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("hostUsage"),
    input: HostUsageInputSchema
});
export const ReconcileHeldBoxesRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("reconcileHeldBoxes"),
    input: ReconcileHeldBoxesInputSchema
});
export const ForgetHostUsageRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("forgetHostUsage"),
    input: ForgetHostUsageInputSchema
});
export const RunningTurnsByHostRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("runningTurnsByHost"),
    input: RunningTurnsByHostInputSchema
});
export const ListHostUsageRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("listHostUsage"),
    input: ListHostUsageInputSchema
});
export const DeferredOffersRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("deferredOffers"),
    input: DeferredOffersInputSchema
});
export const TurnMetricDimensionsRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("turnMetricDimensions"),
    input: TurnMetricDimensionsInputSchema
});
export const PrepareOfferRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("prepareOffer"),
    input: PrepareOfferInputSchema
});
export const HostPresenceRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("hostPresence"),
    input: HostPresenceInputSchema
});
export const HostMessageRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("hostMessage"),
    input: HostMessageInputSchema
});
export const DeadlineReachedRequestSchema = z.object({
    tenantApiVersion: z.int().min(1).max(10),
    operation: z.literal("deadlineReached"),
    input: DeadlineReachedInputSchema
});
export const TenantApiVersionUnsupportedSchema = z.object({
    refusal: z.literal("TenantApiVersionUnsupported"),
    oldestTenantApiVersion: z.int(),
    tenantApiVersion: z.int()
});
export const TenantOperationUnknownSchema = z.object({
    refusal: z.literal("TenantOperationUnknown"),
    operation: z.string()
});
export const TenantRequestInvalidSchema = z.object({
    refusal: z.literal("TenantRequestInvalid"),
    operation: z.string(),
    issues: z.array(z.string())
});
export const WriteConflictSchema = z.object({
    ok: z.literal(false),
    constraint: z.string()
});
export const PersonaWrittenSchema = z.object({
    ok: z.literal(true),
    value: StoredPersonaSchema
});
export const PersonaUpdatedSchema = z.object({
    ok: z.literal(true),
    value: z.union([StoredPersonaSchema, z.null()])
});
export const ListPersonasResultSchema = z.object({
    personas: z.array(StoredPersonaSchema)
});
export const GetPersonaResultSchema = z.object({
    persona: z.union([StoredPersonaSchema, z.null()])
});
export const CreatePersonaResultSchema = z.object({
    written: z.union([PersonaWrittenSchema, WriteConflictSchema])
});
export const UpdatePersonaResultSchema = z.object({
    written: z.union([PersonaUpdatedSchema, WriteConflictSchema])
});
export const PatchPersonaResultSchema = z.object({
    written: z.union([PersonaUpdatedSchema, WriteConflictSchema])
});
export const PersonaDeletedSchema = z.object({
    kind: z.literal("Deleted")
});
export const PersonaNotFoundSchema = z.object({
    kind: z.literal("NotFound")
});
export const PersonaInUseSchema = z.object({
    kind: z.literal("InUse"),
    sessions: z.array(z.string().min(1).max(64))
});
export const DeletePersonaResultSchema = z.object({
    deleted: z.union([PersonaDeletedSchema, PersonaNotFoundSchema, PersonaInUseSchema])
});
export const OpenResultSchema = z.object({});
export const SupervisorUpdateResultSchema = z.object({});
export const SupervisorUpdatesSchema = z.object({
    supervisorUpdateStep: z.discriminatedUnion("state", [SupervisorUpdateNotReportedSchema, SupervisorUpdateStepReportedSchema]),
    supervisorUpdateFailure: z.discriminatedUnion("state", [SupervisorUpdateNotReportedSchema, SupervisorUpdateFailureReportedSchema])
});
export const SupervisorUpdatesResultSchema = z.object({
    byHost: z.record(z.string(), SupervisorUpdatesSchema)
});
export const SecretSetUnreadableSchema = z.object({
    kind: z.literal("Unreadable"),
    secretSetId: z.string().min(1).max(64),
    name: z.string(),
    member: z.string(),
    detail: z.string()
});
export const SecretSetsReadSchema = z.object({
    kind: z.literal("Read"),
    secretSets: z.array(SecretSetSchema)
});
export const ListSecretSetsResultSchema = z.object({
    read: z.union([SecretSetsReadSchema, SecretSetUnreadableSchema])
});
export const SecretSetFoundSchema = z.object({
    kind: z.literal("Found"),
    secretSet: SecretSetSchema
});
export const SecretSetNotFoundSchema = z.object({
    kind: z.literal("NotFound")
});
export const GetSecretSetResultSchema = z.object({
    read: z.union([SecretSetFoundSchema, SecretSetNotFoundSchema, SecretSetUnreadableSchema])
});
export const SecretSetWrittenSchema = z.object({
    ok: z.literal(true),
    value: SecretSetSchema
});
export const CreateSecretSetResultSchema = z.object({
    written: z.union([SecretSetWrittenSchema, WriteConflictSchema])
});
export const SecretSetUpdatedSchema = z.object({
    kind: z.literal("Updated"),
    secretSet: SecretSetSchema
});
export const SecretSetMissingSchema = z.object({
    kind: z.literal("SetNotFound")
});
export const SecretSetConflictSchema = z.object({
    kind: z.literal("Conflict"),
    constraint: z.string()
});
export const SecretSetNoStoredValueSchema = z.object({
    kind: z.literal("NoStoredValue"),
    name: z.string(),
    source: z.string()
});
export const SecretSetUncheckedTokenSchema = z.object({
    kind: z.literal("UncheckedToken"),
    source: z.string()
});
export const UpdateSecretSetResultSchema = z.object({
    updated: z.union([SecretSetUpdatedSchema, SecretSetMissingSchema, SecretSetConflictSchema, SecretSetNoStoredValueSchema, SecretSetUncheckedTokenSchema])
});
export const PatchSecretSetResultSchema = z.object({
    patched: z.union([SecretSetUpdatedSchema, SecretSetMissingSchema, SecretSetConflictSchema, SecretSetNoStoredValueSchema, SecretSetUncheckedTokenSchema])
});
export const SecretMemberWrittenSchema = z.object({
    kind: z.literal("Set"),
    secretSet: SecretSetSchema
});
export const SetSecretMemberResultSchema = z.object({
    set: z.union([SecretMemberWrittenSchema, SecretSetMissingSchema, SecretSetConflictSchema, SecretSetUnreadableSchema])
});
export const SecretMemberRemovedSchema = z.object({
    kind: z.literal("Removed"),
    secretSet: SecretSetSchema
});
export const SecretMemberNotFoundSchema = z.object({
    kind: z.literal("MemberNotFound")
});
export const RemoveSecretMemberResultSchema = z.object({
    removed: z.union([SecretMemberRemovedSchema, SecretSetMissingSchema, SecretMemberNotFoundSchema, SecretSetUnreadableSchema])
});
export const SecretSetDeletedSchema = z.object({
    kind: z.literal("Deleted")
});
export const SecretSetInUseSchema = z.object({
    kind: z.literal("InUse"),
    personas: z.array(z.string())
});
export const DeleteSecretSetResultSchema = z.object({
    deleted: z.union([SecretSetDeletedSchema, SecretSetNotFoundSchema, SecretSetInUseSchema])
});
export const ConfigAppliedSchema = z.object({
    kind: z.literal("Applied")
});
export const ConfigConflictSchema = z.object({
    kind: z.literal("Conflict"),
    constraint: z.string()
});
export const ConfigResourceDeletedSchema = z.object({
    kind: z.literal("Deleted"),
    resource: z.string()
});
export const ApplyConfigResultSchema = z.object({
    applied: z.union([ConfigAppliedSchema, ConfigConflictSchema, ConfigResourceDeletedSchema])
});
export const ListPinsResultSchema = z.object({
    pins: z.array(HarnessPinSchema)
});
export const PinResultSchema = z.object({
    pin: HarnessPinSchema
});
export const UnpinResultSchema = z.object({
    unpinned: z.boolean()
});
export const ListConnectorsResultSchema = z.object({
    connectors: z.array(z.discriminatedUnion("auth", [StaticConnectorSchema, OAuthConnectorSchema]))
});
export const GetConnectorResultSchema = z.object({
    connector: z.union([z.discriminatedUnion("auth", [StaticConnectorSchema, OAuthConnectorSchema]), z.null()])
});
export const ConnectorWrittenOkSchema = z.object({
    kind: z.literal("Written"),
    connector: z.discriminatedUnion("auth", [StaticConnectorSchema, OAuthConnectorSchema])
});
export const ConnectorNotFoundSchema = z.object({
    kind: z.literal("NotFound")
});
export const ConnectorNameTakenSchema = z.object({
    kind: z.literal("NameTaken")
});
export const ConnectorChangedSchema = z.object({
    kind: z.literal("Changed")
});
export const ConnectorWrittenResultSchema = z.object({
    written: z.union([ConnectorWrittenOkSchema, ConnectorNotFoundSchema, ConnectorNameTakenSchema, ConnectorChangedSchema])
});
export const ConnectorDeletedOkSchema = z.object({
    kind: z.literal("Deleted")
});
export const ConnectorInUseSchema = z.object({
    kind: z.literal("InUse"),
    detail: z.string()
});
export const DeleteConnectorResultSchema = z.object({
    deleted: z.union([ConnectorDeletedOkSchema, ConnectorNotFoundSchema, ConnectorChangedSchema, ConnectorInUseSchema])
});
export const ConnectorAuthorizeStartedOkSchema = z.object({
    kind: z.literal("Started"),
    authorization: ConnectorAuthorizationSchema
});
export const ConnectorDiscoveryFailedSchema = z.object({
    kind: z.literal("DiscoveryFailed"),
    detail: z.string()
});
export const ConnectorRegistrationUnsupportedSchema = z.object({
    kind: z.literal("RegistrationUnsupported"),
    detail: z.string()
});
export const StartConnectorAuthorizationResultSchema = z.object({
    started: z.union([ConnectorAuthorizeStartedOkSchema, ConnectorNotFoundSchema, ConnectorChangedSchema, ConnectorDiscoveryFailedSchema, ConnectorRegistrationUnsupportedSchema])
});
export const ConnectorCallbackConnectedSchema = z.object({
    kind: z.literal("Connected"),
    name: z.string()
});
export const ConnectorCallbackNotConnectedSchema = z.object({
    kind: z.literal("NotConnected"),
    detail: z.string()
});
export const ConnectorCallbackResultSchema = z.object({
    settled: z.union([ConnectorCallbackConnectedSchema, ConnectorCallbackNotConnectedSchema])
});
export const ConnectorTokenServedOkSchema = z.object({
    kind: z.literal("Served"),
    token: ConnectorAccessTokenSchema
});
export const ConnectorTokenRefusedSchema = z.object({
    kind: z.literal("Refused")
});
export const ConnectorTurnNotRunningSchema = z.object({
    kind: z.literal("NotRunning")
});
export const ConnectorNoCredentialSchema = z.object({
    kind: z.literal("NoCredential"),
    name: z.string()
});
export const ConnectorRefreshFailedSchema = z.object({
    kind: z.literal("RefreshFailed"),
    detail: z.string()
});
export const ServeConnectorTokenResultSchema = z.object({
    served: z.union([ConnectorTokenServedOkSchema, ConnectorTokenRefusedSchema, ConnectorTurnNotRunningSchema, ConnectorNoCredentialSchema, ConnectorRefreshFailedSchema])
});
export const UnknownConnectorsResultSchema = z.object({
    unknownConnectorIds: z.array(z.string().min(1).max(64))
});
export const CreateConnectorResultSchema = z.object({
    written: z.union([ConnectorWrittenOkSchema, ConnectorNotFoundSchema, ConnectorNameTakenSchema, ConnectorChangedSchema])
});
export const RenameConnectorResultSchema = z.object({
    written: z.union([ConnectorWrittenOkSchema, ConnectorNotFoundSchema, ConnectorNameTakenSchema, ConnectorChangedSchema])
});
export const SetStaticTokenResultSchema = z.object({
    written: z.union([ConnectorWrittenOkSchema, ConnectorNotFoundSchema, ConnectorNameTakenSchema, ConnectorChangedSchema])
});
export const ClearConnectorCredentialResultSchema = z.object({
    written: z.union([ConnectorWrittenOkSchema, ConnectorNotFoundSchema, ConnectorNameTakenSchema, ConnectorChangedSchema])
});
export const OpenRouterAuthorizationStartedOkSchema = z.object({
    kind: z.literal("Started"),
    authorization: OpenRouterAuthorizationSchema
});
export const AuthorizationNoSecretSetSchema = z.object({
    kind: z.literal("NoSecretSet")
});
export const AuthorizationOtherCredentialSchema = z.object({
    kind: z.literal("OtherCredential"),
    name: z.string()
});
export const StartOpenRouterAuthorizationResultSchema = z.object({
    started: z.union([OpenRouterAuthorizationStartedOkSchema, AuthorizationNoSecretSetSchema, AuthorizationOtherCredentialSchema])
});
export const OpenRouterAuthorizationFoundSchema = z.object({
    kind: z.literal("Found"),
    authorization: OpenRouterAuthorizationSchema
});
export const AuthorizationNotFoundSchema = z.object({
    kind: z.literal("NotFound")
});
export const GetOpenRouterAuthorizationResultSchema = z.object({
    read: z.union([OpenRouterAuthorizationFoundSchema, AuthorizationNotFoundSchema])
});
export const OpenRouterReturnedSchema = z.object({
    kind: z.literal("Returned"),
    secretSetId: z.string().min(1).max(64)
});
export const OpenRouterCallbackResultSchema = z.object({
    settled: z.union([OpenRouterReturnedSchema, AuthorizationNotFoundSchema])
});
export const OpenRouterAuthorizationDeadlineReachedResultSchema = z.object({});
export const OpenRouterSecretSetsResultSchema = z.object({
    names: z.array(z.string())
});
export const CircleCIAuthorizationStartedOkSchema = z.object({
    kind: z.literal("Started"),
    authorization: CircleCIAuthorizationSchema
});
export const CircleCIRegistrationRefusedSchema = z.object({
    kind: z.literal("RegistrationRefused"),
    detail: z.string()
});
export const StartCircleCIAuthorizationResultSchema = z.object({
    started: z.union([CircleCIAuthorizationStartedOkSchema, CircleCIRegistrationRefusedSchema])
});
export const CircleCIAuthorizationSteppedOkSchema = z.object({
    kind: z.literal("Stepped"),
    authorization: CircleCIAuthorizationSchema
});
export const AuthorizationNotWaitingSchema = z.object({
    kind: z.literal("NotWaiting"),
    detail: z.string()
});
export const AuthorizationInvalidSchema = z.object({
    kind: z.literal("Invalid"),
    detail: z.string()
});
export const CircleCIAuthorizationSteppedSchema = z.object({
    stepped: z.union([CircleCIAuthorizationSteppedOkSchema, AuthorizationNotFoundSchema, AuthorizationNotWaitingSchema, AuthorizationInvalidSchema])
});
export const CompleteCircleCIAuthorizationResultSchema = z.object({
    stepped: z.union([CircleCIAuthorizationSteppedOkSchema, AuthorizationNotFoundSchema, AuthorizationNotWaitingSchema, AuthorizationInvalidSchema])
});
export const ChooseCircleCIOrganizationResultSchema = z.object({
    stepped: z.union([CircleCIAuthorizationSteppedOkSchema, AuthorizationNotFoundSchema, AuthorizationNotWaitingSchema, AuthorizationInvalidSchema])
});
export const CircleCIAuthorizationDeadlineReachedResultSchema = z.object({});
export const ImageAvailabilitySchema = z.object({
    harness: z.string(),
    harnessVersion: z.string(),
    architectures: z.array(HostArchitectureSchema)
});
export const UnplaceableNotOnlineSchema = z.object({
    kind: z.literal("Unplaceable"),
    host: HostRecordSchema,
    reason: z.literal("NotOnline")
});
export const UnplaceableNoImageSchema = z.object({
    kind: z.literal("Unplaceable"),
    host: HostRecordSchema,
    reason: z.literal("NoImage"),
    image: ImageAvailabilitySchema
});
export const UnplaceableFullSchema = z.object({
    kind: z.literal("Unplaceable"),
    host: HostRecordSchema,
    reason: z.literal("Full"),
    usage: ReportedHostUsageSchema
});
export const UnplaceableMemoryFullSchema = z.object({
    kind: z.literal("Unplaceable"),
    host: HostRecordSchema,
    reason: z.literal("MemoryFull"),
    usage: ReportedHostUsageSchema,
    boxMemoryMib: z.int()
});
export const UnplaceableNoMemorySchema = z.object({
    kind: z.literal("Unplaceable"),
    host: HostRecordSchema,
    reason: z.literal("NoMemory"),
    usage: ReportedHostUsageSchema,
    boxMemoryMib: z.int()
});
export const UnplaceableNoDiskSchema = z.object({
    kind: z.literal("Unplaceable"),
    host: HostRecordSchema,
    reason: z.literal("NoDisk"),
    usage: ReportedHostUsageSchema,
    boxDiskMib: z.int()
});
export const UnplaceableNoConnectorsSchema = z.object({
    kind: z.literal("Unplaceable"),
    host: HostRecordSchema,
    reason: z.literal("NoConnectors"),
    usage: ReportedHostUsageSchema
});
export const ClaudeSetupStartedOkSchema = z.object({
    kind: z.literal("Started"),
    setup: ClaudeSetupSchema
});
export const ClaudeSetupUnplacedSchema = z.object({
    kind: z.literal("Unplaced"),
    hosts: z.array(z.discriminatedUnion("reason", [UnplaceableNotOnlineSchema, UnplaceableNoImageSchema, UnplaceableFullSchema, UnplaceableMemoryFullSchema, UnplaceableNoMemorySchema, UnplaceableNoDiskSchema, UnplaceableNoConnectorsSchema]))
});
export const ClaudeSetupReleaseUnreadableSchema = z.object({
    kind: z.literal("ReleaseUnreadable"),
    detail: z.string()
});
export const StartClaudeSetupResultSchema = z.object({
    started: z.union([ClaudeSetupStartedOkSchema, ClaudeSetupUnplacedSchema, ClaudeSetupReleaseUnreadableSchema, AuthorizationNoSecretSetSchema, AuthorizationOtherCredentialSchema])
});
export const GetClaudeSetupResultSchema = z.object({
    setup: z.union([ClaudeSetupSchema, z.null()])
});
export const ListClaudeSetupsResultSchema = z.object({
    setups: z.array(ClaudeSetupSchema)
});
export const ClaudeSetupCodedOkSchema = z.object({
    kind: z.literal("Coded"),
    setup: ClaudeSetupSchema
});
export const SubmitClaudeSetupCodeResultSchema = z.object({
    coded: z.union([ClaudeSetupCodedOkSchema, AuthorizationNotFoundSchema, AuthorizationNotWaitingSchema])
});
export const ClaudeSetupStoredOkSchema = z.object({
    kind: z.literal("Stored")
});
export const ClaudeSetupRefusedSchema = z.object({
    kind: z.literal("Refused")
});
export const ClaudeSetupNotStoredSchema = z.object({
    kind: z.literal("NotStored"),
    detail: z.string()
});
export const WriteClaudeSetupTokenResultSchema = z.object({
    stored: z.union([ClaudeSetupStoredOkSchema, AuthorizationNotFoundSchema, ClaudeSetupRefusedSchema, AuthorizationNotWaitingSchema, ClaudeSetupNotStoredSchema])
});
export const ClaudeSetupDeadlineReachedResultSchema = z.object({});
export const ClaudeSetupReadySchema = z.object({
    kind: z.literal("Ready"),
    message: z.union([ClaudeSetupBoxOfferSchema, ClaudeSetupBoxCodeSchema])
});
export const ClaudeSetupWithdrawnSchema = z.object({
    kind: z.literal("Withdrawn"),
    message: ClaudeSetupBoxDiscardSchema
});
export const PrepareClaudeSetupResultSchema = z.object({
    prepared: z.union([ClaudeSetupReadySchema, ClaudeSetupWithdrawnSchema])
});
export const ListPrebuildsResultSchema = z.object({
    prebuilds: z.array(PrebuildSchema)
});
export const ListLatestPrebuildsResultSchema = z.object({
    prebuilds: z.array(PrebuildSchema)
});
export const GetPrebuildResultSchema = z.object({
    prebuild: z.union([PrebuildSchema, z.null()])
});
export const HeldPrebuildResultSchema = z.object({
    prebuild: z.union([PrebuildSchema, z.null()])
});
export const RecordPrebuildBuildingResultSchema = z.object({});
export const CallerWorkflowConnectedSchema = z.object({
    kind: z.literal("Connected"),
    callerWorkflow: z.string()
});
export const CallerWorkflowNotConnectedSchema = z.object({
    kind: z.literal("NotConnected")
});
export const JobInputsTargetSchema = z.object({
    prebuild: PrebuildSchema,
    defaultBranch: z.string(),
    callerWorkflow: z.union([CallerWorkflowConnectedSchema, CallerWorkflowNotConnectedSchema]),
    headSha: z.string(),
    rootfsKey: z.string()
});
export const JobInputsTargetResultSchema = z.object({
    target: z.union([JobInputsTargetSchema, z.null()])
});
export const JobRunBoundOkSchema = z.object({
    kind: z.literal("Bound"),
    prebuild: PrebuildSchema
});
export const JobRunOtherSchema = z.object({
    kind: z.literal("OtherRun"),
    runId: z.int()
});
export const BindJobRunResultSchema = z.object({
    bound: z.union([JobRunBoundOkSchema, JobRunOtherSchema])
});
export const WorkflowRunReportedResultSchema = z.object({});
export const PrebuildDeadlineReachedResultSchema = z.object({});
export const PrebuildStartedSchema = z.object({
    kind: z.literal("Started"),
    prebuild: PrebuildSchema
});
export const PrebuildNoInstallationSchema = z.object({
    kind: z.literal("NoInstallation")
});
export const PrebuildTokenRefusedSchema = z.object({
    kind: z.literal("TokenRefused"),
    detail: z.string()
});
export const PrebuildUnreadableSchema = z.object({
    kind: z.literal("Unreadable"),
    detail: z.string()
});
export const PrebuildPermissionMissingSchema = z.object({
    kind: z.literal("PermissionMissing"),
    permissions: z.array(z.string()),
    appSlug: z.string()
});
export const PrebuildAppPermissionMissingSchema = z.object({
    kind: z.literal("AppPermissionMissing"),
    permissions: z.array(z.string()),
    appSlug: z.string(),
    appOwner: z.string()
});
export const PrebuildCallerRefusedSchema = z.object({
    kind: z.literal("CallerRefused"),
    detail: z.string()
});
export const PrebuildActionsDisabledSchema = z.object({
    kind: z.literal("ActionsDisabled"),
    detail: z.string()
});
export const PrebuildRefusedSchema = z.object({
    kind: z.literal("Refused"),
    detail: z.string()
});
export const StartGitHubActionsPrebuildResultSchema = z.object({
    started: z.union([PrebuildStartedSchema, PrebuildNoInstallationSchema, PrebuildTokenRefusedSchema, PrebuildUnreadableSchema, PrebuildPermissionMissingSchema, PrebuildAppPermissionMissingSchema, PrebuildCallerRefusedSchema, PrebuildActionsDisabledSchema, PrebuildRefusedSchema])
});
export const HostPrebuildStartedSchema = z.object({
    kind: z.literal("Started"),
    started: PrebuildSchema
});
export const StartDrainingSchema = z.object({
    kind: z.literal("Draining")
});
export const StartUnplacedSchema = z.object({
    kind: z.literal("Unplaced"),
    hosts: z.array(z.discriminatedUnion("reason", [UnplaceableNotOnlineSchema, UnplaceableNoImageSchema, UnplaceableFullSchema, UnplaceableMemoryFullSchema, UnplaceableNoMemorySchema, UnplaceableNoDiskSchema, UnplaceableNoConnectorsSchema]))
});
export const StartConnectorDisconnectedSchema = z.object({
    kind: z.literal("ConnectorDisconnected"),
    names: z.array(z.string())
});
export const StartHostPrebuildResultSchema = z.object({
    started: z.union([HostPrebuildStartedSchema, StartDrainingSchema, StartUnplacedSchema, StartConnectorDisconnectedSchema, ClaudeSetupReleaseUnreadableSchema])
});
export const PrebuildRunSchema = z.object({
    runId: z.int(),
    headSha: z.string()
});
export const UploadJobRecordedSchema = z.object({
    kind: z.literal("Job"),
    jobId: z.string()
});
export const UploadJobAbsentSchema = z.object({
    kind: z.literal("NoJob")
});
export const RecordedPipelineSchema = z.object({
    pipelineId: z.string(),
    projectId: z.string(),
    headSha: z.string(),
    job: z.union([UploadJobRecordedSchema, UploadJobAbsentSchema])
});
export const GitHubActionsUploadTargetSchema = z.object({
    provider: z.literal("GitHubActions"),
    prebuild: PrebuildSchema,
    defaultBranch: z.string(),
    upload: z.union([PrebuildLayerUploadSchema, z.null()]),
    callerWorkflow: z.union([CallerWorkflowConnectedSchema, CallerWorkflowNotConnectedSchema]),
    run: PrebuildRunSchema
});
export const CircleCIUploadTargetSchema = z.object({
    provider: z.literal("CircleCI"),
    prebuild: PrebuildSchema,
    defaultBranch: z.string(),
    upload: z.union([PrebuildLayerUploadSchema, z.null()]),
    organizationId: z.string(),
    pipeline: RecordedPipelineSchema
});
export const UploadTargetResultSchema = z.object({
    target: z.union([GitHubActionsUploadTargetSchema, CircleCIUploadTargetSchema, z.null()])
});
export const CircleCIJobBoundOkSchema = z.object({
    kind: z.literal("Bound")
});
export const CircleCIJobOtherSchema = z.object({
    kind: z.literal("OtherJob"),
    jobId: z.string()
});
export const CircleCIRevisionMovedSchema = z.object({
    kind: z.literal("RevisionMoved"),
    prebuild: PrebuildSchema
});
export const CircleCIJobRefusedSchema = z.object({
    kind: z.literal("Refused"),
    status: z.int(),
    detail: z.string()
});
export const BindCircleCIUploadJobResultSchema = z.object({
    bound: z.union([CircleCIJobBoundOkSchema, CircleCIJobOtherSchema, CircleCIRevisionMovedSchema, CircleCIJobRefusedSchema])
});
export const UploadRecordedOkSchema = z.object({
    kind: z.literal("Recorded"),
    prebuild: PrebuildSchema
});
export const UploadNotUploadingSchema = z.object({
    kind: z.literal("NotUploading"),
    prebuild: PrebuildSchema
});
export const UploadOtherLayerSchema = z.object({
    kind: z.literal("OtherLayer"),
    prebuild: PrebuildSchema,
    recorded: PrebuildLayerUploadSchema
});
export const UploadRecordedSchema = z.object({
    recorded: z.union([UploadRecordedOkSchema, UploadNotUploadingSchema, UploadOtherLayerSchema])
});
export const StartPrebuildUploadResultSchema = z.object({
    recorded: z.union([UploadRecordedOkSchema, UploadNotUploadingSchema, UploadOtherLayerSchema])
});
export const CompletePrebuildUploadResultSchema = z.object({
    recorded: z.union([UploadRecordedOkSchema, UploadNotUploadingSchema, UploadOtherLayerSchema])
});
export const GetPrebuildFailureResultSchema = z.object({
    failure: z.union([PrebuildFailureSchema, z.null()])
});
export const CircleCIDispatchedSchema = z.object({
    kind: z.literal("Dispatched"),
    prebuild: PrebuildSchema
});
export const CircleCIDispatchNotConnectedSchema = z.object({
    kind: z.literal("NotConnected")
});
export const DispatchCircleCIPrebuildResultSchema = z.object({
    dispatched: z.union([CircleCIDispatchedSchema, CircleCIDispatchNotConnectedSchema, PrebuildRefusedSchema])
});
export const CircleCIWorkflowCompletedResultSchema = z.object({});
export const ReadTokenOkSchema = z.object({
    kind: z.literal("Token"),
    token: z.string()
});
export const RepositoryReadTokenResultSchema = z.object({
    read: z.union([ReadTokenOkSchema, PrebuildRefusedSchema])
});
export const SessionStartedOkSchema = z.object({
    kind: z.literal("Started"),
    started: StartedSessionSchema
});
export const SessionTagsOverLimitSchema = z.object({
    kind: z.literal("TagsOverLimit"),
    tags: z.array(z.string().regex(/^[a-z0-9][a-z0-9:._-]{0,62}$/))
});
export const StartSessionResultSchema = z.object({
    started: z.union([SessionStartedOkSchema, StartDrainingSchema, StartUnplacedSchema, StartConnectorDisconnectedSchema, ClaudeSetupReleaseUnreadableSchema, SessionTagsOverLimitSchema])
});
export const SessionFromIssueStartedOkSchema = z.object({
    kind: z.literal("Started"),
    started: StartedSessionFromIssueSchema
});
export const StartSessionFromIssueResultSchema = z.object({
    started: z.union([SessionFromIssueStartedOkSchema, StartDrainingSchema, StartUnplacedSchema, StartConnectorDisconnectedSchema, ClaudeSetupReleaseUnreadableSchema, SessionTagsOverLimitSchema])
});
export const TurnSentOkSchema = z.object({
    kind: z.literal("Sent"),
    turn: z.discriminatedUnion("state", [OfferedTurnSchema, RunningTurnSchema, CompletedTurnSchema, FailedTurnSchema])
});
export const TurnStrandedSchema = z.object({
    kind: z.literal("Stranded"),
    missingTurnIds: z.array(z.string().min(1).max(64))
});
export const SessionNotFoundSchema = z.object({
    kind: z.literal("NotFound")
});
export const TurnInFlightSchema = z.object({
    kind: z.literal("InFlight"),
    turnId: z.string().min(1).max(64)
});
export const SessionStoppingSchema = z.object({
    kind: z.literal("Stopping")
});
export const SessionArchivedStateSchema = z.object({
    kind: z.literal("Archived")
});
export const SessionFailedStateSchema = z.object({
    kind: z.literal("Failed")
});
export const NoCredentialRefusalSchema = z.object({
    kind: z.literal("NoCredential"),
    accepted: z.array(HarnessCredentialSchema)
});
export const NoModelCredentialRefusalSchema = z.object({
    kind: z.literal("NoModelCredential"),
    model: z.string(),
    provider: ModelProviderSchema,
    accepted: z.array(HarnessCredentialSchema)
});
export const UnsupportedCredentialRefusalSchema = z.object({
    kind: z.literal("Unsupported"),
    name: z.string(),
    credentialKind: z.string(),
    supported: z.array(z.string())
});
export const ModelUnsupportedCredentialRefusalSchema = z.object({
    kind: z.literal("ModelUnsupported"),
    model: z.string().min(1).max(200),
    name: z.string(),
    credentialKind: z.string(),
    allowed: z.array(z.string().min(1).max(200))
});
export const ExpiredCredentialRefusalSchema = z.object({
    kind: z.literal("Expired"),
    name: z.string(),
    expiresAt: z.string()
});
export const TurnCredentialRefusedSchema = z.object({
    kind: z.literal("CredentialRefused"),
    personaId: z.string().min(1).max(64),
    refusal: z.union([NoCredentialRefusalSchema, NoModelCredentialRefusalSchema, UnsupportedCredentialRefusalSchema, ModelUnsupportedCredentialRefusalSchema, ExpiredCredentialRefusalSchema])
});
export const SendTurnResultSchema = z.object({
    sent: z.union([TurnSentOkSchema, StartDrainingSchema, TurnStrandedSchema, StartUnplacedSchema, StartConnectorDisconnectedSchema, ClaudeSetupReleaseUnreadableSchema, SessionNotFoundSchema, SessionStoppingSchema, SessionArchivedStateSchema, SessionFailedStateSchema, TurnCredentialRefusedSchema])
});
export const SessionStoppingWithSchema = z.object({
    kind: z.literal("Stopping"),
    session: SessionSchema
});
export const CancelUnspokenSchema = z.object({
    kind: z.literal("CancelUnspoken"),
    turnId: z.string().min(1).max(64),
    host: z.string()
});
export const StopSessionResultSchema = z.object({
    stopped: z.union([SessionStoppingWithSchema, SessionNotFoundSchema, TurnInFlightSchema, CancelUnspokenSchema, SessionArchivedStateSchema])
});
export const SessionArchivedOkSchema = z.object({
    kind: z.literal("Archived"),
    session: SessionSchema
});
export const SessionNotStoppedSchema = z.object({
    kind: z.literal("NotStopped"),
    state: SessionStateSchema
});
export const ArchiveSessionResultSchema = z.object({
    archived: z.union([SessionArchivedOkSchema, SessionNotFoundSchema, SessionNotStoppedSchema])
});
export const SessionTaggedSchema = z.object({
    kind: z.literal("Tagged"),
    session: SessionSchema
});
export const SetSessionTagsResultSchema = z.object({
    tagged: z.union([SessionTaggedSchema, SessionNotFoundSchema])
});
export const PatchSessionTagsResultSchema = z.object({
    tagged: z.union([SessionTaggedSchema, SessionNotFoundSchema, SessionTagsOverLimitSchema])
});
export const SessionDeletedSchema = z.object({
    kind: z.literal("Deleted")
});
export const DeleteSessionResultSchema = z.object({
    deleted: z.union([SessionDeletedSchema, SessionNotFoundSchema, SessionNotStoppedSchema])
});
export const GetSessionResultSchema = z.object({
    session: z.union([SessionSchema, z.null()])
});
export const ListSessionsResultSchema = z.object({
    sessions: z.array(SessionSchema)
});
export const ListTurnsResultSchema = z.object({
    turns: z.union([z.array(z.discriminatedUnion("state", [OfferedTurnSchema, RunningTurnSchema, CompletedTurnSchema, FailedTurnSchema])), z.null()])
});
export const GetTurnResultSchema = z.object({
    turn: z.union([z.discriminatedUnion("state", [OfferedTurnSchema, RunningTurnSchema, CompletedTurnSchema, FailedTurnSchema]), z.null()])
});
export const TurnCancelledOkSchema = z.object({
    kind: z.literal("Cancelled"),
    turn: z.discriminatedUnion("state", [OfferedTurnSchema, RunningTurnSchema, CompletedTurnSchema, FailedTurnSchema])
});
export const TurnNotFoundSchema = z.object({
    kind: z.literal("NotFound")
});
export const TurnNotWaitingSchema = z.object({
    kind: z.literal("NotWaiting"),
    state: TurnStateSchema
});
export const CancelTurnResultSchema = z.object({
    cancelled: z.union([TurnCancelledOkSchema, TurnNotFoundSchema, TurnNotWaitingSchema])
});
export const SteerSentOkSchema = z.object({
    kind: z.literal("Sent"),
    steer: SteerSchema
});
export const TurnNotRunningSchema = z.object({
    kind: z.literal("NotRunning"),
    state: TurnStateSchema
});
export const SteerUnsupportedSchema = z.object({
    kind: z.literal("Unsupported")
});
export const SteerTurnResultSchema = z.object({
    sent: z.union([SteerSentOkSchema, TurnNotFoundSchema, TurnNotRunningSchema, SteerUnsupportedSchema])
});
export const ListSteersResultSchema = z.object({
    steers: z.union([z.array(SteerSchema), z.null()])
});
export const SteersTakenSchema = z.object({
    kind: z.literal("Taken"),
    prompts: z.array(z.string().min(1).max(100000))
});
export const SteerInboxClosedSchema = z.object({
    kind: z.literal("Closed")
});
export const TakeSteersResultSchema = z.object({
    taken: z.union([SteersTakenSchema, SteerInboxClosedSchema])
});
export const TurnsReadSchema = z.object({
    kind: z.literal("Read"),
    turns: z.array(z.discriminatedUnion("state", [OfferedTurnSchema, RunningTurnSchema, CompletedTurnSchema, FailedTurnSchema]))
});
export const WaitedTurnNotFoundSchema = z.object({
    kind: z.literal("NotFound"),
    turnId: z.string().min(1).max(64)
});
export const WaitTurnsResultSchema = z.object({
    waited: z.union([TurnsReadSchema, WaitedTurnNotFoundSchema])
});
export const EventsReadSchema = z.object({
    kind: z.literal("Read"),
    page: EventPageSchema
});
export const EventCursorExpiredSchema = z.object({
    kind: z.literal("CursorExpired"),
    oldestEventId: z.int().min(0)
});
export const ListEventsResultSchema = z.object({
    listed: z.union([EventsReadSchema, EventCursorExpiredSchema])
});
export const PushDeliveryTargetSchema = z.object({
    endpoint: z.string().url().regex(/^https:\/\/[^\/@?#\s]+(\/[^#\s]*)?$/).max(2048),
    keys: PushSubscriptionKeysSchema,
    events: z.array(TenantEventTypeSchema)
});
export const ListWebhookEndpointsResultSchema = z.object({
    endpoints: z.array(WebhookEndpointSchema)
});
export const CreateWebhookEndpointResultSchema = z.object({
    endpoint: WebhookEndpointSchema
});
export const GetWebhookEndpointResultSchema = z.object({
    endpoint: z.union([WebhookEndpointSchema, z.null()])
});
export const DeleteWebhookEndpointResultSchema = z.object({
    deleted: z.boolean()
});
export const SetWebhookEndpointStatusResultSchema = z.object({});
export const ListPushSubscriptionsResultSchema = z.object({
    subscriptions: z.array(PushSubscriptionSchema)
});
export const CreatePushSubscriptionResultSchema = z.object({
    subscription: PushSubscriptionSchema
});
export const DeletePushSubscriptionResultSchema = z.object({
    deleted: z.boolean()
});
export const ForgetPushSubscriptionResultSchema = z.object({});
export const PushTargetResultSchema = z.object({
    target: z.union([PushDeliveryTargetSchema, z.null()])
});
export const SubscriptionCreatedOkSchema = z.object({
    kind: z.literal("Created"),
    subscription: z.discriminatedUnion("state", [ActiveSubscriptionSchema, PausedSubscriptionSchema, EndedSubscriptionSchema])
});
export const CreateSubscriptionResultSchema = z.object({
    created: z.union([SubscriptionCreatedOkSchema, SessionNotFoundSchema, SessionArchivedStateSchema, SessionFailedStateSchema])
});
export const ListSubscriptionsResultSchema = z.object({
    subscriptions: z.array(z.discriminatedUnion("state", [ActiveSubscriptionSchema, PausedSubscriptionSchema, EndedSubscriptionSchema]))
});
export const GetSubscriptionResultSchema = z.object({
    subscription: z.union([z.discriminatedUnion("state", [ActiveSubscriptionSchema, PausedSubscriptionSchema, EndedSubscriptionSchema]), z.null()])
});
export const SubscriptionChangedOkSchema = z.object({
    kind: z.literal("Changed"),
    subscription: z.discriminatedUnion("state", [ActiveSubscriptionSchema, PausedSubscriptionSchema, EndedSubscriptionSchema])
});
export const SubscriptionNotFoundSchema = z.object({
    kind: z.literal("NotFound")
});
export const SubscriptionEndedStateSchema = z.object({
    kind: z.literal("Ended"),
    subscription: z.discriminatedUnion("state", [ActiveSubscriptionSchema, PausedSubscriptionSchema, EndedSubscriptionSchema])
});
export const SubscriptionCursorExpiredSchema = z.object({
    kind: z.literal("CursorExpired"),
    cursorEventId: z.int().min(0),
    oldestEventId: z.int().min(0)
});
export const PauseSubscriptionResultSchema = z.object({
    paused: z.union([SubscriptionChangedOkSchema, SubscriptionNotFoundSchema, SubscriptionEndedStateSchema])
});
export const ResumeSubscriptionResultSchema = z.object({
    resumed: z.union([SubscriptionChangedOkSchema, SubscriptionNotFoundSchema, SubscriptionEndedStateSchema, SubscriptionCursorExpiredSchema])
});
export const DeleteSubscriptionResultSchema = z.object({
    deleted: z.boolean()
});
export const CompleteSubscriptionResultSchema = z.object({
    completed: z.union([SubscriptionChangedOkSchema, SubscriptionNotFoundSchema, SubscriptionEndedStateSchema])
});
export const TriggerCreatedOkSchema = z.object({
    kind: z.literal("Created"),
    trigger: TriggerSchema
});
export const TriggerUpdatedOkSchema = z.object({
    kind: z.literal("Updated"),
    trigger: TriggerSchema
});
export const TriggerNotFoundSchema = z.object({
    kind: z.literal("NotFound")
});
export const TriggerNameTakenSchema = z.object({
    kind: z.literal("NameTaken")
});
export const TriggerPersonaNotFoundSchema = z.object({
    kind: z.literal("PersonaNotFound")
});
export const CreateTriggerResultSchema = z.object({
    created: z.union([TriggerCreatedOkSchema, TriggerNameTakenSchema, TriggerPersonaNotFoundSchema])
});
export const ListTriggersResultSchema = z.object({
    triggers: z.array(TriggerSchema)
});
export const GetTriggerResultSchema = z.object({
    trigger: z.union([TriggerSchema, z.null()])
});
export const UpdateTriggerResultSchema = z.object({
    updated: z.union([TriggerUpdatedOkSchema, TriggerNotFoundSchema, TriggerNameTakenSchema, TriggerPersonaNotFoundSchema])
});
export const DeleteTriggerResultSchema = z.object({
    deleted: z.boolean()
});
export const TriggerDeliveryRepeatedSchema = z.object({
    kind: z.literal("Repeated"),
    sessionId: z.string().min(1).max(64)
});
export const TriggerStartRefusedOkSchema = z.object({
    kind: z.literal("Refused"),
    refusal: TriggerStartRefusalSchema
});
export const TriggerFiredResultSchema = z.object({
    fired: z.union([SessionStartedOkSchema, TriggerDeliveryRepeatedSchema, TriggerNotFoundSchema, TriggerStartRefusedOkSchema])
});
export const GetTurnFailureResultSchema = z.object({
    failure: z.union([TurnFailureSchema, z.null()])
});
export const ListStopFailuresResultSchema = z.object({
    failures: z.union([z.array(StopFailureSchema), z.null()])
});
export const ListSnapshotsResultSchema = z.object({
    snapshots: z.union([z.array(SnapshotSchema), z.null()])
});
export const ListCredentialHandoversResultSchema = z.object({
    handovers: z.union([z.array(CredentialHandoverSchema), z.null()])
});
export const GetSnapshotResultSchema = z.object({
    snapshot: z.union([SnapshotSchema, z.null()])
});
export const ByteRangeSchema = z.object({
    offset: z.int(),
    length: z.int()
});
export const TranscriptChunkSchema = z.object({
    kind: z.literal("Chunk"),
    sessionState: SessionStateSchema,
    harness: HarnessSchema,
    lastLineSeq: z.int(),
    inFlight: z.boolean(),
    storageKey: z.string(),
    range: ByteRangeSchema
});
export const TranscriptLinesSchema = z.object({
    kind: z.literal("Lines"),
    sessionState: SessionStateSchema,
    harness: HarnessSchema,
    lastLineSeq: z.int(),
    inFlight: z.boolean(),
    lines: z.array(TranscriptLineSchema)
});
export const TranscriptCursorResultSchema = z.object({
    cursor: z.union([TranscriptChunkSchema, TranscriptLinesSchema, z.null()])
});
export const ConnectedAccountsSchema = z.object({
    GitHubActions: z.union([z.string(), z.null()]),
    CircleCI: z.union([z.string(), z.null()]),
    Namespace: z.union([z.string(), z.null()])
});
export const ConnectedAccountsResultSchema = z.object({
    accounts: ConnectedAccountsSchema
});
export const DeleteBuildConnectionResultSchema = z.object({
    deleted: z.boolean()
});
export const CircleCICredentialAuthorizedSchema = z.object({
    kind: z.literal("Authorized"),
    expiresAtMs: z.int()
});
export const CircleCICredentialPastedSchema = z.object({
    kind: z.literal("Pasted")
});
export const CircleCIConnectionRecordSchema = z.object({
    circleCIConnectionId: z.string().min(1).max(64),
    accountLabel: z.string(),
    organizationId: z.string(),
    credential: z.union([CircleCICredentialAuthorizedSchema, CircleCICredentialPastedSchema]),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const CircleCIConnectionResultSchema = z.object({
    connection: z.union([CircleCIConnectionRecordSchema, z.null()])
});
export const CircleCITokenResultSchema = z.object({
    token: z.union([z.string(), z.null()])
});
export const ConnectCircleCIResultSchema = z.object({
    connection: CircleCIConnectionRecordSchema
});
export const ListCircleCIProjectsResultSchema = z.object({
    projects: z.array(CircleCIProjectSchema)
});
export const CircleCIProjectBoundToResultSchema = z.object({
    project: z.union([CircleCIProjectSchema, z.null()])
});
export const CircleCIProjectOfResultSchema = z.object({
    project: z.union([CircleCIProjectSchema, z.null()])
});
export const AddCircleCIProjectResultSchema = z.object({
    project: CircleCIProjectSchema
});
export const CircleCIWebhookSchema = z.object({
    circleCIProjectId: z.string().min(1).max(64),
    webhookId: z.string()
});
export const CircleCIWebhooksResultSchema = z.object({
    webhooks: z.array(CircleCIWebhookSchema)
});
export const CircleCIWebhookSecretResultSchema = z.object({
    secret: z.union([z.string(), z.null()])
});
export const DeleteCircleCIProjectResultSchema = z.object({
    deleted: z.boolean()
});
export const GitHubActionsConnectionResultSchema = z.object({
    connection: z.union([GitHubActionsConnectionSchema, z.null()])
});
export const ConnectGitHubActionsResultSchema = z.object({
    connection: GitHubActionsConnectionSchema
});
export const NamespaceConnectionRecordSchema = z.object({
    namespaceConnectionId: z.string().min(1).max(64),
    accountLabel: z.string(),
    workspaceId: z.string(),
    createdAt: z.int(),
    updatedAt: z.int()
});
export const NamespaceConnectionResultSchema = z.object({
    connection: z.union([NamespaceConnectionRecordSchema, z.null()])
});
export const ConnectNamespaceResultSchema = z.object({
    connection: NamespaceConnectionRecordSchema
});
export const OfferSentResultSchema = z.object({});
export const HostHelloResultSchema = z.object({});
export const HostUsageResultSchema = z.object({});
export const ReconcileHeldBoxesResultSchema = z.object({});
export const ForgetHostUsageResultSchema = z.object({});
export const RunningTurnsSchema = z.object({
    hostId: z.string().min(1).max(64),
    runningTurns: z.int()
});
export const RunningTurnsByHostResultSchema = z.object({
    running: z.array(RunningTurnsSchema)
});
export const ListHostUsageResultSchema = z.object({
    usage: z.array(ReportedHostUsageSchema)
});
export const StoredTurnOfferSchema = z.object({
    type: z.literal("TurnOffer"),
    turnId: z.string().min(1).max(64),
    sessionId: z.string().min(1).max(64),
    boxId: z.string().min(1).max(64),
    repository: z.string().min(1).max(500),
    harness: HarnessSchema,
    harnessVersion: z.string().min(1),
    model: z.string().min(1).max(200),
    prompt: z.string().min(1).max(100000),
    boxMemoryMib: z.int().min(128).max(65536).optional(),
    boxDiskMib: z.int().min(64).max(262144).optional(),
    prebuildCommitSha: z.string().regex(/^[0-9a-f]{40}$/).optional()
});
export const TurnHandoffSchema = z.object({
    type: z.literal("TurnHandoff"),
    hostId: z.string().min(1).max(64),
    offer: StoredTurnOfferSchema
});
export const DeferredOffersResultSchema = z.object({
    handoffs: z.array(TurnHandoffSchema)
});
export const TurnMetricDimensionsResultSchema = z.object({
    dimensions: z.record(z.string(), z.record(z.string(), z.string()))
});
export const OfferReadySchema = z.object({
    kind: z.literal("Ready"),
    turnTotalBudgetSeconds: z.int().min(1).max(86400),
    credential: DispatchGrantSchema,
    lastLineSeq: z.int().min(0),
    snapshots: z.array(SnapshotDownloadSchema).max(1),
    personaFiles: z.array(PersonaFileDownloadSchema),
    image: z.discriminatedUnion("kind", [GuestImageDownloadSchema, LayeredImageDownloadSchema]),
    gitAuthorName: z.string().min(1).max(100),
    gitAuthorEmail: z.string().min(3).max(320)
});
export const OfferWithdrawnSchema = z.object({
    kind: z.literal("Withdrawn")
});
export const PrepareOfferResultSchema = z.object({
    prepared: z.union([OfferReadySchema, OfferWithdrawnSchema])
});
export const HostPresenceResultSchema = z.object({});
export const HostFrameRefusedSchema = z.object({
    type: z.literal("Refused"),
    reason: z.string()
});
export const HostMessageResultSchema = z.object({
    reply: z.union([HostFrameRefusedSchema, SnapshotChunksHeldSchema, SnapshotPackUploadsSchema, RestoreDownloadsSchema, BoxDiscardSchema, ClaudeSetupBoxDiscardSchema, TurnClaimedSchema, TurnWithdrawnSchema, StoredTurnOfferSchema, TurnHandoffSchema, z.null()])
});
export const DeadlineReachedResultSchema = z.object({});
export const SupervisorUpdateLatestStepSchema = z.discriminatedUnion("state", [SupervisorUpdateNotReportedSchema, SupervisorUpdateStepReportedSchema]);
export const SupervisorUpdateLatestFailureSchema = z.discriminatedUnion("state", [SupervisorUpdateNotReportedSchema, SupervisorUpdateFailureReportedSchema]);
export const HostChannelProtocolSchema = z.discriminatedUnion("state", [HostProtocolNotReportedSchema, HostChannelProtocolReportedSchema]);
export const HostGuestProtocolSchema = z.discriminatedUnion("state", [HostProtocolNotReportedSchema, HostGuestProtocolReportedSchema]);
export const SessionOriginSchema = z.discriminatedUnion("kind", [SessionPromptOriginSchema, SessionIssueOriginSchema]);
export const SessionStartedBySchema = z.discriminatedUnion("kind", [PersonOriginSchema, TurnOriginSchema, TriggerOriginSchema]);
export const TurnSchema = z.discriminatedUnion("state", [OfferedTurnSchema, RunningTurnSchema, CompletedTurnSchema, FailedTurnSchema]);
export const TurnImageSchema = z.discriminatedUnion("kind", [TurnFullImageSchema, TurnLayeredImageSchema]);
export const SessionPrebuildLayerSchema = z.discriminatedUnion("layer", [SessionPrebuildLayerStoredSchema, SessionPrebuildLayerAbsentSchema]);
export const SnapshotOutcomeSchema = z.discriminatedUnion("state", [SnapshotStoredSchema, SnapshotFailureSchema]);
export const ModelSupportSchema = z.discriminatedUnion("kind", [ModelSupportListedSchema, ModelSupportProviderCheckedSchema]);
export const InstallRecipeSchema = z.discriminatedUnion("kind", [NpmInstallRecipeSchema, ArchiveInstallRecipeSchema]);
export const PersonaFileSchema = z.discriminatedUnion("source", [InlinePersonaFileReadSchema, StoredPersonaFileReadSchema]);
export const SecretKeySchema = z.discriminatedUnion("kind", [SecretVariableKeySchema, ApiKeyKeySchema, SubscriptionTokenKeySchema, CredentialFileKeySchema]);
export const TriggerSourceSchema = z.discriminatedUnion("kind", [GitHubTriggerSourceSchema]);
export const PersonaFileWriteSchema = z.discriminatedUnion("source", [InlinePersonaFileSchema, StoredPersonaFileSchema]);
export const SecretValueSchema = z.discriminatedUnion("kind", [SecretVariableValueSchema, ApiKeyValueSchema, SubscriptionTokenValueSchema, CredentialFileValueSchema]);
export const SecretMemberUpdateSchema = z.discriminatedUnion("kind", [SecretVariableUpdateSchema, ApiKeyUpdateSchema, SubscriptionTokenUpdateSchema, CredentialFileUpdateSchema]);
export const GitHubAppStateSchema = z.discriminatedUnion("state", [GitHubAppReadySchema, GitHubAppMissingSchema]);
export const PrebuildStatusSchema = z.discriminatedUnion("state", [PrebuildDispatchedSchema, PrebuildBuildingSchema, PrebuildConvertingSchema, PrebuildDoneSchema, PrebuildFailedSchema]);
export const ConfigSecretSchema = z.discriminatedUnion("kind", [ConfigSecretVariableSchema, ConfigApiKeySchema, ConfigSubscriptionTokenSchema]);
export const ConfigFileWriteSchema = z.discriminatedUnion("source", [InlineConfigFileSchema, StoredConfigFileSchema]);
export const GitHubActionsLinkSchema = z.discriminatedUnion("state", [GitHubActionsConnectedSchema, GitHubActionsNotConnectedSchema]);
export const NamespaceLinkSchema = z.discriminatedUnion("state", [NamespaceConnectedSchema, NamespaceNotConnectedSchema, NamespaceNotConfiguredSchema]);
export const CircleCILinkSchema = z.discriminatedUnion("state", [CircleCIConnectedSchema, CircleCINotConnectedSchema]);
export const CircleCICredentialSchema = z.discriminatedUnion("kind", [CircleCIAuthorizedCredentialSchema, CircleCIPastedCredentialSchema]);
export const CircleCIAuthorizationStatusSchema = z.discriminatedUnion("state", [CircleCIAuthorizationAwaitingRedirectSchema, CircleCIAuthorizationChoosingOrganizationSchema, CircleCIAuthorizationCompletedSchema, CircleCIAuthorizationFailedSchema]);
export const ClaudeSetupStatusSchema = z.discriminatedUnion("state", [ClaudeSetupStartingSchema, ClaudeSetupAwaitingCodeSchema, ClaudeSetupMintingSchema, ClaudeSetupCompletedSchema, ClaudeSetupFailedSchema]);
export const SupervisorHandoverImageSchema = z.discriminatedUnion("kind", [SupervisorHandoverFullImageSchema, SupervisorHandoverLayeredImageSchema]);
export const SupervisorHandoverBoxStateSchema = z.discriminatedUnion("kind", [SupervisorHandoverWarmSchema, SupervisorHandoverTurnSchema]);
export const SupervisorHandoverCommandSchema = z.discriminatedUnion("kind", [SupervisorHandoverSnapshotSchema, SupervisorHandoverTeardownSchema, SupervisorHandoverDiscardSchema]);
export const SnapshotEntrySchema = z.discriminatedUnion("kind", [SnapshotFileEntrySchema, SnapshotDirectoryEntrySchema, SnapshotOpaqueDirectoryEntrySchema, SnapshotSymlinkEntrySchema, SnapshotWhiteoutEntrySchema]);
export const OpenRouterAuthorizationStatusSchema = z.discriminatedUnion("state", [OpenRouterAuthorizationAwaitingCallbackSchema, OpenRouterAuthorizationExchangingSchema, OpenRouterAuthorizationCompletedSchema, OpenRouterAuthorizationFailedSchema]);
export const ConnectorStatusSchema = z.discriminatedUnion("state", [ConnectorNotConnectedSchema, ConnectorConnectedSchema, ConnectorDisconnectedSchema, ConnectorAuthorizationFailedSchema]);
export const SubscriptionPauseReasonSchema = z.discriminatedUnion("kind", [SubscriptionPausedByRequestSchema, SubscriptionPausedDeliveryFailedSchema, SubscriptionPausedCrewFailingSchema, SubscriptionPausedCreditExhaustedSchema]);
export const TenantEventSchema = z.discriminatedUnion("event", [TurnStartedEventSchema, TurnCompletedEventSchema, TurnFailedEventSchema, SessionIdleEventSchema, SessionStoppedEventSchema, SessionFailedEventSchema, SessionArchivedEventSchema, HostOnlineEventSchema, HostOfflineEventSchema, PrebuildDoneEventSchema, PrebuildFailedEventSchema, SubscriptionPausedEventSchema, SubscriptionEndedEventSchema, TriggerStartRefusedEventSchema]);
export const EventProblemSchema = z.union([EventCursorExpiredProblemSchema, ProblemSchema]);
export const WebhookDeliveryStatusSchema = z.discriminatedUnion("delivery", [WebhookDeliveringSchema, WebhookFailingSchema]);
export const TriggerTestSchema = z.discriminatedUnion("kind", [StoredTriggerTestSchema, DraftTriggerTestSchema]);
export const TranscriptPageSchema = z.discriminatedUnion("form", [RawTranscriptPageSchema, CompactTranscriptPageSchema]);
export const PersonaFilePatchSchema = z.discriminatedUnion("kind", [PutPersonaFilePatchSchema, RemovePersonaFilePatchSchema, EditPersonaFilePatchSchema]);
export const PrebuildPreviewRequestSchema = z.discriminatedUnion("source", [PrebuildPreviewOfRepositorySchema, PrebuildPreviewOfSuppliedSchema]);
export const ConnectionSummarySchema = z.discriminatedUnion("state", [ConnectedConnectionSchema, ExpiringConnectionSchema, ExpiredConnectionSchema, NotConnectedConnectionSchema, NotConfiguredConnectionSchema]);
export const ConnectorSchema = z.discriminatedUnion("auth", [StaticConnectorSchema, OAuthConnectorSchema]);
export const SubscriptionSchema = z.discriminatedUnion("state", [ActiveSubscriptionSchema, PausedSubscriptionSchema, EndedSubscriptionSchema]);
export const OAuthTokenRequestSchema = z.discriminatedUnion("grant_type", [OAuthAuthorizationCodeRequestSchema, OAuthRefreshTokenRequestSchema]);
export const BootImageSchema = z.discriminatedUnion("kind", [GuestImageDownloadSchema, LayeredImageDownloadSchema]);
export const HostMessageSchema = z.discriminatedUnion("type", [TurnImageFetchingSchema, TurnClaimSchema, TurnRepositoryReadySchema, TurnLineSchema, TurnCompleteSchema, TurnRepositoryCloneFailedSchema, TurnFailedSchema, SnapshotChunksSchema, SnapshotPacksSchema, RestoreChunksSchema, SnapshotDoneSchema, SnapshotFailedSchema, BoxGoneSchema, BoxTeardownFailedSchema, ClaudeSetupBoxUrlSchema, ClaudeSetupBoxFailedSchema, SupervisorUpdateStepSchema, SupervisorUpdateFailedSchema, TelemetryBatchSchema]);
export const ControlMessageSchema = z.discriminatedUnion("type", [TurnOfferSchema, TurnWithdrawnSchema, TurnClaimedSchema, TurnCancelSchema, SnapshotRequestSchema, SnapshotChunksHeldSchema, SnapshotPackUploadsSchema, RestoreDownloadsSchema, BoxTeardownSchema, BoxDiscardSchema, ClaudeSetupBoxOfferSchema, ClaudeSetupBoxCodeSchema, ClaudeSetupBoxDiscardSchema]);
export const HostEnvelopeSchema = z.discriminatedUnion("type", [HelloSchema, HostHeartbeatSchema, HostFrameSchema]);
export const ControlEnvelopeSchema = z.discriminatedUnion("type", [ChallengeSchema, WelcomeSchema, HeartbeatSchema, ReleasePublishedSchema, FrameRefusedSchema, ControlFrameSchema]);
export const ConfigWriteSchema = z.discriminatedUnion("kind", [CreateSecretSetWriteSchema, RewriteSecretSetWriteSchema, DeleteSecretSetWriteSchema, CreatePersonaWriteSchema, UpdatePersonaWriteSchema, DeletePersonaWriteSchema, PinWriteSchema, UnpinWriteSchema, CreateTriggerWriteSchema, UpdateTriggerWriteSchema, DeleteTriggerWriteSchema]);
export const UnplaceableSchema = z.discriminatedUnion("reason", [UnplaceableNotOnlineSchema, UnplaceableNoImageSchema, UnplaceableFullSchema, UnplaceableMemoryFullSchema, UnplaceableNoMemorySchema, UnplaceableNoDiskSchema, UnplaceableNoConnectorsSchema]);
export const TenantRequestSchema = z.discriminatedUnion("operation", [ListPersonasRequestSchema, GetPersonaRequestSchema, CreatePersonaRequestSchema, UpdatePersonaRequestSchema, PatchPersonaRequestSchema, DeletePersonaRequestSchema, OpenRequestSchema, SupervisorUpdateRequestSchema, SupervisorUpdatesRequestSchema, ListSecretSetsRequestSchema, GetSecretSetRequestSchema, CreateSecretSetRequestSchema, UpdateSecretSetRequestSchema, PatchSecretSetRequestSchema, SetSecretMemberRequestSchema, RemoveSecretMemberRequestSchema, DeleteSecretSetRequestSchema, ApplyConfigRequestSchema, ListPinsRequestSchema, PinRequestSchema, UnpinRequestSchema, ListConnectorsRequestSchema, GetConnectorRequestSchema, CreateConnectorRequestSchema, RenameConnectorRequestSchema, DeleteConnectorRequestSchema, SetStaticTokenRequestSchema, ClearConnectorCredentialRequestSchema, StartConnectorAuthorizationRequestSchema, ConnectorCallbackRequestSchema, ServeConnectorTokenRequestSchema, UnknownConnectorsRequestSchema, StartOpenRouterAuthorizationRequestSchema, GetOpenRouterAuthorizationRequestSchema, OpenRouterCallbackRequestSchema, OpenRouterAuthorizationDeadlineReachedRequestSchema, OpenRouterSecretSetsRequestSchema, StartCircleCIAuthorizationRequestSchema, CompleteCircleCIAuthorizationRequestSchema, ChooseCircleCIOrganizationRequestSchema, CircleCIAuthorizationDeadlineReachedRequestSchema, StartClaudeSetupRequestSchema, GetClaudeSetupRequestSchema, ListClaudeSetupsRequestSchema, SubmitClaudeSetupCodeRequestSchema, WriteClaudeSetupTokenRequestSchema, ClaudeSetupDeadlineReachedRequestSchema, PrepareClaudeSetupRequestSchema, ListPrebuildsRequestSchema, ListLatestPrebuildsRequestSchema, GetPrebuildRequestSchema, HeldPrebuildRequestSchema, RecordPrebuildBuildingRequestSchema, JobInputsTargetRequestSchema, BindJobRunRequestSchema, WorkflowRunReportedRequestSchema, PrebuildDeadlineReachedRequestSchema, StartGitHubActionsPrebuildRequestSchema, StartHostPrebuildRequestSchema, UploadTargetRequestSchema, BindCircleCIUploadJobRequestSchema, StartPrebuildUploadRequestSchema, CompletePrebuildUploadRequestSchema, GetPrebuildFailureRequestSchema, DispatchCircleCIPrebuildRequestSchema, CircleCIWorkflowCompletedRequestSchema, RepositoryReadTokenRequestSchema, StartSessionRequestSchema, StartSessionFromIssueRequestSchema, SendTurnRequestSchema, StopSessionRequestSchema, ArchiveSessionRequestSchema, SetSessionTagsRequestSchema, PatchSessionTagsRequestSchema, DeleteSessionRequestSchema, GetSessionRequestSchema, ListSessionsRequestSchema, ListTurnsRequestSchema, GetTurnRequestSchema, CancelTurnRequestSchema, SteerTurnRequestSchema, ListSteersRequestSchema, TakeSteersRequestSchema, WaitTurnsRequestSchema, ListEventsRequestSchema, ListWebhookEndpointsRequestSchema, CreateWebhookEndpointRequestSchema, GetWebhookEndpointRequestSchema, DeleteWebhookEndpointRequestSchema, SetWebhookEndpointStatusRequestSchema, ListPushSubscriptionsRequestSchema, CreatePushSubscriptionRequestSchema, DeletePushSubscriptionRequestSchema, ForgetPushSubscriptionRequestSchema, PushTargetRequestSchema, CreateSubscriptionRequestSchema, ListSubscriptionsRequestSchema, GetSubscriptionRequestSchema, PauseSubscriptionRequestSchema, ResumeSubscriptionRequestSchema, DeleteSubscriptionRequestSchema, CompleteSubscriptionRequestSchema, CreateTriggerRequestSchema, ListTriggersRequestSchema, GetTriggerRequestSchema, UpdateTriggerRequestSchema, DeleteTriggerRequestSchema, TriggerFiredRequestSchema, GetTurnFailureRequestSchema, ListStopFailuresRequestSchema, ListSnapshotsRequestSchema, ListCredentialHandoversRequestSchema, GetSnapshotRequestSchema, TranscriptCursorRequestSchema, ConnectedAccountsRequestSchema, DeleteBuildConnectionRequestSchema, CircleCIConnectionRequestSchema, CircleCITokenRequestSchema, ConnectCircleCIRequestSchema, ListCircleCIProjectsRequestSchema, CircleCIProjectBoundToRequestSchema, CircleCIProjectOfRequestSchema, AddCircleCIProjectRequestSchema, CircleCIWebhooksRequestSchema, CircleCIWebhookSecretRequestSchema, DeleteCircleCIProjectRequestSchema, GitHubActionsConnectionRequestSchema, ConnectGitHubActionsRequestSchema, NamespaceConnectionRequestSchema, ConnectNamespaceRequestSchema, OfferSentRequestSchema, HostHelloRequestSchema, HostUsageRequestSchema, ReconcileHeldBoxesRequestSchema, ForgetHostUsageRequestSchema, RunningTurnsByHostRequestSchema, ListHostUsageRequestSchema, DeferredOffersRequestSchema, TurnMetricDimensionsRequestSchema, PrepareOfferRequestSchema, HostPresenceRequestSchema, HostMessageRequestSchema, DeadlineReachedRequestSchema]);
export const TenantRefusalSchema = z.discriminatedUnion("refusal", [TenantApiVersionUnsupportedSchema, TenantOperationUnknownSchema, TenantRequestInvalidSchema]);
export const GuestInputSchema = z.discriminatedUnion("type", [GuestTurnStartSchema, GuestTurnCancelSchema, GuestClaudeSetupStartSchema, GuestClaudeSetupCodeSchema]);
export const GuestMessageSchema = z.discriminatedUnion("type", [GuestHelloSchema, GuestTurnRepositoryReadySchema, GuestTurnLineSchema, GuestTurnRepositoryCloneFailedSchema, GuestTurnEndSchema, GuestClaudeSetupUrlSchema, GuestClaudeSetupStoredSchema, GuestClaudeSetupFailedSchema]);
