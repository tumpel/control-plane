export declare const MCP_PATH = "/mcp";
