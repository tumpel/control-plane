import type { HarnessCatalogEntrySchema, ProblemSchema, SecretSetCreateSchema, SecretSetSchema } from "@tumpel/schemas";
import type { z } from "zod";
type CatalogEntry = Pick<z.infer<typeof HarnessCatalogEntrySchema>, "credentials" | "credentialChoice">;
export type AcceptedCredential = CatalogEntry["credentials"][number];
type Provider = AcceptedCredential["provider"];
export type SecretMember = z.infer<typeof SecretSetCreateSchema>["secrets"][number];
export type SecretKey = z.infer<typeof SecretSetSchema>["keys"][number];
type Credential<T extends SecretKey | SecretMember> = Exclude<T, {
    kind: "Variable";
}>;
export interface DispatchVariable {
    name: string;
    value: string;
}
export interface DispatchFile {
    path: string;
    value: string;
}
export type CredentialRefusal = {
    kind: "NoCredential";
    accepted: AcceptedCredential[];
} | {
    kind: "NoModelCredential";
    model: string;
    provider: Provider;
    accepted: AcceptedCredential[];
} | {
    kind: "Unsupported";
    name: string;
    credentialKind: string;
    supported: string[];
} | {
    kind: "ModelUnsupported";
    model: string;
    name: string;
    credentialKind: string;
    allowed: string[];
} | {
    kind: "Expired";
    name: string;
    expiresAt: string;
};
export type CredentialCheck<T extends SecretKey | SecretMember> = {
    kind: "Usable";
    credential: Credential<T>;
    variable: string;
    fixed: DispatchVariable[];
    arguments: string[];
    costBasis: AcceptedCredential["costBasis"];
} | CredentialRefusal;
export type CredentialProblem = z.infer<typeof ProblemSchema>;
export declare const modelProvider: (model: string) => Provider;
export declare const checkCredential: <T extends SecretKey | SecretMember>(entry: CatalogEntry, members: readonly T[], now: number) => CredentialCheck<T>;
export declare const checkModelCredential: <T extends SecretKey | SecretMember>(entry: CatalogEntry, members: readonly T[], model: string, now: number) => CredentialCheck<T>;
export declare const credentialProblem: (refusal: CredentialRefusal, owner: string, harness: string, retry: string) => CredentialProblem;
export declare const dispatchVariables: (entry: CatalogEntry, members: readonly SecretMember[], model: string, now: number) => {
    kind: "Ready";
    variables: DispatchVariable[];
    arguments: string[];
    credentialFile?: DispatchFile;
} | CredentialRefusal;
export {};
